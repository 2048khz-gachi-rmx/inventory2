local function inc(str)

	include(str)
	AddCSLuaFile(str)

end


inc('inventory/shared/crafts.lua')