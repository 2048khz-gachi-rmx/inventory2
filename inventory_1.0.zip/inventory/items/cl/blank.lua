--ay

UniqueItems.Blank = UniqueItems.Blank or {}
local it = UniqueItems.Blank

local fe = Material("models/props_c17/fisheyelens")
fe:SetFloat("$bluramount", 0.3)
fe:SetFloat("$refractamount", -0.05)

fe:SetFloat("$vertexalpha", 1)
fe:SetInt("$alphatest", 1)

fe:SetInt("$alpha", 1)

fe:Recompute()


local w, h = ScrW(), ScrH()

local rad = ScrW() * 1.5
local ref = 0

local render = render 

function it:ClientUse()
	timer.Simple(LocalPlayer():Ping()/500, function()
		rad = 16
		sound.PlayFile("data/hdl/blank.dat", "", function() end)
	end)
	self:TakeAmount(1)
end

hook.Add("HUDPaint", "Inventory.BlankFX", function() 

	local max = w*1.5

	ref = (max - rad) * -0.00002

	rad = math.min(L(rad, max, 5), rad + max*FrameTime()*3)

	if rad > w and ref>-0.00025 then return end 
	fe:SetFloat("$refractamount", ref)
	fe:SetFloat("$bluramount", math.Round((max-rad)/max, 3))

	fe:Recompute()


	render.UpdateScreenEffectTexture()

	surface.SetDrawColor(255, 255, 255)
	surface.SetMaterial(fe)


	render.SetStencilEnable(true)
		render.ClearStencil()
		render.SetStencilWriteMask( 3 )
		render.SetStencilTestMask( 3 )
		
		render.SetStencilCompareFunction( STENCIL_NEVER )
		render.SetStencilPassOperation( STENCIL_KEEP )
		render.SetStencilFailOperation( STENCIL_REPLACE )
		render.SetStencilZFailOperation( STENCIL_REPLACE )
		render.SetStencilReferenceValue( 1 ) --1 = paint. 0 = ignore

		surface.DrawTexturedRect(0, 0, w, h)
		
		render.SetStencilReferenceValue( 0 ) --1 = paint. 0 = ignore

		draw.Circle(w/2, h/2, rad - 10, 64)

	
		render.SetStencilFailOperation( STENCIL_ZERO )
		render.SetStencilZFailOperation( STENCIL_ZERO )

		render.SetStencilCompareFunction( STENCIL_EQUAL )
		render.SetStencilFailOperation( STENCIL_KEEP )
		render.SetStencilZFailOperation( STENCIL_KEEP )

		--surface.DrawTexturedRect(ex, ey, w - ex*2, h - ey*2)
		

		draw.Circle(w/2, h/2, rad, 64)

	render.SetStencilEnable(false)

end)
net.Receive("Blank", function()
	local ply = net.ReadEntity()
	print('stunned by', ply)
	sound.PlayFile("data/hdl/blank.dat", "", function() end)
end)