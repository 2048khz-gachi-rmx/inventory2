--ay
print(CLIENT, SERVER, "Blanks (SH)")

UniqueItems.Blank = UniqueItems.Blank or {}
local it = UniqueItems.Blank

function it:SharedUse(ply)
	
end