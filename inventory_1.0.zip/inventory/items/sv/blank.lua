--ay

UniqueItems.Blank = UniqueItems.Blank or {}
local it = UniqueItems.Blank

util.AddNetworkString("Blank")

local force = 800 

local function BlankStun(ply, own, str)--ength

	local norm = (ply:GetPos() - own:GetPos()):GetNormalized()
	
	if not IsPlayer(ply) then 

		if BWEnts[ply] then 
			ply:DrainPower(ply:GetPower() or BWEnts[ply].Power)
			BWEnts[ply].Power = 0
			ply:SetPower(0)
		end

		local phys = ply:GetPhysicsObject()

		if not phys or not phys:IsMoveable() then return end 

		ply:GetPhysicsObject():SetVelocity(norm*(str*force))

		

	else 
		local vel = norm * (str * force)
		if ply:IsOnGround() and norm.z <= (250/force) then 
			vel = vel * 3
		end

		ply:SetVelocity(vel)

		for k,v in pairs(ply:GetWeapons()) do
			if v.Base and (v.Base:find("cw_") or v.Base:find("tfa_")) then 
				v:SetNextPrimaryFire(math.max(v:GetNextPrimaryFire(), CurTime()) + (2*str))
			end
		end

	end
	

end

local sqr = 768^2

function it:ServerUse(ply)

	local pos = ply:EyePos()

	local tbl = ents.FindInSphere(pos, 768)

	for k,v in ipairs(tbl) do 
		if not IsPlayer(v) and not BWEnts[v] and not (v.GetClass and v:GetClass()=="prop_physics" and v.CPPIGetOwner) then 
			tbl[k] = nil 
		end
	end

	for k,v in pairs(tbl) do 

		if v==ply then continue end 

		local pos = v:LocalToWorld(v:OBBCenter()) --get center of ent

		tbl[k] = nil 	--remove from ignore list

		local ppos = ply:GetPos()
		local epos = ply:EyePos()

		local dist = (sqr - (ppos:DistToSqr(pos)))/sqr

		local tr = {
			start = epos, 
			endpos = pos,
			filter = tbl,
		}

		tr = util.TraceLine(tr)

		tbl[k] = v 		--back

		if (tr.HitWorld and dist < 0.4) or dist < 0.1 then print('hell naw', dist) continue end  


		local str = math.min(dist, 1)
		if str > 0.75 then str = 1 end 

		if tr.HitWorld then str = str * 0.5 end
		BlankStun(v, ply, str)

	end
	local rec = RecipientFilter()
	rec:AddPVS(ply:GetPos())
	rec:RemovePlayer(ply)

	net.Start("Blank")
		net.WriteEntity(ply)
	net.Send(rec)

	self:TakeAmount()
end
