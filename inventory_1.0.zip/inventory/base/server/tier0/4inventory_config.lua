Inventory.Config = Inventory.Config or {}

local cfg = Inventory.Config 

cfg.StartingModChance = 100 --100% for at least one mod
cfg.ModDecreaseChance = 0.5 --(startingmodchance) * (0.5 ^ #mods) chance for a new mod
							--For the first mod it would be (100) * (0.5^0), the second: (100) * (0.5^1) a.k.a. 50%

cfg.MaxMods = 4



function InvConfig(k)
	return cfg[k]
end

