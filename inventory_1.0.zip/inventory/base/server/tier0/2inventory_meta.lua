include("inventory/base/shared/item_meta.lua")

local log = Inventory.Log

local shorts = {
	ItemID = "i",
	ItemUID = "u",
	perma = "p",
	ItemAmount = "a",
}

local dontnet = {
	ItemInfo = true,
	ItemUID = true,
	OverrideNetwork = true,
	DontNetwork = true,
	Changes = true,
	Table = true,
	__modindex = true,
	__newindex = true,
}

local proxies = {
	perma = true,
}
local dontnetperma = {
	Internal = true,
}


local function UpdateAmount(uid, amt)

	local str = "UPDATE Items SET amt = %s WHERE uid = %s"
	str = str:format(amt, uid)

	local q = Inventory.DB:query(str)
	q.onError = Inventory.SQLErr

	q:start()

end


function itemfuncs:SetPermaStat(k, v, ignoreuid)
	Inventory.SetPermaStat(self:GetOwner(), self:GetUID(), k, v, ignoreuid)
	QNI(self)
end


function itemfuncs:DeleteItem()
	Inventory.RemoveItem(self:GetOwner(), self:GetUID())
end

itemfuncs.Delete = itemfuncs.DeleteItem
itemfuncs.RemoveItem = itemfuncs.DeleteItem 
itemfuncs.Remove = itemfuncs.DeleteItem 

function itemfuncs:SetAmount(amt)
	if not self:GetAmount() then print("are you retarded", self:GetUID()) return end 

	UpdateAmount(self:GetUID(), amt)

	self.ItemAmount = amt
	QNI(self)
	return amt
end

function itemfuncs:TakeAmount(amt)
	if not self:GetAmount() then print("are you retarded", self:GetUID()) return end 
	local oldamt = self:GetAmount()
	
	amt = amt or 1 

	if self:GetAmount() - amt <= 0 then 
		local left = amt - self:GetAmount()
		self:DeleteItem()
		return left 
	end

	UpdateAmount(self:GetUID(), self:GetAmount() - amt)

	self.ItemAmount = self:GetAmount() - amt
	QNI(self:GetOwner())

	return math.max(amt - oldamt, 0)
end


ChainAccessor(itemfuncs, "Owner", "Owner")

function itemfuncs:UIDQuery(f)

	if self:GetUID() then 
		f(self, self:GetUID())

		return nil
	else 

		if not self.__Queries then self.__Queries = {} end 

		self.__Queries[#self.__Queries + 1] = f

		return #self.__Queries
	end

		
end

function itemfuncs:Use(ply)
	local use = self:GetItem().Usable and self:GetItem().ServerUse

	local al = self:GetAlias()
	local shuse = self:GetItem().Usable and self:GetItem().SharedUse

	if al then 
		al = UniqueItems[al]
		if not al then print('no such item:', al) return end 
		use = al.ServerUse
		shuse = al.SharedUse
	end

	if not use and not shuse then return false end 
	
	if not IsValid(ply) then return end

	local ok = use and use(self, ply)

	local shok = shuse and shuse(self, ply)

	return ok
end

function itemfuncs:GetItemOnItem(it)
	local can = self:GetItem().Interactable and self:GetItem().Interactable[it:GetID()]

	if not can then can = it:GetItem().Interactable and it:GetItem().Interactable[self:GetID()] end --backwards

	if not can then 
		if it:GetAmount() and self:GetAmount() then 
			can = Inventory.StackFunction
		end
	end

	if not can then return false end 

	return can
end

function itemfuncs:TakeItem(amt, req)

	local ply = self:GetOwner()
	if not ply or not IsValid(ply) then return end 

	return Inventory.TakeItem(self, ply, amt, req)
end

function itemfuncs:SetUID(uid)
	self.ItemUID = uid
end

function itemfuncs:AddItem(amt, req)
	local ply = self:GetOwner()
	if not ply or not IsValid(ply) then print('uh owner not valid so fuck that') return false end 


	return Inventory.AddItem(self, ply, amt)
end

local function FetchUnnetworked(self)
	local ret = {}

	local search = self.Changes

	if self.Unknown then 

		search = self

	end

	for k,v in pairs(search) do 
		if not dontnet[k] then 
			if shorts[k] then ret[shorts[k]] = v continue end
			ret[k] = v 
		end 
	end
	
	if self.Changes then self.Changes = {} end

	local prm = Items.FetchPerma(self)

	if prm then 
		ret.perma = {}
		local p = ret.perma

		if self.Unknown then 
			
			for key, val in pairs(prm) do 
				p[key] = val
			end

		else

			for key, _ in pairs(proxies) do

				if self[key] and self[key].Changes and not table.IsEmpty(self[key].Changes) then 
					p[key] = {}
					for k2,v2 in pairs(self[key].Changes) do 
						p[key][k2] = v2
						self[key].Changes[k2] = nil
					end
					self[key].Changes = {}
				end 
			end

		end

	end
	if ret.perma and table.IsEmpty(ret.perma) then ret.perma = nil end 

	return ret
end

Items.FetchUnnetworked = FetchUnnetworked

local function FetchPerma(self)
	local ret = {}
	if not self.perma then return false end 

	for key, val in pairs(self.perma) do 
		if dontnet[key] then continue end
		ret[key] = val

	end

	return ret
end

Items.FetchPerma = FetchPerma

function itemfuncs:Network()	--forcefully network
	local ply = self:GetOwner()

	Inventory.QueueForNetworking(self)

end

function itemfuncs:Encode(typ)
	local ns = netstack:new()

	ns:WriteUInt(self:GetID(), Inventory.IIDConstant)
	ns:WriteUInt(self:GetUID(), Inventory.UIDConstant)
	
	local tab

	if typ=="changes" or not typ then 

		if self.Unknown then
			self.Unknown = nil
			return self:Encode("full")	--since item was never known, network like it's full
		end

		local new = FetchUnnetworked(self)

		if new.a then 
			ns:WriteBool(false)	--item amount changed
			ns:WriteUInt(new.a, 16)
		elseif new.perma then

			ns:WriteBool(true)	--perma changed
			tab = new.perma
		else 
			return false --dont nw anything
		end
		print("networking myself", self:GetUID(), new.perma, new.a)
		self.Unknown = nil 

		return ns, tab

	elseif typ=="full" or typ == "others" then

		if self:GetAmount() then 
			ns:WriteBool(false)
			ns:WriteUInt(self:GetAmount(), 16)
		else
			ns:WriteBool(true)
			if (self.perma) then

				local prm = FetchPerma(self)

				if not table.IsEmpty(prm) then 

					tab = util.TableToJSON(prm)

				end

			end

		end

		if typ=="full" then self.Unknown = nil end

	end

	return ns, tab
end

function itemfuncs:__modindex(k, v)
	if dontnet[k] then return end
	if key~="Changes" then
		self.Changes[k] = v
	end
end



function itemfuncs:Initialize(iid, perma, amt, ply)	--you can omit ply

	local it = ProxyTable(self)

	it.ItemID = (isnumber(iid) and iid) or (isstring(iid) and Inventory.StringToID[iid]) 
	it.ItemInfo = Items[iid] or (log("Attempted to create an unknown item! PUID: %s, ItemID: %s", ply, iid) and {})
	it.ItemAmount = amt

	it.Owner = (isnumber(ply) and sql.GetByPUID(ply, true)) or ply 
	it.Unknown = true 

	if perma then

		it.perma = ProxyTable()

		for k,v in pairs(perma) do 
			it.perma[k] = v
		end
		it.perma.Changes = {}

	end
	
	

	it.Changes = {}

	if not Items[iid] then 
		errorf("Unknown item %s! (no Items[%s])", iid, iid)
		return
	end

	local smeta = Items[iid].specialMeta
	local smt = (istable(smeta) and smeta) or (isstring(smeta) and _G[smeta]) or item

	setmetatable(self, smt)
	--[[
	if smt and smt.new then 

		it.Table = smt.Recreate(it) 
		if not it then error("failed to recreate lol?") return end
	end
	]]

	--setmetatable(it:GetTable(), smt or item)

	function it:Ready()
		
		self.Changes = {}

		self.__newindex = it.__modindex 

		if perma then
			it.perma.__modindex = function(self, key, val)
				if key~="Changes" then
					self.Changes[key] = val
				end
			end
			self.perma.__newindex = it.perma.__modindex 
		end

	end

	return it
end

local DB 

local function WriteToSQL(name, tab, ret)
	local keys = ""

	local vals = ""

	DB = DB or Inventory.DB

	for k,v in pairs(tab) do 

		k = "`" .. tostring(k) .. "`"
		v = (isstring(v) and mysql.quote(DB, v)) or tostring(v)

		keys = keys .. k .. ","
		vals = vals .. v .. ","

	end

	keys = keys:sub(1, #keys - 1)
	vals = vals:sub(1, #vals - 1)

	local str = "INSERT INTO %s(%s) VALUES(%s)"
	str = str:format(name, keys, vals)

	

	local q = DB:query(str)

	q.onError = Inventory.SQLErr

	q.onSuccess = function(self, dat, what)
		if ret then ret(self:lastInsert()) end
	end


	q:start()
end

ABC = WriteToSQL

function itemfuncs:ToVault(ply, uid)

	local uid = uid or self:Write(function(uid)
		self.ToVault(self, ply, uid)
	end)

	self:SetBelongs(ply.Inventory.Vault)
	self:SetBelongsID(2)

	self:SetOwner(ply)

	if not uid then return self end

	ply.Items[uid] = self 

	WriteToSQL("ply_vault", {
		uid = uid,
		puid = sql.GetPUID(ply)
	})

	return self
end 

function itemfuncs:ToTemporary(ply, uid)
	print("called with args", self, ply, uid)
	local uid = uid or self:Write(function(uid)
		self.ToTemporary(self, ply, uid)
	end)

	self:SetBelongs(ply.Inventory.Temp)
	self:SetBelongsID(1)
	self:SetOwner(ply)

	if not uid then return self end

	ply.Items[uid] = self 

	WriteToSQL("ply_tempinv", {
		uid = uid,
		puid = sql.GetPUID(ply)
	})

	return self
end
itemfuncs.ToTemp = itemfuncs.ToTemporary

function itemfuncs:ToPerma(ply, uid)
	local uid = uid or self:Write(function(uid)
		self.ToPerma(self, ply, uid)
	end)

	self:SetBelongs(ply.Inventory.Perma)
	self:SetBelongsID(3)
	self:SetOwner(ply)

	if not uid then return self end

	ply.Items[uid] = self 

	WriteToSQL("ply_permainv", {
		uid = uid,
		puid = sql.GetPUID(ply)
	})

	return self
end

function itemfuncs:Insert(uid)

	if self:GetBelongs() then 
		if uid or self:GetUID() then self:GetBelongs()[uid or self:GetUID()] = self return end 

		self:UIDQuery(self.Insert)
	else 
		log("Couldn't get where this item belongs!")
	end

end

function itemfuncs:Write(cb, cb_anyway)

	local uid = self:GetUID()

	if uid then --If the item has a UID that means it's already written into MySQL

		if cb_anyway then 
			cb(uid)
		end

		return uid 
	end 


	--Otherwise, the item is not in MySQL: write it and do the callback

	local iid = self.ItemID 	--self:GetID() doesn't... work? for some reason?

	if isstring(iid) then 
		iid = Inventory.StringToID[iid]
	end

	if not iid then 
		error("No ItemID to write to MySQL! Check your order!")
		return 
	end
	
	

	local perma = self:GetPerma()
	local amt = self:GetAmount()

	amt = (amt and tostring(amt)) or nil
	perma = (perma and util.TableToJSON(perma)) or nil

	WriteToSQL("items", {
		iid = iid,
		perma = perma,
		amt = amt,
	}, function(uid)
		self:SetUID(uid)
		cb(uid)

		if self.__Queries then 
			for k,v in ipairs(self.__Queries) do 
				v(self, uid)
				self.__Queries[k] = nil 
			end 

			self.__Queries = nil 
		end

	end)

	return false
end