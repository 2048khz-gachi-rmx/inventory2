

local invQuery = "CREATE TABLE IF NOT EXISTS InvIDs(id INTEGER PRIMARY KEY, itemname TEXT UNIQUE)" 
sql.Check(invQuery)

local insIID = [[INSERT OR IGNORE INTO InvIDs(itemname) VALUES('%s');
		SELECT id FROM InvIDs WHERE itemname = '%s';]]

ItemsString = {}

Inventory.IIDConstant = Inventory.IIDConstant or 2
Inventory.UIDConstant = Inventory.UIDConstant or 2

knowsItems = knowsItems or {}
knowsIDs = knowsIDs or {}

Inventory.IDItems = Inventory.IDItems or {}

Inventory.IDToString = Inventory.IDToString or {}
Inventory.StringToID = Inventory.StringToID or {}

Inventory.DBIDs = Inventory.DBIDs or {}
Inventory.DBStr = Inventory.DBStr or {}

Inventory.UItems = Inventory.UItems or {}
Inventory.UniqueItems = Inventory.UItems 

local DB = Inventory.DB 

local IDFetched = false 

local IDFetch = {}	--after IDs are fetched these will be written

local LargestID = 0

function Inventory.CreateNewItem(name, tbl, cb)
	local cb = cb or BlankFunc

	if not isstring(name) then 
		errorf("BaseItem creation failed: 1st arg must be a string! Got: %s", name)
		return
	end

	tbl = (tbl.IsBaseItem and tbl) or BaseItem:new(name, tbl)
	tbl.IsBaseItem = true 

	if Items[name] then
			
		tbl.ItemID = Items[name].ItemID
		local id = Items[name].ItemID

		Items[name] = tbl 
		tbl.ItemIDName = name 

		if id then Items[id] = tbl end
		
		ItemsString[name] = tbl
		
		return tbl
	end
	
	tbl.ItemName = name

	tbl.ItemIDName = name
	Items[name] = tbl
	ItemsString[name] = tbl 

	if not IDFetched then --SQL didn't grab ItemID's yet; add to queue
		IDFetch[#IDFetch + 1] = {name = name, cb = cb}
		Items[name] = tbl
	else 

		local id = Inventory.DBStr[name]

		if not id then --this item doesn't have an ItemID at all; add it to SQL

			local qs = "INSERT INTO ItemIDs(name) VALUES(%s)"
			qs = qs:format(mysqloo.quote(DB, name))

			local q = DB:query(qs)
			q.onError = Inventory.SQLErr

			q.onSuccess = function(self)
				local id = self:lastInsert()

				Inventory.IDToString[id] = name
				Inventory.StringToID[name] = id 

				tbl.ItemID = id 

				local iidc = bit.GetLen(id)

				Inventory.QueueConsts(player.GetAll())
				Inventory.IIDConstant = math.max(iidc, Inventory.IIDConstant)

				cb(id)
			end

			q:start()

			return
		end

		--this item was already fetched by SQL; just assign it the itemID

		tbl.ItemID = id 

		Inventory.IDToString[id] = name
		Inventory.StringToID[name] = id 

		local iidc = bit.GetLen(id)

		Inventory.IIDConstant = math.max(iidc, Inventory.IIDConstant)
		Inventory.QueueConsts(player.GetAll())
		

	end

	return tbl
end

function Inventory.Initialize(reinit)

	DB = DB or Inventory.DB or mysqloo.connect(unpack(__MYSQL_INFO))

	DB.onConnectionFailed = Inventory.SQLErr

	local status = DB:status()
	if status == 2 then 	--not 3 because if it's 3 then it does the "lua object referenced twice" error
		DB:connect() 
	elseif status == 3 and not reinit then 
		Inventory.DB = mysqloo.connect(unpack(__MYSQL_INFO))
		DB = Inventory.DB 	--reconnect to SQL and re-initialize
		Inventory.Initialize(true)
		return
	end

	Inventory.DB = DB

	local create_use_q = DB:query("CREATE DATABASE IF NOT EXISTS `Inventory`; USE `Inventory`")

	create_use_q.onError = Inventory.SQLErr

	create_use_q:start()

	mysqloo.CreateTable(DB, "ply_TempInv", "uid INT UNIQUE PRIMARY KEY", "puid INT", "time TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	mysqloo.CreateTable(DB, "ply_Vault", "uid INT UNIQUE PRIMARY KEY", "puid INT")
	mysqloo.CreateTable(DB, "ply_PermaInv", "uid INT UNIQUE PRIMARY KEY", "puid INT")

	mysqloo.CreateTable(DB, "Items", "uid INT UNIQUE PRIMARY KEY AUTO_INCREMENT", "iid INT", "amt INT", "perma JSON")
	mysqloo.CreateTable(DB, "ItemIDs", "id INT UNIQUE PRIMARY KEY AUTO_INCREMENT", "name TEXT")

	--[[
		Grabbing maximum ItemUID for networking as a constant
	]]


	local q = "SELECT MAX(uid) FROM items"
 	q = DB:query(q)

 	q.onError = Inventory.SQLErr 
 	q.onSuccess = function(self, dat)

 		local uid = dat[1]["MAX(uid)"]

 		Inventory.UIDConstant = bit.GetLen(uid) + 1
 		
 	end
 	
 	q:start()


 	--[[
		Filling in ItemID : ItemName fields
 	]]

	local q = ("SELECT * FROM ItemIDs")

	q = DB:query(q)

	q.onSuccess = function(_, dat)

		--[[
			Fetch all ItemID : ItemName pairs
			and add them to "existing" pairs
		]]

		for k,v in ipairs(dat) do 
			Inventory.DBIDs[v.id] = v.name
			Inventory.DBStr[v.name] = v.id


			Inventory.IDToString[v.id] = v.name
			Inventory.StringToID[v.name] = v.id

			if istable(Items[v.name]) then 
				local it = Items[v.name]

				it.ItemID = v.id
				Items[v.id] = it
			end
			LargestID = math.max(v.id, LargestID)

			local len = bit.GetLen(LargestID)

			if not dat[k + 1] then
				Inventory.IIDConstant = math.max(len, Inventory.IIDConstant)
				Inventory.QueueConsts(player.GetAll())
			end

		end

		IDFetched = true
		
		--[[
			For each new item created with Inventory.CreateNewItem b4 the query,
			check if they already existed in SQL
		]]

		local toInsert = 0

		for k,t in pairs(IDFetch) do

			local name = t.name
			local cb = t.cb

			--[[
				If they did, just add them to the Items table, 
				give their base item an ItemID entry and check for highest ItemID
			]]

			if Inventory.DBStr[name] then 

				local id = Inventory.DBStr[name]

				Inventory.IDToString[id] = name 
				Inventory.StringToID[name] = id

				Inventory.IDItems[id] = Items[name]
				Items[id] = Items[name]

				Items[name].ItemID = id
				LargestID = math.max(LargestID, id)

				if not next(IDFetch, k) then 
					local len = bit.GetLen(LargestID)

					Inventory.IIDConstant = math.max(len, Inventory.IIDConstant)
					Inventory.QueueConsts(player.GetAll())
				end

				cb(id)

				continue
			end

			--[[
				otherwise, add them to SQL
			]]

			local qs = "INSERT INTO ItemIDs(name) VALUES(%s)"
			qs = qs:format(mysqloo.quote(DB, name))

			local q = DB:query(qs)
			q.onError = Inventory.SQLErr

			q.onSuccess = function(_, dat)
				local id = q:lastInsert()

				Inventory.IDToString[id] = name 
				Inventory.StringToID[name] = id

				Inventory.IDItems[id] = Items[name]
				Items[id] = Items[name]

				Items[name].ItemID = id

				LargestID = math.max(LargestID, id + 1)
				

				toInsert = toInsert - 1 

				if toInsert == 0 then 

					local len = bit.GetLen(LargestID)

					Inventory.IIDConstant = math.max(len, Inventory.IIDConstant)
					Inventory.QueueConsts(player.GetAll())

				end

				cb(id)

			end

			toInsert = toInsert + 1

			q:start()
		end
 	end

 	q:start()


end

Inventory.Initialize()

util.AddNetworkString("ReceiveInventoryConsts")

function Inventory.SendConsts(ply, justids)

	local ns = netstack:new()

	--[[
		Bool: Contains IDs
			UInt, 6: UID
			Int, 6: ID

		Bool: Contains ItemInfo
			UInt, 16: Len of item names
			Bool: Compressed or no 
			Data: (un)Compressed data
			UInts, IDConst: Item IDs

	]]

	if not justids then

		if not knowsIDs[ply] or knowsIDs[ply][1] ~= Inventory.UIDConstant or knowsIDs[ply][2] ~= Inventory.UIDConstant then 
			ns:WriteBool(true)
		
			ns:WriteUInt(Inventory.UIDConstant, 6)
			ns:WriteUInt(Inventory.IIDConstant, 6)
		else
			ns:WriteBool(false)
		end


		if not knowsItems[ply] then 
			knowsItems[ply] = {}
		end

		local unknowns = {}

		for k,v in pairs(Inventory.IDToString) do 
			if not knowsItems[ply][k] then 
				unknowns[k] = v 
			end 
		end
		print("unknowns:", table.Count(unknowns))
		if not table.IsEmpty(unknowns) then
			local str = ""
			local sep = "|"
			ns:WriteBool(true)

			for k,v in pairs(unknowns) do 
				str = str .. (v:gsub("|", "\\|"))
				if next(unknowns, k) then str = str .. sep end
			end 
			local comp = util.Compress(str)

			if #str > #comp then ns:WriteBool(true) str = comp else ns:WriteBool(false) end

			ns:WriteUInt(#str, 16)
			ns:WriteData(str, #str)

			for k,v in pairs(unknowns) do 
				ns:WriteUInt(k, Inventory.IIDConstant)
				knowsItems[ply][k] = true
			end
		else 
			ns:WriteBool(false)
		end
	else
		ns:WriteBool(true)

		ns:WriteUInt(Inventory.UIDConstant, 6)
		ns:WriteUInt(Inventory.IIDConstant, 6)
		
		ns:WriteBool(false)
	end

	net.Start("ReceiveInventoryConsts")
		net.WriteNetStack(ns)
	net.Send(ply)
end

local plys = {}
function Inventory.QueueConsts(ply)

	if istable(ply) then 
		table.Merge(plys, ply)
	else
		plys[#plys + 1] = ply
	end

	timer.Create("QueueConsts", 0, 1, function()
		local stillhere = {}
		for k,v in pairs(plys) do 
			if IsPlayer(v) then
				stillhere[#stillhere + 1] = v 
			end 
		end 
		Inventory.SendConsts(stillhere)
	end)
end
hook.Add("PlayerFullyLoaded", "SendInvConsts", function(ply)
	Inventory.SendConsts(ply)
	hook.Run("PlayerInventoryReady", ply)
end)