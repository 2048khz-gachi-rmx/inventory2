Inventory = Inventory or {}
Inventory.Actions = {}

--[[

	1: Delete item
	2: Stack item
	3: Drop X amount of item
	4: Use item
]]
Inventory.Actions[1] = {args = 1, func = function(ply, uid)

	local item = ply:HasItem(uid)
	if not item then print('no item'..uid) return end 
	ply:DeleteItem(item:GetUID())

end}


--stacking items:

local recent = {}

Inventory.Actions[2] = {args = 2, func = function(ply, uid, uid2) --item: from; item2: to
	
	local item = ply:HasItem(uid)
	local item2 = ply:HasItem(uid2)

	if not item or not item2 then print('not item or not item2', uid, uid2) return end
	if item:GetID()~=item2:GetID() then print('itemids not equal', item:GetID(), item2:GetID() ) return end 

	if not item:GetAmount() or not item2:GetAmount() then return end

	local lt = recent[uid]
	local lt2 = recent[uid2]
	local ct = CurTime() 

	if lt then 
		if ct-lt < 0.1 then return else recent[uid] = nil end 
	end 

	if lt2 then 
		if ct-lt2 < 0.1 then return else recent[uid2] = nil end 
	end 

	recent[uid] = ct 
	recent[uid2] = ct


	local was1, was2 = item:GetAmount(), item2:GetAmount()

	local left = item:AddItem(item2:GetAmount())
	if not left then print('returned false') Inventory.ResumeNetworking(ply) return end

	item:Network()

	if left <= 0 then 
		item2:Remove() 
	else 
		item2:SetAmount(left) 
	end


end}

Inventory.Actions[4] = {args = 1, func = function(ply, uid)
	
	local item = ply:HasItem(uid)
	if not item then print('not item ', uid) return end

	local lt = recent[uid]
	local ct = CurTime() 
	local cd = item:GetItem().Cooldown 

	if cd then 
		if lt then 
			if lt-ct <= cd then return end 
		else 
			recent[uid] = ct 
		end 
	end
	
	item:Use(ply)

end}

util.AddNetworkString("InventoryAction")

net.Receive("InventoryAction", function(len, ply)

	local type = net.ReadUInt(8)
	local uids = {}
	local action = Inventory.Actions[type]
	if not action or not action.func then print('no action for type #'..type) return end 

	local args = action.args 
	if not args then print('no #args for type #'..type) return end 

	for i=1, args do 
		uids[i] = net.ReadUInt(32)
	end
	action.func(ply, unpack(uids))


end)