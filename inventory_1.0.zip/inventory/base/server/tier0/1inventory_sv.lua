local shorts = {
	ItemID = "i",
	ItemUID = "u",
	perma = "p",
	ItemAmount = "a",
}

local dontnet = {
	ItemInfo = true,
	ItemUID = true,
	OverrideNetwork = true,
	DontNetwork = true,
	Changes = true,
}

local dontnetperma = {
	Internal = true,
}

--Names for getting inventory name by an ID for indexing within player.Inventory

local invs = {
	[3] = "Perma",
	[2] = "Vault",
	[1] = "Temp",
}


--Names for getting inventory name by an ID for MySQL

local sqlinvs = {
	[3] = "ply_permainv",
	[2] = "ply_vault",
	[1] = "ply_tempinv",
}

local DontNetwork = {}
local DontNetworkAll = false 

Inventory.LogTable = {name = "Inventory", col = Color(60, 175, 255)}

local log

log = function(str, ...)
	Log(Inventory.LogTable, str, ...)
end

Inventory.Log = log 


hook.Add("PostGamemodeLoaded", "inventory_log", function()

	log = function(str, ...)
		Log(Inventory.LogTable, str, ...)
	end
	Inventory.Log = log 

end)


local DB = Inventory.DB

local function LogSQLError(query, err, sql)
	log("[col=230, 70, 70]SQL Error![col=255,255,255]\nError: %s\nSQL: %s", err, sql)
end

Inventory.SQLErr = LogSQLError 


local qtonet = {}

local queued = {}
local fullqueued = {}

function Inventory.QueueForNetworking(it, full, del)
	local sid
	local ply

	if it.ItemID then
		ply = it:GetOwner()
		if not IsPlayer(ply) then ErrorNoHalt("item owner is not a player? " .. tostring(it:GetID()) .. ": " .. tostring(ply) .. "\n") return end 

		if DontNetwork[ply] or DontNetworkAll then 
			local str = "-- Not queueing inventory for networking %sas DontNetwork%s is enabled --\n"
			str = str:format((DontNetwork[ply] and ("to " .. ply:Nick().." ")) or "", (DontNetworkAll and "All") or "[ply]" )
			MsgC(Color(50, 150, 250), str) 
			return 
		end

		if not queued[ply] then queued[ply] = {} end
		sid = ply:SteamID64()	

		queued[ply][#queued[ply] + 1] = it
	elseif IsPlayer(it) then 

		if DontNetwork[it] or DontNetworkAll then 
			local str = "-- Not queueing inventory for networking %sas DontNetwork%s is enabled --\n"
			str = str:format((DontNetwork[it] and ("to " .. it:Nick().." ")) or "", (DontNetworkAll and "All") or "[ply]" )
			MsgC(Color(50, 150, 250), str) 
			return 
		end

		fullqueued[it] = {}
		fullqueued[it][1] = full 
		fullqueued[it][2] = del
		sid = it:SteamID64()
		ply = it
	end

	timer.Create("NetworkFor" .. sid, 0, 1, function()	--this is done in order for multiple items to be able to be queued in a single tick
		if not IsValid(ply) then return end
		log("deciding networking") 
		if fullqueued[ply] then 
			log("player is fullqueued! %s, %s", fullqueued[ply][1], fullqueued[ply][2])
			ply:NI(fullqueued[ply][1], fullqueued[ply][2])

			fullqueued[ply] = nil
			queued[ply] = {}
		else
			log("player has queued items")
			ply:NetworkItems(queued[ply])
			queued[ply] = {}
		end
	end)

end

QNI = Inventory.QueueForNetworking 

local sqlq = {}

function Inventory.QueueForSQL(query, key)
	sqlq[key] = query
end

local SQLQ = Inventory.QueueForSQL

Inventory = Inventory or {}

local PLAYER = FindMetaTable("Player")

--[[

	Player: Player to give the item to
	ID: Can be a string(internal name) or ItemID

	[Info]: Contains Perma data

	[Callback]: Called with two arguments:
		Item: Item that was passed
		New: If the item is a newly created one(For example, if this item stacked with an another one then it'll be false)
		[Amt]: If this item is old and was stacked in, this is the amount
]]

local inv_writes = {
	["ply_tempinv"] = function(mt) mt:ToTemporary(mt:GetOwner()) end,
	["ply_vault"] = function(mt) mt:ToVault(mt:GetOwner()) end,

	["ply_perma"] = function(mt) mt:ToPerma(mt:GetOwner()) end, --blergh
	["ply_permainv"] = function(mt) mt:ToPerma(mt:GetOwner()) end,
}
local function CreateItem(base, id, puid, isstk, info, cb, where, tabname)
	local smeta = base.specialMeta

	local smt = (istable(smeta) and smeta) or (isstring(smeta) and _G[smeta]) or itemmeta

	local ply, sid = sql.GetByPUID(puid, true)
	if not IsPlayer(ply) then ply = nil end --make matters simpler

	local mt

	local isprm = not isstk

	if smt.Recreate then 
		mt = smt:Recreate(id, (isprm and info) or nil, (isstk and info) or nil, puid)
	elseif smt.new then 
		mt = smt:new(id, (isprm and info) or nil, (isstk and info) or nil, puid)
	else
		mt = itemmeta:new(id, (isprm and info) or nil, (isstk and info) or nil, puid)
	end

	mt.Owner = ply 
	mt.Unknown = true

	mt:SetBelongs(where)
	mt:SetBelongsID(where:GetID())

	mt:Ready()

	mt.ItemID = id 

	log("called createitem and id is %d", id)
	mt:Write(function(uid)

		if bit.GetLen(uid) > Inventory.UIDConstant then
			Inventory.UIDConstant = math.max(Inventory.UIDConstant, bit.GetLen(uid))
			Inventory.SendConsts(player.GetAll(), true)
		end

		where[uid] = mt

		log("written, tabname is %s", tabname)

		if tabname then 
			if inv_writes[tabname] then 
				inv_writes[tabname](mt) 
			else 
				log("Attempted to write to unknown table name! (%s)", tabname)
			end 
		end

		cb(mt, true)

		if ply then QNI(ply) end
	end)


	return mt, true
end

--[[
	correct usage:
	me:GiveItem("blank_bp", {Amount = 50}, nil, me.Inventory.Temp, "ply_tempinv")
]]
function Inventory.CreateItem(ply, id, info, cb, where, tabname)

	local puid = sql.GetPUID(ply)
	if not puid then log("Item creation: invalid player or their PUID was not found!\nPlayer: %s\nPUID: %s", ply, puid) return false end 

	id = Inventory.StringToID[id] or tonumber(id) or id
	if not isnumber(id) then log("Item creation: ItemID does not exist! %s", id) return false end
	--[[
		Attempt to find an item with this ID
	]]

	local it = Items[id]
	local oldID = id 

	if not it then 
		log('Attempted to create a non-existent item! (ItemID: %s)', oldID) 
		return false
	end

	cb = cb or function() end
	
	local where = where or (log("where table not specified! the fuck do i know where do i check for stackables?") or {})
	--[[
		Get item properties
	]]

	local stk = it.stackable 	--stk = item is stackable

	local FoundStack = false 	--found item to stack to : UID
	local NewAmount		 		--only if found stack : new item's amount

	local perma
	local amt

	if info then 
		amt = info.Amount
		perma = info.Perma or (not amt and info) or nil
	end


	if stk then 

		if not amt then amt = 1 end 

		local max = it.maxStack or 50

		for k,v in pairs(where) do 
			if v.ItemID ~= id then continue end 

			local curamt = v.ItemAmount

			if curamt + amt > max then 	--size will exceed maxstack, but try to stack what you can stack in
				
				local can = max - curamt 	--how much can you stack in?
				if can<=0 then continue end --bail dude
				
				if v.CanStack then 	--will the item allow stacking?
					local ok = v:CanStack(can, perma)
					if ok == false then continue end --find an another item 
				end

				amt = amt - can		--remains to be inserted into an another stack or into a new item
				v:SetAmount(curamt + can, perma) 	--actually stack it in
				cb(v, false, can)

				continue
			else 	--size wont exceed maxstack, drop the last ones in

				if v.CanStack then 	--will the item allow stacking?
					local ok = v:CanStack(amt)
					if ok == false then continue end --find an another item 
				end

				v:SetAmount(v:GetAmount() + amt, perma)

				FoundStack = v
				NewAmount = v.ItemAmount
			end
		end

	end


	if not FoundStack then --Item isn't stackable(unique) OR it didnt find where to stack: create a new item either way

		if not amt then --item is unique

			local mt = CreateItem(it, id, puid, false, perma, cb, where, tabname)	

			return mt
		end

		local ret = UnionTable()

		while (amt and amt>0) do 	--item is stackable; create as many new items as needed and return a union
			local stkq = "amt"
			
			local tostack = math.min(it.maxStack or 50, amt)

			local mt = CreateItem(it, id, puid, true, tostack, cb, where, tabname)

			amt = amt - tostack

			ret[#ret + 1] = mt
		end

		return ret 
		
	elseif stk and FoundStack then --it was stackable AND it found where to stack it; update the existing item with a new amount

		FoundStack:SetAmount(NewAmount)
		cb(FoundStack, false)

		return FoundStack, false
	end

end

PLAYER.AddItem = Inventory.CreateItem
PLAYER.GiveItem = Inventory.CreateItem
PLAYER.CreateItem = Inventory.CreateItem

function Inventory.AddToTemp(ply, id, info, callback)

	local cb = function(item, is_new)

		if not is_new then return end

		local uid = item:GetUID()

		if callback then callback(item, uid) end

		item:Network()
	end

	Inventory.CreateItem(ply, id, info, cb, ply.Inventory.Temp, "ply_tempinv")
end

function Inventory.RemoveItem(ply, uid)
	local puid = (isstring(ply) and ply) or sql.GetPUID(ply) 

	if not puid then print("no puid >:(((") return end 
	if not uid then error("Can't delete a non-existent item!") return end
	
	local item, where = ply:HasItem(uid)
	if not item then error('ply didnt have item ' .. uid) return end 

	local sqlname = sqlinvs[where]

	local str = "DELETE FROM `%s` WHERE uid = %s AND puid = %s; DELETE FROM `items` WHERE uid = %s"	--requires immediate update
	str = str:format(sqlname, uid, puid, uid)

	local q = DB:query(str)
	q.onError = Inventory.SQLErr

	q:start()

	item:GetBelongs()[item:GetUID()] = ITEM_DELETED

	QNI(ply, false, true)
end

Inventory.DeleteItem = Inventory.RemoveItem
PLAYER.RemoveItem = Inventory.RemoveItem
PLAYER.DeleteItem = Inventory.RemoveItem

function PLAYER:DeleteInventory(sure)
	if not sure then error("Call with argument = true to erase the player's inventory.") return end 
	for k,v in pairs(self.Inventory) do 
		for uid, it in pairs(v) do 
			it:Delete()
		end 
	end
end
--[[
	Take away an amount from an item.
	Args:
		uid OR item - Item to take away from.
		ply - Player to take away from. Not required if the first argument is an item.
		amt - Amount to take away.
		req - true/false : Does the item need to have that amt?

	Returns:
		If req and failed to take: returns false.
		Otherwise, returns the amount left to take(can be 0)
]]

function Inventory.TakeItem(uid, ply, amt, req)	

	local puid = (isstring(ply) and ply) or sql.GetPUID(ply) 
	if not puid then return end 

	local it = (IsItem(uid) and uid) or ply:HasItem(uid)
	if not it or not it.ItemAmount then error('ply didnt have item or it was unstackable ' .. uid) return false end 

	local has = it.ItemAmount

	if has < amt and req then return false end

	if has <= amt then 
		del = true 
		it:Delete()

		return amt - has

	elseif has > amt then 

		it:SetAmount(has-amt)

		return 0
	end

	
end

local plymetatakeitem = function(ply, uid, amt, req)
	return Inventory.TakeItem(uid, ply, amt, req)
end

PLAYER.TakeItem = plymetatakeitem
PLAYER.TakeItemAmount = plymetatakeitem


function Inventory.SetPermaStat(ply, uid, stat, val, ignoreuid)
	local puid = (isstring(ply) and ply) or sql.GetPUID(ply) 
	if not puid then return end 

	local item = ply:HasItem(uid)

	if not item and not ignoreuid then print('setpermastat: item', uid, ' doesnt exist') return end

	if not item.perma then print('setpermastat: item', uid, ' doesnt have perma') return end 

	local prm = item.perma
	prm[stat] = val --modifies the original table as well

	local q = [[UPDATE items SET perma = JSON_SET(IFNULL(perma, "{}"), "$.%s", "%s") WHERE uid = %s]]
	q = q:format(DB:escape(stat), DB:escape(val), uid)

	local q = DB:query(q)

	q.onError = LogSQLError

	q:start()
end

function PLAYER:GetInventory(num)
	local key = invs[num]
	return key and self.Inventory[key] or false 
end

function Inventory.ExistsItem(ply, uid)
	local inv = ply.Inventory 
	if not inv then return false end 

	for k,v in pairs(inv) do 
		if v[uid] then 
			return v[uid], v:GetID()
		end 
	end

	return false
end

PLAYER.HasItem = Inventory.ExistsItem
PLAYER.GetItem = Inventory.ExistsItem

--[[
	Add an amount to an item.
	Args:
		uid OR item - Item to take away from.
		ply - Player to take away from. Not required if the first argument is an item.
		amt - Amount to take away.

	Returns:
		Returns the amount left to add (can be 0)
]]

function Inventory.AddItem(uid, ply, amt)

	local ply = ply or (IsItem(uid) and uid:GetOwner())

	local it = (IsItem(uid) and uid) or ply:HasItem(uid)

	if not it or not it.ItemAmount then 
		log("ply didn't have item or it was unstackable:\nuid: %s\nitem? %s", uid, IsItem(it))

		if it then 
			log("stackable? %s", it:IsStackable())
		end

		return false 
	end 

	local has = it:GetAmount()
	local max = it:GetItem().maxStack or 50
	if has>=max then log('Item %s has more than max(%d, %d)', it, has, max) return amt end 

	local can = math.min(max - has, amt)

	it:SetAmount(has+can)

	if ply then QNI(ply) end

	return amt - can
end


function Inventory.StopNetworking(ply)
	if ply then DontNetwork[ply] = true return end
	DontNetworkAll = true
end

StopInvNetworking = Inventory.StopNetworking
PLAYER.StopInvNet = Inventory.StopNetworking
PLAYER.StopInventoryNet = Inventory.StopNetworking
PLAYER.StopInventoryNetworking = Inventory.StopNetworking

function Inventory.ResumeNetworking(ply)
	if ply then DontNetwork[ply] = nil return end
	DontNetworkAll = false
end

ResumeInvNetworking = Inventory.ResumeNetworking
PLAYER.ResumeInvNet = Inventory.ResumeNetworking
PLAYER.ResumeInventoryNet = Inventory.ResumeNetworking
PLAYER.ResumeInventoryNetworking = Inventory.ResumeNetworking


function Inventory.RecreateItem(tbl)
	local iid = tonumber(tbl.iid)
	local i = tbl.perma 
	local pu = tonumber(tbl.puid)
	local uid = tonumber(tbl.uid)
	local amt = tonumber(tbl.amt) 

	local it = Items[iid]

	if not it then 
		PrintTable(tbl)
		error("Failed to get item with IID " .. tostring(iid)) 
		return 
	end 

	local smeta = it.specialMeta
	local meta = (istable(smeta) and smeta) or (isstring(smeta) and _G[smeta]) or itemmeta

	local perma = (i and util.JSONToTable(i)) or {}

	local it

	if meta.Recreate then 
		it = meta:Recreate(iid, perma, amt, pu)
	else 
		it = meta:new(iid, perma, amt, pu)
	end

	if not it.SetUID then 
		_META = meta 
	end

	it:SetUID(uid)

	it.Unknown = true
	
	return uid, it
end

local function FetchFromInv(ply, name, cb, finalcb)
	local pu = ply:GetUID()
	if not pu then return end 


	local q = [[SELECT * FROM %s inv
LEFT JOIN items its 
ON inv.uid = its.uid
WHERE inv.puid = %s AND its.iid IN (SELECT iid FROM itemids)]]
					--if there's an entry with an itemID that doesn't exist you don't need it anyways
	q = q:format(name, pu)

	q = DB:query(q)

	q.onSuccess = function(self, t)
		for k,v in pairs(t) do 
			cb(v)
		end
		if finalcb then finalcb(ply) end
	end

	q.onError = LogSQLError

	q:start()

end

local function RecreateAndInsert(ply, data, where)
	local uid, it = Inventory.RecreateItem(data)

	if not IsItem(it) then
		log("[col=230, 100, 100]ERROR: [col=200,200,200]Item refused to create, couldn't be recreated or doesn't have the item meta.\n	ItemUID: %s, ItemID: %s, Player: \"%s\" (%s)", v.uid, v.id, ply:Nick(), ply:SteamID64()) 
		return 
	end

	it.Owner = ply

	where[uid] = it

	if it.Ready then it:Ready() end

	ply.Items[it:GetUID()] = it
	Inventory.UItems[it:GetUID()] = it

	return it
end

function Inventory.UpdateTempInventory(ply, cb)
	local callback = function(data)
		local it = RecreateAndInsert(ply, data, ply.Inventory.Temp)

		it:SetBelongs(ply.Inventory.Temp)
		it:SetBelongsID(1)

	end	

	FetchFromInv(ply, "ply_tempinv", callback, cb)
end


function Inventory.UpdateVault(ply, cb)

	local callback = function(data)

		local it = RecreateAndInsert(ply, data, ply.Inventory.Vault)

		it:SetBelongs(ply.Inventory.Vault)
		it:SetBelongsID(2)

	end	

	FetchFromInv(ply, "ply_vault", callback, cb)
end


function Inventory.UpdatePermaInventory(ply, cb)

	local callback = function(data)

		local it = RecreateAndInsert(ply, data, ply.Inventory.Perma)

		it:SetBelongs(ply.Inventory.Perma)
		it:SetBelongsID(3)

	end	

	FetchFromInv(ply, "ply_permainv", callback, cb)
end

PLAYER.UpdateInventory = function(self)
	local done = 0 

	local cb = function()
		done = done + 1 
		if done==3 then 
			hook.Run("InventoryFetched", self)
		end
	end

	Inventory.UpdateTempInventory(self, cb)
	Inventory.UpdateVault(self, cb)
	Inventory.UpdatePermaInventory(self, cb)

end

function Inventory.ResetInventory(ply)
	ply.Items = {}

	ply.Inventory = {}
	
	local inv = Inventory.InventoryMeta

	ply.Inventory.Temp = inv(ply, "Backpack", 1, "ply_tempinv")
	ply.Inventory.Vault = inv(ply, "Vault", 2, "ply_vault")
	ply.Inventory.Perma = inv(ply, "Perma", 3, "ply_permainv")

	ply:UpdateInventory()
end

PLAYER.ResetInventory = Inventory.ResetInventory
PLAYER.RefreshInventory = Inventory.ResetInventory
PLAYER.ReloadInventory = Inventory.ResetInventory

hook.Add("PlayerInitialSpawn", "RestoreInv", function(ply)
	Inventory.ResetInventory(ply)
end)

util.AddNetworkString("FetchInventory")

lastknown = lastknown or {}
invCooldowns = {}

net.Receive("FetchInventory", function(len, ply)
	if invCooldowns[ply] and CurTime() - invCooldowns[ply] < 5 then print('nuh-uh') return end

	invCooldowns[ply] = CurTime()
	ply:NI(true)
end)
--[[
	States:
		0: Item deleted
		1: Item moved to...
			0: ...temp
			1: ...vault
			2: ...perma

	ITEM_DELETED = 0
	ITEM_MOVED = 1

	ITEM_TEMP = 0
	ITEM_VAULT = 1
	ITEM_PERMA = 2
	
	ITEM_FULL = 0
	ITEM_CHANGES = 1
]]

local function TempEncode(type, temp, dat)
	net.WriteUInt(type, 4)
	net.WriteUInt(#temp, 16)
	log("written temp head: %d type; %d items", type, #temp)

	for k,v in ipairs(temp) do 
		net.WriteNetStack(v)
		--log("written item: %s\n", v)
	end

	local json

	local compressed = false 
	local uncomp

	if not table.IsEmpty(dat) then 
		json = util.TableToJSON(dat)

		uncomp = json

		if json ~= "[]" then
			local comp = util.Compress(json)
			if #comp < #json then json = comp compressed = true end
		end
	end

	if json then 

		log("sv: writing json: %s, len: %d", (#uncomp < 300 and uncomp) or "(>300 uncompr. chars)", #json)

		net.WriteBool(true)	--has perma?

		net.WriteBool(compressed)

		net.WriteUInt(#json, 16)
		net.WriteData(json, #json)
	else 
		net.WriteBool(false)
	end

end

VaultEncode = TempEncode 
PermaEncode = TempEncode 

local function CompareState(where, uid, v)
	if IsItem(v) then return end 


	local args = (istable(v) and v) or {v}

	local typ = args[1]

	local ns = netstack:new()

	ns:WriteUInt(uid, Inventory.UIDConstant)
	ns:WriteUInt(typ, 2)	--if it's ITEM_DELETE it's enough to just know the UID

	if typ == ITEM_MOVED then
		ns:WriteUInt(args[2], 2)	--1 2 or 3; meaning it moved TO there(see "invs" table in this file)
	end

	where[uid] = nil 

	return ns
end

function PLAYER:NetworkInventory(full, delitem)
	

	if DontNetwork[self] or DontNetworkAll then 
		local str = "-- Not networking inventory %sas DontNetwork%s is enabled --\n"
		str = str:format((DontNetwork[self] and ("to " .. self:Nick().." ")) or "", (DontNetworkAll and "All") or "[ply]" )
		MsgC(Color(50, 150, 250), str) 
		return 
	end

	local typ = (full and "full") or "changes"
	local typnum = full and ITEM_FULL or ITEM_CHANGES 

	local states = {}

	local temp = {}
	local tempdat = {}

	local vault = {}
	local vaultdat = {}

	local perma = {}
	local permadat = {}

	--[[
		Collect all states from inventories first
	]]

	for _, inv in pairs(self.Inventory) do 				--Check if any of the items' states changed before encoding items,
		for uid, item in pairs(inv) do 					--to prevent networking an item unnecessarily (e.g. moved from temp to vault doesn't require re-networking the item data)
			states[uid] = CompareState(inv, uid, item)	--CompareState will automatically remove the state entry from the table.
		end
	end

	--[[
		Fill in the tables with netstacks containing item data
	]]

		for k,v in pairs(self.Inventory.Temp) do

			if states[k] then continue end 

			local ns, tab = v:Encode(typ)	--tab = additional data as a table which will be appended
			if not ns then continue end

			temp[#temp + 1] = ns

			if tab then
				tempdat[#temp] = tab 
				print("put one at", #temp, v:GetUID())
			end
		end

		-----------------


		for k,v in pairs(self.Inventory.Vault) do

			if states[k] then continue end 

			local ns, tab = v:Encode(typ)	--tab = additional data as a table which will be appended
			if not ns then continue end

			vault[#vault + 1] = ns

			if tab then
				vaultdat[#vault] = tab 
			end
		end

		-----------------

		for k,v in pairs(self.Inventory.Perma) do

			if states[k] then continue end 

			local ns, tab = v:Encode(typ)	--tab = additional data as a table which will be appended
			if not ns then continue end

			perma[#perma + 1] = ns

			if tab then
				permadat[#perma] = tab 
			end
		end

	net.Start("FetchInventory")

		log("writing %d items in temp", #temp)

		net.WriteBool(full)	--true = client erases all data clientside

		if #temp > 0 then 
			net.WriteBool(true)
			TempEncode(typnum, temp, tempdat)
		else 
			net.WriteBool(false)
		end

		log("has vault? %s %d", #vault > 0, #vault)

		if #vault > 0 then 
			net.WriteBool(true)
			VaultEncode(typnum, vault, vaultdat)
		else 
			net.WriteBool(false)
		end

		log("has perma? %s %d", #perma > 0, #perma)

		if #perma > 0 then 
			net.WriteBool(true)
			PermaEncode(typnum, perma, permadat)
		else 
			net.WriteBool(false)
		end

		if not table.IsEmpty(states) then 
			log("writing %d state changes", table.Count(states))
			net.WriteBool(true)
			net.WriteUInt(table.Count(states), 16)

			for k, v in pairs(states) do 
				net.WriteNetStack(v)
			end

		else 
			net.WriteBool(false)
		end

		net.WriteUInt(0xd1, 8)
		
		log("Server wrote bytes: %d", (net.BytesWritten()))
	net.Send(self)

end

PLAYER.NI = PLAYER.NetworkInventory

function PLAYER:NetworkItems(t)
	log("networking items:", table.Count(t))


	local its = {
		Temp = {},
		TempDat = {},

		Vault = {},
		VaultDat = {},

		Perma = {},
		PermaDat = {},
	}


	for k,v in pairs(t) do 
		local ns, dt = v:Encode("changes")
		if not ns then continue end

		local belongs = Inventory.InventoryIDs[v:GetBelongsID()]

		local dat = its[belongs .. "Dat"]
		dat[#dat + 1] = dt

		local t = its[belongs]
		t[#t + 1] = ns
	end

	net.Start("FetchInventory")
		net.WriteBool(false)

		if not table.IsEmpty(its.Temp) then 
			net.WriteBool(true)
			TempEncode(ITEM_CHANGES, its.Temp, its.TempDat)
		else 
			net.WriteBool(false)
		end

		if not table.IsEmpty(its.Vault) then 
			net.WriteBool(true)
			TempEncode(ITEM_CHANGES, its.Vault, its.VaultDat)
		else 
			net.WriteBool(false)
		end

		if not table.IsEmpty(its.Perma) then 
			net.WriteBool(true)
			TempEncode(ITEM_CHANGES, its.Perma, its.PermaDat)
		else 
			net.WriteBool(false)
		end

		net.WriteBool(false)	-- no deletes

		log("Server wrote bytes on manual item update: %d", (net.BytesWritten()))

		net.WriteUInt(0xd1, 8)

	net.Send(self)

end

function PLAYER:ClearInventory()
	for k,v in pairs(self.Inventory) do 
		v:Delete()
	end

end

function PLAYER:ResyncInventory()
	net.Start("FetchInventory")
		net.WriteUInt(3, 4)
		net.WriteUInt(0, 16)
	net.Send(self)

	self:NI(true)
end
