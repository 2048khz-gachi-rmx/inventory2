--ay
local PLAYER = FindMetaTable("Player")

local function CreateItem(puid, iid, info)	--adds item to SQL
											--takes puid, item id, info (amount as number or perma as table)

	local str = "INSERT INTO p_Inv(puid, id%s) VALUES(%s, %s%s)"

	local column = ""
	local insert = ""

	if Items[iid].stackable then 
		column = ", amt"
		insert = ", " .. info 	--assuming info is number for amount
	elseif info then
		column = ", info"
		insert = ", " .. SQLStr(util.TableToJSON(info))	--assuming info is .perma info
	end

	str = str:format(column, puid, iid, insert)
	
	sql.Check(str)

end

function Inventory.InsertInto(ply, item, meta)
	local puid = ply:GetUID()
	if not puid then error('ply invalid') return end 
	
	local it = item:GetItem()
	CreateItem(puid, item.ItemID, (it.stackable and it.ItemAmount) or item.perma)


	local uid = sql.Check("SELECT seq FROM sqlite_sequence WHERE name=='p_Inv'", true)
	uid = tonumber(uid[1]['seq'])
	item.ItemUID = uid 
	item.ItemInfo = item.ItemInfo or Items[item.ItemID]
	
	if not item.GetID then 
		setmetatable(item, (meta or itemmeta) or {})
		if not item.GetID then
			PrintTable(item) 
			error("no GetID method for item") 
			return
		end
	end 

	ply.Inventory[uid] = item

	return item
end

function Inventory.EnoughItem(ply, id, amt)

	local has = 0
	if isstring(id) then id = Inventory.StringToID[id] end 

	for k,v in pairs(ply.Inventory) do 
		if v.ItemID==id then 
			has = has + (v:GetAmount() or 1)
		end
	end

	return amt <= has, has
end

PLAYER.EnoughItem = Inventory.EnoughItem

function Inventory.SubItem(ply, id, amt)
	local its = {}
	local left = amt 

	for k,v in pairs(ply.Inventory) do 
		if v.ItemID == id then 
			its[#its + 1] = v
		end
	end 

	table.sort(its, function(a, b)
		return a:GetAmount() < b:GetAmount()
	end)
	for k,v in ipairs(its) do 
		left = v:TakeAmount(left)
		if left<=0 then break end 
	end

	return left
end



local gunstats = {
	["acc"] = function(wep, a)
		if wep.CW20Weapon then 
			wep.HipSpreadMult = wep.HipSpreadMult * (1 - a)
			wep.AimSpreadMult = wep.AimSpreadMult * (1 - a)
			return wep.AimSpreadMult
		end
	end,
	["rec"] = function(wep, a)
		if wep.CW20Weapon then 
			wep.RecoilMult = wep.RecoilMult * (1 - a)
			return wep.RecoilMult
		end 
	end,

	["dmg"] = function(wep, a)
		if wep.CW20Weapon then 
			wep.DamageMult = wep.DamageMult * (1 + a)
			return wep.DamageMult
		end 
	end,

	["fr"] = function(wep, a)
		if wep.CW20Weapon then 
			wep.FireDelayMult = wep.FireDelayMult * (1 - a)
			return wep.FireDelayMult
		end 
	end,

}


util.AddNetworkString("ApplyWepStats")
function Inventory.GiveGun(item, ply)
	local it = Items[item:GetID()]

	local class = it.Class 
	local perma = item.perma 

	local nwstats = {}

	if not weapons.Get(class) then print('lolno such gun', class) return end 
	local wep = ply:Give(class)
	if perma.stats then 
		for k,v in pairs(perma.stats) do 
			if gunstats[k] then 
				nwstats[k] = gunstats[k](wep, (v - 100) / 100 )	--e.g. 126 -> 26 -> 0.26
			end

		end 
	end
	if wep.CW20Weapon and wep.recalculateStats then 
		wep:recalculateStats()
	end
	timer.Simple(0, function()
		net.Start("ApplyWepStats")
			net.WriteString(util.TableToJSON(nwstats))
			net.WriteUInt(wep:EntIndex(), 32)
		net.Send(ply)
	end)
end