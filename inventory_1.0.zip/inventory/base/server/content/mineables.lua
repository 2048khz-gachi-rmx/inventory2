
local Mineable = Inventory.Mineable

	Mineable("copper_ore")
		:SetAppearChance(25)
		:SetMineChance(60)
		:SetWasteChance(12)
		:SetRichness(20, 70)
		:AddAlloy(
			3, 				--With
			"bronze_ore", 	--Makes
			{2, 1},			--Ratio (self : with)
			3)				--Amt it makes
		:Add()
	
	Mineable("silver_ore")
		:SetAppearChance(14)
		:SetMineChance(40)
		:SetWasteChance(88)
		:SetRichness(10, 20)
		:Add()

	Mineable("tin_ore")
		:SetAppearChance(35)
		:SetMineChance(40)
		:SetWasteChance(88)
		:SetRichness(40, 60)
		:Add()

	Mineable("tin_ore")
		:SetAppearChance(35)
		:SetMineChance(75)
		:SetWasteChance(90)
		:SetRichness(40, 60)
		:Add()

	Mineable("lead_ore")
		:SetAppearChance(23) 
		:SetRichness({15, 40})
		:SetMineChance(35)
		:SetWasteChance(60)
		:Add()

	Mineable("gold_ore")
		:SetAppearChance(7) 
		:SetRichness({7, 13})
		:SetMineChance(55)
		:SetWasteChance(85)
		:Add()

	Mineable("alum_ore")
		:SetAppearChance(35) 
		:SetRichness({40, 60})
		:SetMineChance(80)
		:SetWasteChance(80)
		:Add()

	Mineable("sulfur_ore")
		:SetAppearChance(20) 
		:SetRichness({40, 80})
		:SetMineChance(90)
		:SetWasteChance(90)
		:AddIncompat("tin_ore", 2)
		:Add()



--(\w+)\s=\s(\w+),