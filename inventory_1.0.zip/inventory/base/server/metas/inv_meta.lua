
function invobj:Add(id, info, cb)
	local ply = self:GetOwner()

	local it = ply:GiveItem(id, info, cb or BlankFunc, self, self:GetSQLName())	--Ideally, this should handle inserting the item by itself

end

invobj.AddItem = invobj.Add