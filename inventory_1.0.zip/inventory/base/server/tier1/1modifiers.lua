--a

Inventory.Modifiers = Inventory.Modifiers or {}

--[[

	tbl.chance 
	
	Chance:
		If you're changing chance, change it like a multiplier.
		1 = same chance as others,
		0.5 = twice as rare as others,
		4 = 4x more frequent than others.
]]

Inventory.Modifiers[1] = {
	ID = 1,
	Name = "Poisonous",
	eff = {1, 5},
}

Inventory.Modifiers[2] = {
	ID = 2,
	Name = "Fiery",
	eff = {1, 5},
}

Inventory.Modifiers[3] = {
	ID = 3,
	Name = "Leeching",
	eff = {1, 3},
}
