local Mineable = BaseItem:Callable()

Inventory.Mineable = Mineable 

ChainAccessor(Mineable, "AppearChance", "AppearChance")

function Mineable:Initialize(name)
	self.Name = name
end

function Mineable:SetRichness(min, max)
	self.Richness = {min, max}
	return self
end

ChainAccessor(Mineable, "MineChance", "MineChance")
ChainAccessor(Mineable, "WasteChance", "WasteChance")

function Mineable:AddIncompat(with, prio)
	local ic = self.Incompatible or {}
	self.Incompatible = ic

	ic[#ic + 1] = {with = with, remove = prio}

	return self
end

function Mineable:AddAlloy(with, result, ratio, amt_made, frac)
	local ic = self.Incompatible or {}
	self.Incompatible = ic

	ic[#ic + 1] = {with = with, makes = result, ratio = ratio, amt = amt_made, frac = frac}

	return self
end

Mineable.AddIncompatibility = Mineable.AddIncompat


function Mineable:Add()
	Inventory.Ores[self.Name] = self 
	return self
end


include("inventory/base/server/content/mineables.lua")