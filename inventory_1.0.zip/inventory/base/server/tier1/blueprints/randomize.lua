
function blueprintMeta:RandomizeMods(wep, info)

	local mods = {}
	local stats = {}
	print("randomizing!")
	if info.ModChances then
		print("random mods!")
		local modspool = {}
		local componly = wep.mods_compat 
		local incomp = wep.mods_incompat

		local function AddToPool(k, v)
			if v.chance then 
				local int, fr = math.modf(v.chance, 1)
				for i=1, int do 
					modspool[#modspool + 1] = v 
				end

				if fr~=0 and fr then 
					fr = fr * 100 
					local rand = math.Rand(0, 100)
					if rand <= fr then 
						modspool[#modspool + 1] = v 
					end 
				end
			else 
				modspool[#modspool + 1] = v 
			end
		end

		for k,v in RandomPairs(Inventory.Modifiers) do 
			if componly then 
				if not componly[k] then continue end 
				AddToPool(k, v)
				continue 
			end
			if incomp and incomp[k] then continue end 
			AddToPool(k, v)
		end

		
		local modcount = 0

		local modChances = info.ModChances

		info.ModChances = nil

		if modChances then 
			local getmods = 0

			for i=1, #modChances do 
				local chance = modChances[i]
				if math.Rand(0, 100) < chance then 
					getmods = getmods + 1 
				else 
					break 
				end
			end


			for i=1, getmods do 

				if #modspool == 0 then return end 

				local key = math.random(#modspool) 
				local mod = modspool[key]
				local wmod = {}

				if mod.eff then 
					wmod.eff = math.random(mod.eff[1], mod.eff[2])
				end

				wmod.ID = mod.ID 

				mods[i] = wmod

				table.remove(modspool, key)
			end

		end

	end

	--[[
		
		Randomizing weapon stats

	]]

	if info.RandomStats then
		print("random stats!")
		if wep.permastats then 

			for k,stat in pairs(wep.permastats) do 
				local name = stat.stat 
				local typ = stat.type 

				if typ=="rand" then 
					stats[name] = math.random(stat[1], stat[2])
				end

			end

		end

	end

	return stats, mods
end