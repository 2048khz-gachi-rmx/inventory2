Inventory.Blueprints = Inventory.Blueprints or {}

blueprint = item:Extend()
blueprintMeta = blueprint.Meta

blueprintMeta.IsBluePrint = true
blueprintMeta.IsBlueprint = true

AnalyzeStation = "workbench2"

function blueprintMeta:GetName()
	return Inventory.GunClasses[self:GetCraftsTo()] or "L_ L_ L_ "
end

function blueprintMeta:GetCraftsTo()
	return self.perma.CraftsInto
end
--[[
function blueprintMeta:new(ply, wep, info)
	local it = item:new("blueprint", {}, nil, ply)
	setmetatable(it, self)

	it:Initialize(ply, wep, info)
end
]]

function blueprintMeta:Initialize(ply, wepclass, info)	--"info" is a table to merge into "perma"

	local bp = self

	bp.Owner = ply 
	bp.perma = {}
	bp.ItemID = Inventory.StringToID["blueprint"]

	local wep = Inventory.GunClasses[wepclass]  
	if not wep then error("No such gun exists! " .. tostring(wepclass)) return end
	
	local stats, mods 

	local prm = {analyzed = false, CraftsInto = wepclass}

	if info then 
		for k,v in pairs(info) do 
			prm[k] = v
		end 
	end

	for k,v in pairs(prm) do
		bp.perma[k] = v 
	end

	_G.bp = bp

	if not ply or not IsValid(ply) then 
		ErrorNoHalt("no player btw; this blueprint is for testing only! check global 'bp'\n")
	end

	item.Changes = {}

end

function blueprintMeta:Recreate(id, perma, amt, puid)
	local ply = ( isnumber(puid) and (sql.GetByPUID(puid, true)) ) or puid

	local bp = blueprint:new(ply, perma.CraftsInto, perma)

	_BP = bp

	local an = perma.analyzed 

	if not an then 
		bp.OverrideNetwork = {mods = {}, stats = {}}

		local on = bp.OverrideNetwork

		if bp.perma.mods then
			for k,v in pairs(bp.perma.mods) do 
				on.mods[k] = true 
			end
		end

		if bp.perma.stats then
			for k,v in pairs(bp.perma.stats) do 
				on.stats[k] = "?"
			end
		end

	end

	return bp
end

local analyzing = {}

function blueprintMeta:Analyze(ent)
	if (not ent or not IsValid(ent) or ent:GetClass() ~= AnalyzeStation or (self:GetOwner():GetPos():Distance(ent:GetPos()) > 192)) then return end 

	self:SetPermaStat("analyzed", true)

	self.OverrideNetwork = nil 
	self.DontNetwork = nil

	self:Network()
end

function blueprintMeta:GetGun(ig) 	--ignore analyzed/not analyzed
	if not self:GetPermaStat("analyzed") and not ig then return false end 

	local gun = self:GetPermaStat("CraftsInto", false)
	if not gun then return end
	
	local gunconfig = Inventory.GunClasses[gun]

	local guntbl = Items[gunconfig.ID]

	local ret = {}
	ret.ItemID = gun 
	ret.Owner = self:GetOwner()
	local mods = self:GetPermaStat("mods")
	ret.perma = {
		mods = mods,
		stats = (self:GetPermaStat("stats") or {}),
		uses = (guntbl.perma and guntbl.perma.uses) or (guntbl.uses) or (50 and ErrorNoHalt("missing uses in guntbl " .. tostring(gun)))
	}

	return ret
end

--[[

	info = {
		ModChances = {
			chance in %,
			chance in % (for a second mod),
			etc...
		},

		RandomStats = true/false/nil - takes possible stats from the weapon config
	}

]]
function blueprintMeta:MakeStats(info)
	local gun = self:GetPermaStat("CraftsInto")
	local guncfg = Inventory.GunClasses[gun]

	local stats, mods = self:RandomizeMods(guncfg, info)

	self.perma["mods"] = mods
	self.perma["stats"] = stats
end

util.AddNetworkString("Analyze")

net.Receive("Analyze", function(_, ply)
	local uid = net.ReadUInt(32)
	local ent = net.ReadEntity()

	local it = ply:HasItem(uid)
	if not it then return end 

	if it.ItemID ~= 100000 then return end
	if analyzing[uid] then return end 
	--if it.perma and it.perma.analyzed == true then return end 
	if ply.AnalyzingBlueprint then return end 

	ply.AnalyzingBlueprint = true 
	analyzing[uid] = true 


	timer.Simple(1, function()
		if not IsValid(ply) or not ply:HasItem(uid) or not ent or not IsValid(ent) or ent:GetClass()~=AnalyzeStation or (ply:GetPos():Distance(ent:GetPos()) > 192) then return end
		if not it then print("not valid item???") return end 

		it:Analyze(ent)

		analyzing[uid] = false
		ply.AnalyzingBlueprint = false 
	end)

end)

function Inventory.TurnToBlueprints(tbl)

	for k,v in pairs(tbl) do 
		Inventory.Blueprints[v.Class] = {id = k}
		table.Merge(Inventory.Blueprints[v.Class], v)
	end

end

function Inventory.CreateBlueprint(ply, wep, perma, mods)
	local w = weapons.Get(wep)

	if not w then error("No such weapon exists! " .. wep) return end
	if not Inventory.GunClasses[wep] then error("No such weapon in inventory exists! " .. wep) return end 
	if not IsPlayer(ply) then error("Not a player! " .. tostring(ply)) return end 

	local bp = blueprintMeta:new(ply, wep, perma)

	if mods then 
		bp:MakeStats(mods)
	end

	return bp
end


function Inventory.ApplyDamage(gun, perc)
	if gun.Base and gun.Base:find("tfa_") then 

		local tfa = gun.Primary_TFA
		if tfa.Damage then 
			tfa.Damage = (tfa.Damage or 0) * (1+perc/100) 
		end
		if tfa.Attacks then 
			for k,v in pairs(tfa.Attacks) do 
				v.dmg = (v.dmg or 0) * (1+perc/100)
			end
		end

	end
	if gun.Base and gun.Base:find("cw_") then 
		if gun.Damage_Orig then 
			gun.Damage_Orig = gun.Damage_Orig * (1+perc/100)
		end	
	end
end