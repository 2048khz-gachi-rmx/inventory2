--placeholder

function EquipmentMeta:GetEffects()
	return self.perma.Effects
end

local shrtfx = {}

--[[
	Effects structure:
	Item = {
		ItemID = ...,
		ItemUID = ...,
		Effects = {
			[1] = {		//1 = effect ID for flames for example
				custom data
				i guess effects needs to be an object too
				to encode data efficiently?
			}
		}
	}
]]

local shrt = {
	ItemID = "i",
	Effects = "f",
	ItemUID = "u",
}

local valmod = {
	["Effects"] = function(t)
		for k,v in pairs(t) do 
			if shrtfx[k] then t[k] = shrtfx[k] end 
		end
	end
}

local function EncodeData(t)	--modifies original table

	for k,v in pairs(t) do 
		if shrt[k] then
			t[shrt[k]] = eval(valmod[k], v) or v
			t[k] = nil
		end
	end

end

function EquipmentMeta:GetNetwork()
	local ret = {}

	local iid = self:GetItemID()
	local fx = self:GetEffects()

	ret.ItemID = iid 
	ret.Effects = fx 

	EncodeData(ret)
	return ret
end