--placeholder

local PLAYER = FindMetaTable("Player")

local log = Inventory.EquipmentLog

function PLAYER:UpdateEquipment(str)
	

end

function PLAYER:GetEquipmentSlot(str)

	if not Equipment.Slots[str] then 
		print("Attempt to get non-existing equipment slot:", str)
		return false 
	end

	if not self.Equipment[str] then 
		return false --???
	end

end

function PLAYER:UnequipItem(uid, slot)

	local puid = self:GetUID()
	if not puid then log("no PUID!") return false end 

	local slotname = (isstring(slot) and slot) or Equipment.SlotIDs[slot].key 

	if not slotname then log("no slotname! player %s, '%s'", self, slot) return false end 

	if not self.Equipment[slotname] then log("player %s had nothing equipped in slot '%s'", self, slotname) return false end

	local it = self:HasItem(uid)
	if not it then log("no item! player %s, uid: %d", self, uid) return false end 

	Equipment.SQLUnequip(self, slot, it)
end

function PLAYER:EquipItem(uid)

	local puid = self:GetUID()
	if not puid then return end 

	local it, where = self:HasItem(uid)
	if not it or where ~= 3 then return false end --equippables MUST be in perma inventory

	local eq = it:GetSlot()
	if not eq then print("no slot?") return false end 


	if self.Equipment[eq] == it then log("player %s attempted to reequip an equipped item", self) return false end

	local query = "UPDATE `ply_equipment` SET `%s` = %s WHERE `puid` = %s"

	query = query:format(eq, uid, puid)

	local q = eqDB:query(query)

		q.onError = function(_, err)
			local errstr = "[color=230, 100, 100]Failed to equip item for player!\n 	Player: %s(%s)\n 	ItemUID: %s\n 	Query: ' %s '\n 	Err: %s"
			errstr = errstr:format(self:Nick(), self:SteamID(), uid, query, err)
			log(errstr)
		end

		q.onSuccess = function(_, data)
			self.Equipment[eq] = it
			self:SendEquipment()

			--local item = it:GetItem()

			--if item.OnEquip then 
			--	item.OnEquip(it)
			--end

			if it.OnEquip then 			--if the item has an OnEquip method, use that
				it:OnEquip()
			elseif item.OnEquip then 	--otherwise if its' base item has an OnEquip method, use that
				item.OnEquip(it)		--call base's OnEquip from item meta if you need them both
			end

		end

	q:start()

	

end

function EquipmentPlayerAuth(ply)
	if not eqDB then print("no equipment DB", debug.traceback()) return end 
	local sid64 = ply:SteamID64()

	local uid = sql.GetPUID(sid64)
	ply.Equipment = {}

	Equipment.GetPlayerEquipment(ply, uid)
	
end

function EquipmentPlayerNetwork(ply)
	local plys = {}

	local its_temp = {}

	local its_net = {}

	for k, ply in ipairs(player.GetAll()) do 
		if not ply.Equipment or table.IsEmpty(ply.Equipment) then continue end 

		local t = {}
		its_temp[ply:UserID()] = t

		for k,v in pairs(ply.Equipment) do 
			local it = ply:GetItem(v)
			if not it then continue end 

			t[Equipment.GetSlot(k)] = it
		end

	end 

	for k, its in pairs(its_temp) do 

		its_net[k] = {}
		local t = its_net[k]

		for bp, it in pairs(its) do 

			t[bp] = it:GetNetwork() or {
				ItemID = it:GetItemID()
			}

		end


	end

	return its_net
end


util.AddNetworkString("ReceiveItems")

hook.Add("InventoryFetched", "UpdateEquipment", EquipmentPlayerAuth)

hook.Add("PlayerFullyLoaded", "NetworkEqupment", EquipmentPlayerNetwork)