--placeholder

util.AddNetworkString("Equipment")

local neteq = {}

for k,v in pairs(Equipment.Slots) do 
	v.slotname = k
	neteq[v.slot] = v
end
	
net.Receive("Equipment", function(_, ply)
	local eq = net.ReadBool()
	local it = net.ReadUInt(32)
	local slot = net.ReadUInt(8)

	if eq then 
		ply:EquipItem(it, slot)
	else 
		ply:UnequipItem(it, slot)
	end

end)

Inventory.Items = Inventory.Items or {}


local PLAYER = FindMetaTable("Player")

function PLAYER:SendEquipment(slot, who)
	local slots = {}
	if slot then 
		slots[slot] = self.Equipment[slot]
	else 
		slots = self.Equipment 
	end 
	if not slots then return end 
	
	net.Start("Equipment")
		net.WriteUInt(table.Count(slots), 8)

		for k,v in pairs(slots) do 
			print(k)
			net.WriteUInt(Equipment.Slots[k].slot, 8)
			net.WriteUInt((isnumber(v) and v) or v.ItemUID, 32)
		end 

	net.Send(who or self)

end

hook.Add("PlayerFullyLoaded", "EquipmentBroadcast", function(ply)
	ply:SendEquipment(nil, player.GetAll())
end)