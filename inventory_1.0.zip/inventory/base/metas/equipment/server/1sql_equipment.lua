--aey
require("mysqloo")

local schema_name = "equipment"
local table_name = "ply_Equipment"

Equipment = Equipment or {}

eqDB = Inventory.DB--mysqloo.connect("127.0.0.1", "root", "31415", schema_name)

local log = Inventory.EquipmentLog

--[[

eqDB.onConnected = function()
	log("Connected to MySQL [col=80, 220, 80]successfully[col=255,255,255]!")
end 

eqDB.onConnectionFailed = function(d, err) 
	log("Connection to MySQL [col=240, 50, 50]FAILED! Expect errors!")
end

eqDB:connect()
]]

local slots = {
	["head"] = {slot = 1, name = "Head"},
	["body"] = {slot = 2, name = "Body"},
	["back"] = {slot = 3, name = "Back"},
	["legs"] = {slot = 4, name = "Legs"},
	["primary"] = {slot = 5, name = "Primary"},
	["secondary"] = {slot = 6, name = "Secondary"},
	["special"] = {slot = 7, name = "Special"},
	["util"] = {slot = 8, name = "Utility"},
}

Equipment.Slots = slots 

local tablequery = [[CREATE TABLE IF NOT EXISTS ]] .. table_name .. [[ (
	`puid` INT UNSIGNED NOT NULL,
%s);
]]

local slotstr = ""
for k,v in pairs(slots) do 
	local nextexists = (next(slots, k) and ",") or "" --add a "," or don't depending on if its the last column
	slotstr = slotstr .. ("	`%s` INT UNSIGNED NOT NULL%s\n"):format(k, nextexists)
end 

tablequery = tablequery:format(slotstr)

--Results:

--[[

	CREATE TABLE ply_Equipment (
		puid INT UNSIGNED NOT NULL,
		head INT UNSIGNED NOT NULL,
		body INT UNSIGNED NOT NULL,
		...
		util INT UNSIGNED NOT NULL,
	);

]]

local q = eqDB:query(tablequery)

q.onError = function(self, err)

end
q.onSuccess = function(self, data)

end

q:start()

--[[
	Check if slots changed; add more columns if missing and vice versa
]]

local q = eqDB:query("DESCRIBE ply_Equipment")

q.onError = function(self, err)
	print("you fucked up:", err)
	print('query:', tablequery)
end



q.onSuccess = function(self, data)
	local slots = table.Copy(slots)

	for k,v in pairs(data) do 
		if not slots[v.Field] and v.Field ~= "puid" then 
			log(" [col=220, 100, 100]sql_equipment: Missing key in equipment lua table: " .. v.Field  .. " [col=255, 255, 255]")
			continue
		end 
		slots[v.Field] = nil 
	end

	for k,v in pairs(slots) do 
		log(" [col=240, 240, 100]sql_equipment: Missing column in equipment MySQL: " .. k  .. "; [col=100, 200, 100]Creating... [col=255, 255, 255]")

		local q = eqDB:query([[ALTER TABLE `]] .. table_name .. [[` ADD COLUMN `]] .. k .. [[` INT NOT NULL;]])

		q.onSuccess = function(self, data)
			log("Created column `" .. k .. "` [col=80, 220, 80]successfully[col=255,255,255]!")
		end 

		q.onError = function(self, err)
			log("[col=250, 60, 60]Failed creating column `" .. k .. "`! Error:[col=255,255,255]\n" .. err)
		end

		q:start()
	end


end

q:start()

function Equipment.SQLUnequip(ply, slot, it)
	local puid = (isstring(ply) and ply) or sql.GetPUID(ply)
	local ply, sid64 = sql.GetByPUID(puid, true)
	local slotname = (isstring(slot) and slot) or Equipment.SlotIDs[slot].key 

	if not slotname or not puid then 
		errorf("Couldn't get either slotname or PUID! Slotname: %s, PUID: %s, Slot: %s", slotname, puid, slot)
		return 
	end 

	local query = "UPDATE `ply_equipment` SET `%s` = NULL WHERE `puid` = %s;"
	query = query:format(slotname, puid)

	local q = eqDB:query(query)

		q.onError = function(_, err)
			local errstr = "[color=230, 100, 100]Failed to unequip item from player!\n 	Player: %s (%s)\n 	ItemUID: %s\n 	Query: ' %s '\n 	Err: %s"

			errstr = errstr:format(
				ply and ply:Nick() or ("(puid: " .. puid .. ")"),
				sid64,
				uid,
				query,
				err)

			log(errstr)
		end

		q.onSuccess = function(_, data)
			log("unequipped successfully %s %s", ply, it)

			if ply then
				ply.Equipment[slotname] = nil
				ply:SendEquipment(slot)
			end

			if it then 
				local item = it:GetItem()

				if item and item.OnUnequip then 
					item.OnUnequip(it)
				end
			end

		end

	q:start()

end

function Equipment.SQLEquip(ply, puid, slot, uid)
	if not uid then Equipment.SQLUnequip(ply, slot) return end 

end

function Equipment.GetPlayerEquipment(ply, puid)

	local q = eqDB:query("SELECT * FROM `ply_equipment` WHERE `puid` = " .. puid .. ";")

	

	q.onError = function(self, err)
		log("youre a retard %s", err)
	end

	q.onSuccess = function(self, data)

		if table.IsEmpty(data) then

			local q = eqDB:query("INSERT IGNORE INTO `ply_equipment`(puid) VALUES(" .. puid .. ");")

			q.onError = function(self, err)
				log("youre a retard #2 %s", err)
			end
			
			q.onSuccess = function(self, data)
				log("nice #2")
			end

			q:start()

			ply.Equpiment = {}

			return
		end

		local tbl = data[1]

		tbl["puid"] = nil

		for k,v in pairs(tbl) do 
			v = tonumber(v)
			if v==0 then tbl[k] = nil continue end 

			local it, where = ply:HasItem(v)

			if not it or where ~= 3 then 
					log("player %s didn't have item %s or it was not in perma inventory (where reported as %s which isn't 3)\n 	we'll deequip it for now", ply, v, where)

				return 
			end 

			tbl[k] = it
		end
		
		ply.Equipment = tbl
		ply:SendEquipment(nil, player.GetAll())
	end

	q:start()

end