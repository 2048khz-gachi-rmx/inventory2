--aey

Inventory.Equipment = Inventory.Equipment or {}
Inventory.Equipped = Inventory.Equipped or {}

function Equipment.AttemptEquip(it, slot)

	local num = Equipment.Slots[slot]
	if not num then print("didnt find num") return false end 

	local can, err = true, nil

    if it.CanEquip then
        can, err = it:CanEquip()
    end

    if not can then return false, err end 

	num = num.slot 
	
	net.Start("Equipment")
		net.WriteBool(true)
		net.WriteUInt(it.ItemUID, 32)
		net.WriteUInt(num, 8)
	net.SendToServer()

	return true 

end

function Equipment.UnequipItem(it, slot)
	local uid = it.ItemUID

	local num = Equipment.Slots[slot]
	if not num then print("didnt find num") return end 
	num = num.slot 

	Inventory.Equipped[slot] = nil

	net.Start("Equipment")
		net.WriteBool(false)
		net.WriteUInt(uid, 32)
		net.WriteUInt(num, 8)
	net.SendToServer()

end

net.Receive("Equipment", function()
	local amt = net.ReadUInt(8)
	local slots = {}

	for i=1, amt do 
		local num = net.ReadUInt(8)
		local item = net.ReadUInt(32)

		slots[num] = item
	end

	for k,v in pairs(slots) do 
		local slot = Equipment.SlotIDs[k]
		local item

		if v==0 then item = nil else item = Inventory.Items[v] end 
		Inventory.Equipped[slot.key] = item
	end

end)


Inventory.Items = Inventory.Items or {}

net.Receive("ReceiveItems", function(leng)
	local whose = net.ReadEntity()
	whose.Equipment = whose.Equipment or {}

	local amt = net.ReadUInt(16)

	local its = {}

	for i=1, amt do 
		local iid, uid = net.ReadUInt(Inventory.IIDConstant), net.ReadUInt(Inventory.UIDConstant)	--IID:UID pair is constant for ALL items

		local it = {}
		local hasperma = net.ReadBool()

		if not hasperma then 
			it.ItemAmount = net.ReadUInt(16)
		else 
			it.perma = {}
		end

		it.ItemID = iid 
		it.ItemUID = uid
		
		local it = Inventory.ParseItem(it)

		its[#its + 1] = it
	end

	local data = {}

	local hasdat = net.ReadBool()

	if hasdat then 

		local comp = net.ReadBool()

		local len = net.ReadUInt(16)
		local dat = net.ReadData(len)

		printf("%d bytes of %scompressed JSON data", len, (comp and "") or "un")

		if comp then 
			dat = util.Decompress(dat)
		end

		local tbl = util.JSONToTable(dat)
		if not tbl then return end

		for k, v in pairs(tbl) do 
			local json = util.JSONToTable(v)
			data[k] = json
		end

	end

	for k,v in pairs(data) do 

		if its[k] then 
			its[k]:ParsePerma(v) 
		end
	end

	for k,v in pairs(its) do 
		local slot = v:GetSlot()
		whose.Equipment[slot] = v
	end
end)