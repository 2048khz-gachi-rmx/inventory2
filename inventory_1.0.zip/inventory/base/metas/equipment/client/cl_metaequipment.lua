
EquipmentMeta = item:extend()
local EquipmentFuncs = EquipmentMeta.Meta



function EquipmentFuncs:GetSlot()
	return self:GetItem().Slot
end