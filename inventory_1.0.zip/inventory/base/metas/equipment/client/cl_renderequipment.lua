--placeholder


--todo: move to equipment/cl_charpanel.lua

--[[

    Opening full inventory

]]

Equipment.SlotPanels = {
	["head"] = {slot = 1, name = "Head"},
	["body"] = {slot = 2, name = "Body"},
	["back"] = {slot = 3, name = "Back"},
	["legs"] = {slot = 4, name = "Legs"},
	["primary"] = {slot = 5, name = "Primary"},
	["secondary"] = {slot = 6, name = "Secondary"},
	["special"] = {slot = 7, name = "Special"},
	["util"] = {slot = 8, name = "Utility"},
}

local invw, invh = 500, 604 
local charw, charh = 600, 604

Equipment.CSModels = Equipment.CSModels or {}

local function ClearCSModels()

    for uid, item in pairs(Equipment.CSModels) do 
        for k, mdlinfo in pairs(item) do 
            if IsValid(mdlinfo.mdl) then 
                mdlinfo.mdl:Remove()
            end
        end
        Equipment.CSModels[uid] = nil
    end

end

local function ClearCSModel(uid)

    if Equipment.CSModels[uid] then 
        for k, mdlinfo in pairs(Equipment.CSModels[uid]) do 
            if IsValid(mdlinfo.mdl) then 
                mdlinfo.mdl:Remove()
            end
        end

        Equipment.CSModels[uid] = nil

    end

end

for k,v in pairs(Equipment.CSModels) do 
    for k2, v2 in pairs(v) do 
        if v2.mdl and IsValid(v2.mdl) then v2.mdl:Remove() v2.mdl = nil end 
    end 
end 

local vm = Matrix()

function PaintItem(uid, ply, prev)
    local it = Inventory.Items[uid]
    if not it then return end 
    local item = it:GetItem()

    local r = item.Render 
    if not r then return end 

    Equipment.CSModels[uid] = Equipment.CSModels[uid] or {}
    local csm = Equipment.CSModels[uid] --item which has multiple render infoes
    csm.item = item 

    local ppos, pang = ply:GetPos(), ply:GetAngles()
    local ents = {}

    for k,v in pairs(r) do
        if not csm[k] then 
            csm[k] = {}
        end 

        local mdl = v.mdl
        local pos = v.pos or Vector(0, 0, 0)
        local ang = v.ang or Angle(0, 0, 0)
        local bone = v.bone 
        local scale = v.scale
        local func = v.func
        
        local mdlinfo = csm[k]  --render info

        local ent = csm[k].mdl  --the CSModel

        

        if not IsValid(csm[k].mdl) and mdl then 
            csm[k].mdl = ClientsideModel(mdl)
            ent = csm[k].mdl
        end

        if prev then 
            ent:SetNoDraw(true)
        else 
            ent:SetNoDraw(false)
        end

        local bID = ply:LookupBone(bone)
        if not bID then continue end 

        local bpos, bang = ply:GetBonePosition(bID)

        if scale then 
            vm:SetScale(scale)
            ent:EnableMatrix("RenderMultiply", vm)
        end

        ent:SetPos(bpos + pos)
        ent:SetAngles(bang + ang)
        ent:DrawModel()

        ents[#ents+1] = ent
    end
    return ents
end

hook.Add("PostPlayerDraw", "PaintEquipment", function(ply)
    if ply.Equipment then return end
end)

function Inventory.OpenFull()
    local inv = Inventory.CreateFrame(Inventory.Data.Perma)

    inv:SetSize(invw, invh)   
    inv:Center()

    inv:SortItems(function(a, b)
        a, b = a:GetItem(), b:GetItem()

        local eq1, eq2 = a.Equippable, b.Equippable 
        if eq1 and not eq2 then return true end 
        return false
    end, 1)

    

    inv:CreateItems()

    for k,v in pairs(inv.Items) do 
        local it = v.Item:GetItem()
        if not it.Equippable then 
            v:DeHighlight(true)
        else 
            v:DeHighlight(false)
            v:Droppable("Equip")
        end

        
    end

    function inv:OnNewCell(v)
        local it = v.Item:GetItem()
        if not it.Equippable then 
            v:DeHighlight(true)
        else 
            v:DeHighlight(false)
            v:Droppable("Equip")
        end
    end
    inv:PopIn()
    
    local slotpnls = {}

    local char = vgui.Create("FFrame")
    char:SetSize(charw, charh)
    char:SetPos(ScrW()/2 - (charw / 2 + 8 + invw / 2) + 16, ScrH()/2 - charh/2)
    char:MakePopup()
    char.Shadow = {}
    char:PopIn()
    char:MoveBy(-16, 0, 0.2, 0, 0.4)

    function char:Think()
        local dragged = dragndrop.m_Dragging --its a table 

        local dslot

        if dragged then 
            local it = dragged[1]
            if it.Item then 
                dslot = it.Item:GetItem().Slot
            end 
        end

        for k,v in pairs(slotpnls) do 
            if dslot and dslot ~= v.slotname then 
                v.Color = Color(45, 45, 45)
                v.HovMult = 1
            else 
                v.Color = Color(70, 70, 70)
                v.HovMult = 1.3
            end
        end

    end


    local prev = vgui.Create("DModelPanel", char)
    prev:Dock(FILL)
    prev:DockMargin(140, 4, 140, 0)
    prev:SetModel(LocalPlayer():GetModel())
    prev:SetFOV(prev:GetFOV() - 30)
    local pnt = prev.Paint 

    function prev:Paint(w, h)
        surface.SetDrawColor(40, 40, 40)
        surface.DrawRect(0, 0, w, h)

        if ( !IsValid( self.Entity ) ) then return end

        local x, y = self:LocalToScreen( 0, 0 )

        self:LayoutEntity( self.Entity )

        local ang = self.aLookAngle
        if ( !ang ) then
            ang = ( self.vLookatPos - self.vCamPos ):Angle()
        end

        cam.Start3D( self.vCamPos, ang, self.fFOV, x, y, w, h, 5, self.FarZ )

        render.SuppressEngineLighting( true )
        render.SetLightingOrigin( self.Entity:GetPos() )
        render.ResetModelLighting( self.colAmbientLight.r / 255, self.colAmbientLight.g / 255, self.colAmbientLight.b / 255 )
        render.SetColorModulation( self.colColor.r / 255, self.colColor.g / 255, self.colColor.b / 255 )
        render.SetBlend( ( self:GetAlpha() / 255 ) * ( self.colColor.a / 255 ) ) -- * surface.GetAlphaMultiplier()

        for i = 0, 6 do
            local col = self.DirectionalLight[ i ]
            if ( col ) then
                render.SetModelLighting( i, col.r / 255, col.g / 255, col.b / 255 )
            end
        end

        self:DrawModel()

        for k,v in pairs(char.Slots) do
            if not v.UID then continue end 

            local ents = PaintItem(v.UID, self.Entity)
        end

        render.SuppressEngineLighting( false )
        cam.End3D()

        self.LastPaint = RealTime()

        --pnt(self, w, h)
    end

    inv:MoveRightOf(char, 0)

    inv:MoveBy(16, 0, 0.2, 0, 0.4)

    function char:OnRemove()
        if IsValid(inv) then inv:Remove() end
        ClearCSModels()
    end


    local f = char 
    
    local function CreateSlot(x, y, v, k)
    	local n = v.slot 
    	local name = v.name 

    	local slot = vgui.Create("FButton", char)

    	slot:SetPos(x, y)
    	slot:SetSize(120, 120)

    	slot.Label = name

        slot.slotname = v.slotname 
        slot.name = name 

        slot.Shadow.OnHover = false
        
        local halorad = 0

        local canequip_color = Color(20, 80, 255)
        local cantequip_color = Color(250, 60, 60)
        local cantequip_tipcolor = Color(220, 120, 120)

        slot.Shadow.Color = canequip_color:Copy()
        slot.Shadow.Intensity = 2
        slot.Shadow.Blur = 4

        function slot:PrePaint(w, h)

            if not self.ItemHovered then 
                self.Shadow.Spread = L(self.Shadow.Spread, -1, 15) 
                self:RemoveCloud("cantequip_reason")
            else 
                local it = self.ItemHovered
                local item = it:GetItem()

                local can, err = true, nil

                if it.CanEquip then
                    can, err = it:CanEquip()
                end

                self.Shadow.Spread = L(self.Shadow.Spread, 1, 15) 

                if can then
                    LC(self.Shadow.Color, canequip_color, 15)
                    self:RemoveCloud("cantequip_reason")
                else 
                    LC(self.Shadow.Color, cantequip_color, 15)
                    local cl = self:GetCloud("cantequip_reason")

                    if err and not cl then 
                        cl = self:AddCloud("cantequip_reason")
                        cl:SetRelPos(w/2, -16)
                        cl:SetFont("OS28")
                        cl.MaxW = 450
                        cl:SetText(err)
                        cl:SetColor(Color(50, 40, 40))
                    end

                    if cl then
                        cl.TextColor = cantequip_tipcolor

                        cantequip_tipcolor.r = 220 + math.sin(CurTime() * 5) * 40
                        cantequip_tipcolor.g = 120 + math.sin(CurTime() * 5) * 20
                        cantequip_tipcolor.b = 120 + math.sin(CurTime() * 5) * 20
                    end
                end


            end

            self.ItemHovered = false

        end

        local paints = {}

        function slot:PostPaint(w, h)
            for k,v in SortedPairs(paints) do 
                v(self, w, h)
            end
        end

        function slot:Think()

            if Inventory.Equipped[v.slotname] then 

                local it = Inventory.Equipped[v.slotname]
                local item = it:GetItem()
                self.UID = it.ItemUID

                local itemMDL = item.mdl or item.Model 

                if not self.mdlpnl or not IsValid(self.mdlpnl) then 
                    local p = vgui.Create("DModelPanel", self)
                    self.mdlpnl = p 
                    p:SetSize(80, 80)
                    p:SetPos(20, 20)
                    p:SetMouseInputEnabled(false)

                    self.Label = ""

                    if itemMDL then 
                        p:SetModel(itemMDL.name)
                    end

                    if p.Entity then 

                        p.Entity.RenderGroup = RENDERGROUP_BOTH
                        p.Entity:SetRenderMode(RENDERMODE_TRANSCOLOR)

                        if itemMDL.skin then 
                            p.Entity:SetSkin(itemMDL.skin)
                        end
                        if itemMDL.mat then 
                            p.Entity:SetMaterial(itemMDL.mat)
                        end
                        if itemMDL.col then 
                            p.Entity:SetColor(itemMDL.col)
                        end

                        local mn, mx = p.Entity:GetRenderBounds()
                        local size = 0
                        size = math.max( size, math.abs( mn.x ) + math.abs( mx.x ) )
                        size = math.max( size, math.abs( mn.y ) + math.abs( mx.y ) )
                        size = math.max( size, math.abs( mn.z ) + math.abs( mx.z ) )

                        p:SetFOV( 45 )
                        p:SetCamPos( Vector( size, size, size ) )
                        p:SetLookAt( ( mn + mx ) * 0.5 )

                        if itemMDL.decal then 
                            itemMDL.decal(slot, p, p.Entity)
                        end
                        
                    end
                    paints[1] = function(self, w, h)
                        draw.SimpleText(it:GetName(), "OS24", w/2, 4, color_white, 1, 5)
                    end
                    self.Item = it 
                    self.HasItem = true
                end
            elseif IsValid(self.mdlpnl) then

                self.mdlpnl:Remove()
                self.Label = name

                self.Item = nil 
                self.HasItem = false
                table.Empty(paints)
            end

        end

        function slot:DoClick()

            if self.Border then     --re-clicked
                inv:RemoveSort(1)

                for k,v in pairs(inv.Items) do 
                    v:DeHighlight(false)
                end

                self.Border = false 

                return 
            end

            local name = v.slotname

            inv:SortItems(function(a, b)
                a, b = a:GetItem(), b:GetItem()

                local eq1, eq2 = a.Equippable, b.Equippable 
                if eq1 and not eq2 then return true end 

                local t1, t2 = a.Slot, b.Slot 
                local ok1, ok2 = false, false 

                if t1 and t1==name then 
                    ok1 = true 
                end

                if t2 and t2==name then 
                    ok2 = true 
                end 

                return (ok1 and not ok2)

            end, 1)

            for k,v in pairs(slotpnls) do 
                v.Border = nil 
            end

            self.borderColor = Color(200, 200, 50)
            self.Border = {}

            for k,v in pairs(inv.Items) do 
                local it = v.Item:GetItem()
                if not it.Equippable or (it.Slot and it.Slot ~= name) then 
                    v:DeHighlight(true)
                else 
                    v:DeHighlight(false)
                end
            end
            inv:Update(true)

        end

        slot.DoRightClick = function(self)
            if not self.HasItem then return end 

            local m = vgui.Create("FMenu")
            m:Open()
            m:SetAlpha(0)
            local mx, my = m:GetPos()
            m:SetPos(mx+1, my)
            m:MoveTo(mx+7,my, 0.2, 0, 0.4)
            m:AlphaTo(255, 0.1, 0)

            local use = m:AddOption("Unequip Item", function() 
                Equipment.UnequipItem(self.Item, self.slotname)

                ClearCSModel(self.Item:GetUID())

                self.UID = nil
            end)

            use.Description = "Unequips this item from yourself."
            use:SetColor(Color(30, 120, 200))
            use.Icon = hand
            use.IconW = 24
            use.IconH = 24

        end

        slot:Receiver("Equip", function(self, tbl, drop, _, x, y)
            local itpnl = tbl[1]
            local it = itpnl.Item
            local item = itpnl.Item:GetItem()

            if not item.Equippable then return end 

            if not drop then 
                    if v.slotname ~= item.Slot then return end
                    self.ItemHovered = it
                return
            end

            if drop then 
                if self.slotname ~= item.Slot then return end --incorrect slot 

                local ok = Equipment.AttemptEquip(it, self.slotname)

                if ok then 
                    self.UID = it.ItemUID
                    Inventory.Equipped[self.slotname] = it --predict success
                end
            end
        end)

        slotpnls[v.slotname] = slot 

    	return slot
    end

    local slots = {}
    char.Slots = {}

    local slotfs = char.Slots

    for k,v in pairs(Equipment.SlotPanels) do 
    	v.slotname = k
    	slots[v.slot] = v 
    end

    for k,v in ipairs(slots) do 
    	local n = v.slot 
    	local name = v.name 

    	if n >= 5 then break end 

  	 	local x, y = 10, f.HeaderSize + 8 + (140 * (n-1))
  	 	
  	 	slotfs[name] = CreateSlot(x, y, v)

  	 	x = x + (charw - 140)

  	 	slotfs[slots[k + 4].name] = CreateSlot(x, y, slots[k+4])
    end
end