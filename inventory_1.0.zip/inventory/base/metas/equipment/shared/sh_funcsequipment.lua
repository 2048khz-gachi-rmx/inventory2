--aey

Equipment = Equipment or {}
Equipment.Items = Equipment.Items or {}

EquipmentMeta = EquipmentMeta or item:extend()
EquipmentFuncs = EquipmentMeta.Meta

local logt = {name = "Inventory.Equipment", col = Color(100, 220, 120)}

local function log(...)
	Log(logt, ...)
end

Inventory.EquipmentLog = log

Equipment.Slots = {
	["head"] = {slot = 1, name = "Head"},
	["body"] = {slot = 2, name = "Body"},
	["back"] = {slot = 3, name = "Back"},
	["legs"] = {slot = 4, name = "Legs"},
	["primary"] = {slot = 5, name = "Primary"},
	["secondary"] = {slot = 6, name = "Secondary"},
	["special"] = {slot = 7, name = "Special"},
	["util"] = {slot = 8, name = "Utility"},
}

local slots = Equipment.Slots 

--[[
	backslots = {
		[1] = {key = "head", name = "Head"},
		...
	}
]]

local backslots = {}

for k,v in pairs(slots) do 
	backslots[v.slot] = {key = k, name = v.name}
end

Equipment.SlotIDs = backslots 

--[[
	nameslots = {
		["Head"] = {key = "head", slot = 1},
		...
	}
]]

local nameslots = {}

for k,v in pairs(slots) do 
	nameslots[v.name] = {key = k, slot = v.slot}
end

function Equipment.GetSlot(key)

	if isstring(key) then 
		local t = slots[key] or nameslots[key]
		return t.slot
	else 
		return (backslots[key] and backslots[key].name)
	end

end

local item

local function CheckForExistence(...)
	if not item then error("item not set!") return end 

	local str = ""
	local keys = {...}

	for k,v in ipairs(keys) do 
		local val = item[v]
		str = str .. v .. ", "
		if val then return val end 
	end 

	local mult = #keys > 1

	return false, ("[col=230, 120, 120]	ITEM does not have %skey%s \"" .. str:sub(1, #str - 2) .. "\" set! Not loading.\n"):format(mult and "any of the " or "", mult and "s" or "")

end

function Equipment.AddBaseItem(item)
	item.specialMeta = EquipmentMeta 

	Equipment.Items[item.Name] = item

	Inventory.CreateNewItem(item.Name, item, function(id)
		Equipment.Items[id] = item
	end)

end

if CLIENT then 
	--[[
		Auto-fill Equipment.Items with aliases
	]]
	hook.Add("ReceivedInventoryConsts", "EquipmentAdd", function()

		for k,v in pairs(Items) do 
			if isnumber(k) or not istable(v) then continue end 

			if Equipment.Items[k] then 
				Equipment.Items[v.ItemID] = Equipment.Items[k]
			end 
		end

	end)
end

function Equipment.LoadItem(path, slot)
	item = {}

	ITEM = item --create an ITEM global for the item

	include("inventory/equipment/" .. path)

	local sv = CheckForExistence("SV", "SERVER", "Server", "ServerSide", "ServerOnly")

	if not sv and not path:match(".-_sv.lua") then 
		AddCSLuaFile("inventory/equipment/" .. path)
	end

	local name, err = CheckForExistence("Name", "ItemName")
	local slot, err2 = slot or CheckForExistence("Slot", "SlotName")

	if err or err2 then 
		log(err or err2)
		return
	end

	ITEM.Slot = slot 
	ITEM.Name = name
	ITEM.Equippable = true 

	Equipment.AddBaseItem(item)
end

function Equipment.LoadItems()
	local items, folder = file.Find("inventory/equipment/*", "LUA")

	for k, fn in ipairs(items) do 
		log("Loading item %s", fn)
		Equipment.LoadItem(fn)
	end

	for k, name in ipairs(folder) do 

		local slot = Equipment.Slots[name] and name

		if not Equipment.Slots[name] then 
			log("Slot with the same name as folder \"%s\" wasn't found; loading regularly.", name)
		end 

		local items, _ = file.Find("inventory/equipment/" .. name .. "/*.lua", "LUA")

		for k,v in ipairs(items) do
			local fn = name .. "/" .. v
			log("Loading item %s", fn) 
			Equipment.LoadItem(fn, slot)
		end
	end

end

Equipment.LoadItems()


