--aaa

surface.CreateFont("OS48_Shadow", {
	font = "Open Sans",
	size = 48,
	blursize = 1,
	weight = 400
})


local tags = {}

function Inventory.MakeWeaponTagTable()
	Inventory.WeaponTags = setmetatable(tags, {__index = chathud.TagTable})
	tags.emote = table.Copy(chathud.TagTable.emote)
	tags.emote.args[2].default = 96
	tags.emote.args[3].default = 96

	tags.emote.args[2].max = 192
	tags.emote.args[3].max = 192
end

hook.Add("InitPostEntity", "WeaponTags", Inventory.MakeWeaponTagTable)

local charW, charH

local font = "OS48"
local shadowfont = "OS48_Shadow"

hook.Add("CWDrawVM", "DrawEet", function(wep)

	if not IsValid(wep) then return end 

	local base, uid = wep:IsFromInventory()
	if not base then return end

	local info = base.GetScreenInfo 
	if not info then return end 

	local tags = Inventory.WeaponExpressions[uid]
	if not tags then return end 

	local pos, ang

	if wep.CW20Weapon then
		local att = wep:getMuzzlePosition()

		pos = att.Pos
		ang = att.Ang
	end


	pos, ang, scale = info(base, pos, ang)

	local buffer = {}
	buffer.y = 0
	buffer.x = 0 
	buffer.h = 0 

	buffer.curh = 64 	--Current line H: useful for emotes and such

	buffer.fgColor = color_white
	buffer.multmatrix = true

	if tags then

		cam.Start3D2D(pos, ang, scale)

			if not charH then 
				surface.SetFont(font)
				charW, charH = surface.GetTextSize("abcdefghijklmnopqrstuvwxyz")
			end

			local ok, err = pcall(function()

				for k,v in ipairs(tags) do 

					local tx = buffer.x
					local ty = buffer.y + buffer.curh/2 - charH/2

					if isstring(v) then 

						surface.SetFont(shadowfont)
						surface.SetTextColor(color_black)

						for i=1, 2 do
							surface.SetTextPos(tx + i, ty + i )

							surface.DrawText(v)
						end

						surface.SetFont(font)
						surface.SetTextColor(buffer.fgColor)
						surface.SetTextPos(tx, ty)

						surface.DrawText(v)

						local tw, th = surface.GetTextSize(v)
						buffer.x = buffer.x + tw
					else 
						v:Run(buffer)
					end 

				end
				
				for k,v in ipairs(tags) do --end all unended tags
					if istable(v) and not v.Ended and not v.ender then 

						v:End(buffer)
					end
				end

			end)

		cam.End3D2D()

		if not ok then 
			print(err)
		end
	end

end)
