--placeholder
Inventory.Weapon = EquipmentMeta:Callable() --weapons are also equippable but have more features
Inventory.BaseWeapon = Inventory.BaseEquippable:Callable()

WeaponMeta = Inventory.Weapon

local wep = Inventory.Weapon
local wepmeta = wep.Meta 

local bwep = Inventory.BaseWeapon

bwep.Equippable = true 

local weplog = {name = "Inventory.Weapons", col = Color(170, 85, 85)}

local log = function(str, ...)
	Log(weplog, str, ...)
end

Inventory.LogWeapon = log 

function wep:OnEquip()
	local wep = self:GetOwner():Give(self:GetItem().Class)
	wep.SpawnedFromItem = self
	wep:SetDTInt(30, self:GetUID())
	wep:SetDTInt(31, self:GetID())

	if self.perma.expression then 
		net.Start("WeaponExpressions")
			net.WriteUInt(self:GetUID(), 32)
			net.WriteString(self.perma.expression)
		net.Broadcast()
	end

end

function wep:CanEquip()
	local ow = self:GetOwner()
	if ow:HasWeapon(self:GetItem():GetClass()) then return false, "You already have that weapon on you!" end 
	return true
end

function bwep:CanEquip()
	return true 
end

function bwep:OnEquip()
	--self:GetOwner():Give(self:GetItem().Class)
	printf("base weapon somehow got the OnEquip")
end



function bwep:Initialize(class, id)
	self.Class = class 
	self.ID = id 
	self.Model = {}
	self.specialMeta = Inventory.Weapon
end

ChainAccessor(bwep, "Name", "Name") --for displaying in the inventory 
ChainAccessor(bwep, "Class", "Class")
ChainAccessor(bwep, "Slot", "Slot")

--[[
	mdl: table - {
	name: string - Model name
	skin: number - Skin to set for item
	mat: IMaterial - Material to set for the item
	col: Color - Color to set for the item
	decal: function - A function that'll be ran when the panel is created. Args: Panel slot, Panel mdlPanel, Entity mdlEntity
	tick: function - A function that'll be ran for every tick(Panel:Paint hook). Args: ^
]]

function bwep:SetModel(mdl)
	self.Model.name = mdl
	return self
end

function bwep:SetSkin(num) 	--doubt it?
	self.Model.skin = num
	return self
end

function bwep:SetMaterial(mat)
	self.Model.mat = mdl
	return self
end

function bwep:SetColor(col)
	self.Model.col = col
	return self
end

--add getters to the weapno meta so you can call :GetClass() and etc. on items

for k,v in pairs(bwep) do 
	if tostring(k):find("Get.+") and not wep[k] then 
		wep.Meta[k] = v
	end
end


local WEAPON = FindMetaTable("Weapon")

function WEAPON:IsFromInventory()

	local id = self:GetDTInt(31)
	
	if id == 0 then --if true that means we already checked that it's from inventory and it's not
		return false
	else 
		return Items[id], self:GetDTInt(30)
	end

end

local _ = SERVER and util.AddNetworkString("WeaponExpressions")

if CLIENT then 
	local wepexpressions = Inventory.WeaponExpressions or {}
	Inventory.WeaponExpressions = wepexpressions
	
	local _

	net.Receive("WeaponExpressions", function()
		local UID = net.ReadUInt(32)
		local expr = net.ReadString()

		_, wepexpressions[UID] = string.ParseTags(expr, chathud.Shortcuts, Inventory.WeaponTags)--expr
	end)

	

end