--an _include.lua file in a meta allows you to override the including logic yourself

FInc.FromHere("shared/*.lua", _SH) --include whatever in shared first

--and then client and server, order doesn't matter here
FInc.FromHere("server/*.lua", _SV) 
FInc.FromHere("client/*.lua", _CL) 

--After base is done loading, include every weapon in inventory/weapons/*

FInc.Recursive("inventory/weapons/*", _SH, nil, nil, function(path, ret)
	local name = (ret and ret.Name) or file.GetFile(path) or 'What'
	local realm = (CLIENT and "clientside") or "serverside"

	Inventory.LogWeapon("Weapon '%s' loaded %s!", name, realm)
end) --then