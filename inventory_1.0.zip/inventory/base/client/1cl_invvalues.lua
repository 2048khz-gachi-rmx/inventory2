

Inventory.Sorting = {}
Inventory.FeelsGoodManClap = Inventory.Sorting 

Inventory.DeleteHoldTime = 1  --seconds


local fgm = Inventory.FeelsGoodManClap
--date; amt; type; rar

fgm["date"] = function(a, b)
    return a.ItemUID < b.ItemUID
end

local amt = {}

fgm["amt"] = {preeval = function() 
    local inv = Inventory.Data 

    local temp = {}
    table.Empty(amt)
    for k,v in pairs(inv) do 
        local id = v:GetID()
        local num = v:GetAmount()
        if id then 
            temp[id] = (temp[id] or 0) + (num or 1)
        end
    end

    local i = 1

    for k,v in SortedPairsByValue(temp) do 
        amt[k] = i
        i = i+1
    end

end, 
sort = function(a,b) 
    
    local same = (a:GetID()==b:GetID()) 
    if same then 
        local c1 = a:GetAmount()
        local c2 = b:GetAmount()

        return (c1 and c2 and c1>c2)
    end

    local crossitem = amt[a:GetID()] > amt[b:GetID()]
    return crossitem

end} --had to be done :(

local amt2 = {}

fgm["name"] = {preeval = function() 
    local inv = Inventory.Data 

    local temp = {}

    table.Empty(amt2)

    for k,v in pairs(inv) do 
        local id = v:GetID()
        local num = v:GetAmount()
        if id then 
            temp[id] = (temp[id] or 0) + (num or 1)
        end
    end

    local i = 1

    for k,v in SortedPairsByValue(temp) do 
        amt2[k] = i
        i = i+1
    end

end,
sort = function(a, b)
    local t1 = a:GetName()
    local t2 = b:GetName()
    local bool = t1:lower() < t2:lower()    --lua can do alphabet checking with "str < str", amazing

    if t1:lower()==t2:lower() then 
        bool = amt2[a:GetID()] < amt2[b:GetID()]
    end
    print(t1, bool, t2)
    return bool
end}

fgm["rar"] = function(a, b)
    return false
end
----------
Inventory.Stats = {}
local stat = Inventory.Stats 

stat["uses"] = {
    format = function(amt)
        local ret = "%s use%s remaining"

        if amt>1 then 
            ret = ret:format(amt, "s")
        else 
            ret = ret:format(amt, "")
        end 

        return ret, Color(150, 150, 150, 100)
    end,
    order = 1,  --lower = higher
    yoff = 18,
}

stat["dmg"] = {
    diff = function(a) return a-100 end,
    good = function(a) return a>0 end,
    bad = function(a) return a<0 end,
    name = "%s%s%% Damage",
    yoff = 18, 
    order = 2, --has to be unique!!!
}
stat["acc"] = {
    diff = function(a) return a-100 end,
    good = function(a) return a>0 end,
    bad = function(a) return a<0 end,
    name = "%s%s%% Accuracy",
    yoff = 18,
    order = 3,
}

stat["Gay"] = {
    diff = function(a) return (a and 1) or -1 end,
    good = function(a) return a>0 end,
    bad = function(a) return a<0 end,
    name = "%s%s%% Gayness!",
    yoff = 18,
    order = 3,
}

--find mods @ inventory/shared/modifiers.lua