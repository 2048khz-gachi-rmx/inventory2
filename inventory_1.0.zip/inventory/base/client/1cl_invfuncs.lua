--yeet

Inventory = Inventory or {}
Inventory.Data = Inventory.Data or {}

local DATA = Inventory.Data 

DATA.Temp = DATA.Temp or invobj:new(LocalPlayer(), "Backpack", 1)
DATA.Vault = DATA.Vault or invobj:new(LocalPlayer(), "Vault", 2)
DATA.Perma = DATA.Perma or invobj:new(LocalPlayer(), "Permanent", 3)

Inventory.GetByID = function(id)
	return Inventory.Data[Inventory.InventoryIDs[id]]
end

Inventory.Log = function(...)
	Log({name = "Inventory-CL", col = Color(50, 150, 250)}, ...)
end

local log = Inventory.Log 

Inventory.HaloEnts = {}
local lightemup = Inventory.HaloEnts

inv = Inventory

local shorts = {
	ItemID = "i",
	ItemUID = "u",
	perma = "p",
	ItemAmount = "a",
}
local longs = {}

for k,v in pairs(shorts) do 
	longs[v] = k
end

include("inventory/shared/item_meta.lua")	--Shared item meta
include("inventory/client/cl_meta.lua")		--Client-only item methods

Inventory.StackFunction = function(i1, i2)

	net.Start("InventoryAction")
		net.WriteUInt(2, 8)
		net.WriteUInt(i2:GetUID(), 32)	--from
		net.WriteUInt(i1:GetUID(), 32)	--to
	net.SendToServer()

end

function Inventory.EnoughItem(id, amt, reserved)

	local has = 0
	local iid = (isnumber(id) and id) or Inventory.ItemDefines[id]
	for k,v in pairs(Inventory.Data) do 
		if v.ItemID==iid then has = has + (v:GetAmount() or error('Item with ID of '..v.ItemID..' is not stackable!')) end
	end

	has = has - (reserved or 0)

	return amt <= has, has
end

function Inventory.FindItem(uid)
	return Inventory.Items[uid], Inventory.Items[uid]:GetBelongsTo()
end

function Inventory.GetItem(key)
	return (Inventory.ItemDefines[key] and Items[Inventory.ItemDefines[key]])
end

GetItem = Inventory.GetItem 

function Inventory.UseItem(uid)

	net.Start("InventoryAction")
		net.WriteUInt(4, 8)
		net.WriteUInt(uid, 32)	--to
	net.SendToServer()

	local item = Inventory.FindItem(uid)
	local it = item:GetItem()

	local func = it.ClientUse or (it.alias and UniqueItems[it.alias] and UniqueItems[it.alias].ClientUse)
	local shfunc = it.SharedUse or (it.alias and UniqueItems[it.alias] and UniqueItems[it.alias].SharedUse)

	if func then func(item) end
	if shfunc then shfunc(item, LocalPlayer()) end 

end

function Inventory.ParseItems(its)	--update item

	local ret = {}

	for _, item in ipairs(its) do
		
		local newitem = Inventory.ParseItem(item)
		local uid = newitem.ItemUID

		ret[uid] = newitem
	end

	return ret
end

local curi = 0

function Inventory.ParseItem(item)

	local uid = item.ItemUID
	local iid = item.ItemID

	if not iid then 
		print("\n------\n")
		PrintTable(item)
		print("\n------ curI =", curi, "\n")
		error("Failed to get ItemID!") 
	return end 

	local it = GetItem(iid)

	if not it then 
		print("\n------\n")
		PrintTable(item)
		print("\n------ curI =", curi, "\n")
		error("Failed to get Item with ID " .. tostring(iid)) 
	return end 

	local base = Items[iid]

	local smeta = it.specialMeta
	local meta = (istable(smeta) and smeta) or (isstring(smeta) and _G[smeta]) or itemmeta


	if not meta then error("Did not find metatable for item " .. tostring(iid) .. " named " .. tostring(metaname)) return end 
	if not meta.Decode then error("Did not find Decode function for Item meta \"" .. smeta .. "\"") return end

	local newitem = meta:Decode(uid, item)

	return newitem
end

Inventory.Callbacks = Inventory.Callbacks or {}

function Inventory.ItemCallback(uid, func)
	Inventory.Callbacks[uid] = func
end

local function ReadChange()

	local iid, uid = net.ReadUInt(Inventory.IIDConstant), net.ReadUInt(Inventory.UIDConstant)	--IID:UID pair is constant for ALL items
	local it = Inventory.FindItem(uid)

	if not it then
		print("failed #", i, iid, uid, "; creating new")

		it = {}

		local hasperma = net.ReadBool()

		if not hasperma then 
			it.ItemAmount = net.ReadUInt(16)
		else 
			it.perma = {}
		end

		it.ItemID = iid 
		it.ItemUID = uid
		
		it = Inventory.ParseItem(it)
	else
		it:ParseChanges()
	end

	return it
end

local function ReadItem()

	local iid, uid = net.ReadUInt(Inventory.IIDConstant), net.ReadUInt(Inventory.UIDConstant)	--IID:UID pair is constant for ALL items

	local it = {}
	local hasperma = net.ReadBool()

	if not hasperma then 
		it.ItemAmount = net.ReadUInt(16)
	else 
		it.perma = {}
	end

	it.ItemID = iid 
	it.ItemUID = uid
	
	local it = Inventory.ParseItem(it)

	return it
end


local function ReadChanges(amtits)
	local its = {}


	for i=1, amtits do 

		local it = ReadChange()

		its[i] = it

	end

	local hasperma = net.ReadBool()

	if hasperma then

		local comp = net.ReadBool()

		local len = net.ReadUInt(16)
		local dat = net.ReadData(len)
		if comp then dat = util.Decompress(dat) end

		if #dat > 1 then

			local tbl = util.JSONToTable(dat)

			for k, v in pairs(tbl) do 

				k = tonumber(k)
				local it = its[k]

				if not it then error("attempted to change item we are not aware of! (UID: " .. tostring(k) .. ")") return end
				if not it.ParsePerma then log("%s ; did not have 'ParsePerma' method, skipping", tbl[k]) continue end

				it:ParsePerma(tbl[k])
			end
		end

	end

	return its
end

local function ReadItems(amtits)

	local its = {}

	for i=1, amtits do 

		local it = ReadItem()

		its[i] = it
	end

	local hasdat = net.ReadBool()
	local data = {}

	if hasdat then 

		local comp = net.ReadBool()

		local len = net.ReadUInt(16)
		local dat = net.ReadData(len)

		log("%d bytes of %scompressed JSON data", len, (comp and "") or "un")

		if comp then 
			dat = util.Decompress(dat)
		end

		local tbl = util.JSONToTable(dat)
		if not tbl then return end

		for k, v in pairs(tbl) do 
			local json = util.JSONToTable(v)
			data[k] = json
			
		end
	end
	_ITS = its

	for k,v in pairs(data) do 

		local it = its[k]

		if not it then log("#%d : received permanent info JSON but didn't reseive the actual item; skipping", k) continue end
		if not it.ParsePerma then log("k: %d, v printed above ; did not have 'ParsePerma' method, skipping", k, PrintTable(v)) continue end

		it:ParsePerma(v) 

	end

	return its
end

local function ReceiveInventory(ins_where, name)
	local typ = net.ReadUInt(4)
	local amtits = net.ReadUInt(16)

	if typ == ITEM_CHANGES then --Receiving changes

		local its = ReadChanges(amtits)

		for k,v in pairs(its) do 
			ins_where[v:GetUID()] = v
			Inventory.Items[v:GetUID()] = v

			v:SetBelongsTo(ins_where)
			v:SetBelongsID(Inventory.InventoryNames[name])
		end

	elseif typ == ITEM_FULL then	--Receiving new items

		local its = ReadItems(amtits)

		for k,v in pairs(its) do
			ins_where[v.ItemUID] = v
			Inventory.Items[v:GetUID()] = v
		end

	end
end

function Inventory.ReceiveTemp()
	ReceiveInventory(Inventory.Data.Temp, "Temp")
end

function Inventory.ReceiveVault()
	ReceiveInventory(Inventory.Data.Vault, "Vault")
end

function Inventory.ReceivePerma()
	ReceiveInventory(Inventory.Data.Perma, "Perma")
end

function Inventory.FindItem(uid)
	for key, t in pairs(Inventory.Data) do 
		if t[uid] then 
			return t[uid], t 
		end 
	end 
end

net.Receive("FetchInventory", function(leng)

	local resync = net.ReadBool()

	if resync then 
		for key, t in pairs(Inventory.Data) do 
			table.Empty(t)
		end 
	end

	local hastemp = net.ReadBool()

	if hastemp then 
		Inventory.ReceiveTemp()
	end


	local hasvault = net.ReadBool()

	if hasvault then 
		Inventory.ReceiveVault()
	end

	local hasperma = net.ReadBool()

	if hasperma then 
		Inventory.ReceivePerma()
	end


	local hasstates = net.ReadBool()
	local states = {}

	if hasstates then 

		local amt = net.ReadUInt(16)

		for i=1, amt do 

			local uid = net.ReadUInt(Inventory.UIDConstant)
			local typ = net.ReadUInt(2)

			if typ == ITEM_DELETED then
				local it, where = Inventory.FindItem(uid)
				if not it then error("What " .. tostring(uid)) return end 

				where[uid] = nil
			elseif typ == ITEM_MOVED then 
				local to = net.ReadUInt(2)
				local name = Inventory.InventoryIDs[to]

				local it, where = Inventory.FindItem(uid)
				if not it or not name then error("What " .. tostring(it) .. ", " .. tostring(name)) return end

				where[uid] = nil
				Inventory.Data[name][uid] = it
			end
		end

	end

	local okcode = net.ReadUInt(8)

	if okcode ~= 0xd1 then 	--im sorry
		error("Something went wrong while receiving your inventory. Whoops.\nWe'll discard your entire inventory clientside to save you the trouble of fake items and fake info. Sorry about that.")
		return 
	end

	for k,v in pairs(inv) do 
		if Inventory.Callbacks[k] then 
			Inventory.Callbacks[k](v) 
			Inventory.Callbacks[k] = nil 
		end
	end
	--Inventory.Data = table.Merge(Inventory.Data, inv)

	hook.Run("InventoryUpdate", Inventory.Data, diff)
end)

function ApplyWeaponStats(wep, stats)
	if not IsValid(wep) or not LocalPlayer():HasWeapon(wep:GetClass()) then return end 

	wep.FireDelayMult = stats.fd or wep.FireDelayMult
	wep.ReloadSpeedMult = stats.rs or wep.ReloadSpeedMult

	wep.HipSpreadMult = stats.acc or wep.HipSpreadMult
	wep.AimSpreadMult = stats.acc or wep.AimSpreadMult

	wep.DamageMult = stats.dmg or wep.DamageMult

	wep.RecoilMult = stats.rec or wep.RecoilMult

	wep:recalculateStats()
end

net.Receive('ApplyWepStats', function()
	
	if not IsValid(wep) then return end 

	local stats = util.JSONToTable(net.ReadString())

	local id = net.ReadUInt(32)
	local gun = Entity(id)


	if not IsValid(gun) or not LocalPlayer():HasWeapon(gun:GetClass()) then 
		timer.Simple(0.5, function()
			gun = Entity(id)
			ApplyWeaponStats(gun, stats)
		end)
	else 
		ApplyWeaponStats(gun, stats)
	end
	
end)

Inventory.UIDConstant = Inventory.UIDConstant or 0
Inventory.IIDConstant = Inventory.IIDConstant or 0

Inventory.StringToID = Inventory.StringToID or {}
Inventory.IDToString = Inventory.IDToString or {}

Inventory.CreateItemQueue = Inventory.CreateItemQueue or {}
local ciq = Inventory.CreateItemQueue

Inventory.ItemDefines = Inventory.ItemDefines or {}
local itdef = Inventory.ItemDefines

function Inventory.CreateNewItem(name, tbl)
	
	tbl.IsBaseItem = true 
	
	if not itdef[name] then 
		Inventory.CreateItemQueue[name] = tbl 
	else 
		print("Found defined b4", name)

		tbl.ItemName = name

		local old = Items[name]

		if old then 
			tbl.ItemID = old.ItemID
		end

		Items[itdef[name]] = tbl 
		Items[name] = tbl
	end

end

net.Receive("ReceiveInventoryConsts", function(len)
	print("received consts, len:", len/8, "bytes")

	local hasids = net.ReadBool()

	if hasids then 
		local uid = net.ReadUInt(6)
		local iid = net.ReadUInt(6)


		Inventory.UIDConstant = uid 
		Inventory.IIDConstant = iid 
	end

	local hasits = net.ReadBool()

	if hasits then 

		local comp = net.ReadBool()

		local len = net.ReadUInt(16)
		local ns = net.ReadData(len)
		
		if comp then ns = util.Decompress(ns) end

		local names = {}

		for s in string.gmatch(ns, "(.-[^\\])|") do 
			names[#names+1] = s 
			ns = ns:gsub(s .. "|", "")
		end

		names[#names + 1] = ns 

		local idslen = Inventory.IIDConstant

		for i=1, #names do 

			local iid = net.ReadUInt(idslen)
			if names[i] then 
				Inventory.ItemDefines[iid] = names[i]
				Inventory.ItemDefines[names[i]] = iid 

				Inventory.StringToID[names[i]] = iid 
				Inventory.IDToString[iid] = names[i]
			end

		end

	end

	for k,v in pairs(ciq) do --create every item that was queued
		
		local name = Inventory.ItemDefines[k]
		v.ItemID = Inventory.ItemDefines[k]

		Items[k] = v 
		Items[Inventory.ItemDefines[k]] = v
	end

	hook.Run("ReceivedInventoryConsts")
	
	net.Start("FetchInventory")
	net.SendToServer()
end)