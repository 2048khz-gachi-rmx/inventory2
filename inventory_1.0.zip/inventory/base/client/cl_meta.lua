
--[[

	Client-exclusive metamethods for items or players.
	Must be ran after shared item meta definition.

]]

if not item then 
	error("Loaded too fast?")
	return 
end

function itemfuncs:Decode(uid, t, typ)

	local iid = t.ItemID 
	local perma = t.perma
	local amt = t.ItemAmount

	local item = {}

	item.ItemID = iid 
	item.ItemAmount = amt 
	item.ItemUID = uid 

	item.perma = perma 
	
	local base = Items[iid]
	
	local smeta = base.specialMeta
	local meta = (istable(smeta) and smeta) or (isstring(smeta) and _G[smeta]) or itemmeta

	setmetatable(item, meta)

	return item
end

function itemfuncs:ParseChanges(uid, t)

	local prm = net.ReadBool()

	if not prm then 
		self.ItemAmount = net.ReadUInt(16)
		print("item amount:", self.ItemUID, self.ItemAmount)
	end

end

function itemfuncs:ParsePerma(t)	--nothing special; default perma parsing
	print("t is", t)
	if isstring(t) then t = util.JSONToTable(t) end
	self.perma = table.Merge(self.perma or {}, t)
end

function itemfuncs:GetOwner()
	return LocalPlayer()
end

function itemfuncs:GetItemOnItem(item)
	local can = self:GetItem().Interactable and self:GetItem().Interactable[item:GetID()]

	if not can then can = item:GetItem().Interactable and item:GetItem().Interactable[self:GetID()] end --backwards

	if not can then 
		if item:GetAmount() and self:GetAmount() then 
			can = Inventory.StackFunction
		end
	end

	if not can then return false end 

	return can
end

function PLAYER:HasItem(uid)

	for k,v in pairs(Inventory.Data) do 
		if v[uid] then 
			return v[uid], v:GetID()
		end 
	end

	return false
end