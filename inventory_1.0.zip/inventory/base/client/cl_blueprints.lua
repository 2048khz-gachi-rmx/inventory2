Inventory.Blueprints = Inventory.Blueprints or {}

blueprint = item:Extend()

blueprintMeta = blueprint.Meta

blueprintMeta.IsBluePrint = true
blueprintMeta.IsBlueprint = true

local weptypeicons = {
	["Pistol"] = {URL = "https://i.imgur.com/1PjXopB.png", URLName = "crafting/chalkpistol.png"},
	["Melee"] = {}
}

function Inventory.TurnToBlueprints(tbl)

	for k,v in pairs(tbl) do 
		Inventory.Blueprints[v.Class] = {id = k}
		table.Merge(Inventory.Blueprints[v.Class], v)
	end

end

function blueprintMeta:Initialize(tbl)

	tbl.Overrides = {}
	local ov = tbl.Overrides 
	ov.icon = {}
	local wep = Inventory.GunClasses[tbl.perma.CraftsInto]

	if not wep then 

		local err = tbl.perma and tbl.perma.CraftsInto 
		err = err or (not tbl.perma and "not even dang ole' perma table!") or "crafts into is empty dood!"
		err = err .. (" (UID: %s)"):format(tbl.ItemUID)

		PrintTable(tbl)
		error('no weapon you joker! ' .. err)

		return 
	end 

end

function blueprintMeta:GetRemark()
	return {Text = "Take this to a blueprint to analyze this! Don't actually, this is a test.", Font = "RL16"}
end

function blueprintMeta:GetResult()
	return Inventory.GunClasses[self:GetCraftsTo()]
end

function blueprintMeta:GetName()
	local gc = self:GetResult()
	return ((gc and gc.Name) or "L_ L_ L_ ?") .. " (BP)"
end

function blueprintMeta:GetResultName()
	local gc = self:GetResult()
	return ((gc and gc.Name) or "L_ L_ L_ ?")
end

function blueprintMeta:GetCraftsTo()
	return self.perma.CraftsInto
end

function blueprintMeta:PaintIcon(pnl, w, h)
	local wep = self:GetResult()
	local wtype = wep and wep.weptype
	local icon = wtype and weptypeicons[wtype]

	if icon then 
		surface.SetDrawColor(color_white)
		surface.DrawMaterial(icon.URL, icon.URLName, w/2 - 24, h/2 - 20, 48, 48)
	end
end

function blueprintMeta:Decode(...)	--just make an item and wait for parse perma

	local it = item:Decode(...)
	it:SetMeta(blueprint)

	return it

end
