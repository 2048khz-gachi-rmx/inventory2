local lightemup = Inventory.HaloEnts

local twash = Material("data/hdl/trash.png")
hdl.DownloadFile("https://i.imgur.com/a13ySns.png", "trash.png", function(fn) twash = Material(fn) end)

local surface = surface 

function CreateItemSlot(sX, sY, v, par, f)
	local item = Items[v.ItemID]
	if not item then return end 

	local k = v.ItemUID 


	local slot = vgui.Create("FButton", par)

	slot:SetPos(sX, sY)
	slot:SetSize(80, 80)
	slot:Droppable("ItemDrop")

	slot.White = Color(255, 255, 255)
	slot.Gray = Color(130, 130, 130)


	slot:SetMouseInputEnabled(true)
	slot.UID = v.ItemUID
	slot.Item = v

	local inv_tbl = f and f.Inventory

	local Item = v

	slot:Receiver("ItemDrop", function(self, tbl, dropped)
		if not dropped or not tbl[1] or not tbl[1].Item or not tbl[1].UID or tbl[1].UID == self.UID then return end 
		local i2 = tbl[1]
		local can = i2.Item:GetItemOnItem(self.Item)
		if can then can(i2.Item, self.Item) end

	end)

	if f then f.Items[slot.UID] = slot end

	slot.Options = {}

	if item.Usable then 
		local opt = {}
		opt.Name = "Use Item"
		opt.Callback = function()
			Inventory.UseItem(Item.ItemUID)
		end

		opt.Description = "This will consume your item."
		opt.Color = Color(30, 120, 200)
		opt.Icon = hand
		opt.IconW = 24
		opt.IconH = 24

		opt.Order = 2

		slot.Options["Use"] = opt
	end

	if not item.Undeleteable then 
		local opt = {}
		opt.Name = "Delete Item"

		opt.OnCreate = function(del)
			local lastheld = 0
			local holdtime = 0

			function del:PreTextPaint(w, h)
				if self:IsDown() then 
					holdtime = holdtime + FrameTime()
					lastheld = CurTime()

				elseif CurTime() - lastheld > 0.6 then 

					holdtime = math.max(holdtime - FrameTime()*3, 0)
				end

				if holdtime >= Inventory.DeleteHoldTime then 

					self.Menu:Remove()
					net.Start("InventoryAction")
						net.WriteUInt(1, 8)
						net.WriteUInt(Item:GetUID(), 32)
					net.SendToServer()

				end

				local frac = holdtime / Inventory.DeleteHoldTime
				
				frac = (1 - frac)^3

				surface.SetDrawColor(200, 60, 60)
				surface.DrawRect(0, 0, w*frac, h)
			end

			del.Description = "Delete an item permanently.\n(click & hold)"
			del:SetColor(Color(140, 20, 20))
			del.HovMult = 1.2
			del.Icon = twash
		end

		opt.Order = 0

		slot.Options["Delete"] = opt
	end

	slot.DoRightClick = function()
		if table.Count(slot.Options) == 0 then print("no options") return end 

		local opts = {}

		for k,v in pairs(slot.Options) do 
			opts[#opts + 1] = v 
		end 

		table.sort(opts, function(a, b)
			return (a.Order or 1) > (b.Order or 1)
		end)

		local m = vgui.Create("FMenu")
		m:Open()
		m:SetAlpha(0)
		local mx, my = m:GetPos()
		m:SetPos(mx+1, my)
		m:MoveTo(mx+7,my, 0.2, 0, 0.4)
		m:AlphaTo(255, 0.1, 0)
		print("created menu")
		for k,v in pairs(opts) do 
			local opt = m:AddOption(v.Name, v.Callback)
			opt.Description = v.Description 
			opt.Menu = m 

			if v.Color then opt:SetColor(v.Color) end

			if v.Icon then 
				opt.Icon = v.Icon 
				opt.IconW = v.IconW or opt.IconW
				opt.IconH = v.IconH or opt.IconH
			end 

			if v.OnCreate then 
				v.OnCreate(opt)
			end
		end

	end

	function slot:OnStartDragging()
	   -- self:SetWorldClicker(true)
		self.IsDragged = true

	end

	function slot:DeHighlight(bool)
		slot.DeHighlighted = bool
		self:AlphaTo((bool and 150) or 255, 0.1)
		if slot.mdl then 
			self.mdl:AlphaTo((bool and 75) or 255, 0.1)
		end
	end

	function slot:GetItem()
		return self.Item
	end

	local hg = 255

	slot.CurCursor = "none"
	slot.DeHighlighted = false
	slot.Border = {w=2, h=2}
	slot.borderColor = Color(100, 100, 100)

	function slot:Think()

		if f.Inventory and not f.Inventory[self.UID] and not self.Removing then

			self.Removing = true

			self:SizeTo(self:GetWide() / 2, self:GetTall() / 2, 0.2, 0, 0.4)
			self:MoveTo(self.X + self:GetWide() / 4, self.Y + self:GetTall() / 4, 0.2, 0, 0.4)

			if self.mdl then 
				local mdl = self.mdl
				mdl:SizeTo(mdl:GetWide() / 2, mdl:GetTall() / 2, 0.2, 0, 0.4)
				mdl:MoveTo(mdl.X + mdl:GetWide() / 4, mdl.Y + mdl:GetTall() / 4, 0.2, 0, 0.4)
			end

			self:RemoveCloud("stats")

			self:AlphaTo(0,0.3, 0, function() 
				if f then 
					f.Items[slot.UID] = nil
					f:Update(true)
				end

				self:Remove()  
			end)

		end

	end

	function slot:Paint(w,h)

		local ishov = vgui.GetHoveredPanel() == self
		self.Hovered = ishov 						 --unreliable rightclicks fix
													  --thanks garry

		if self.Matrix then --ah shit here we go again 
			cam.PushModelMatrix(self.Matrix)
			self.PopMatrix = true 
		end

		if self.DontPaint then return end 

		local cloud = self:GetCloud("stats")


		if self.DeHighlighted then 
			self:SetMouseInputEnabled(false)
			draw.RoundedBox(8, 0, 0, w, h, Color(30, 30, 30))

			hg = L(hg, 120, 15)

		else 
			self:SetMouseInputEnabled(true)
			self:Draw(w,h)

			hg = L(hg, 255, 15)
		end

		self.White.a = hg
		self.Gray.a = hg

		if self.Removing then return end 

		local stats = v.GetPermaStats and v:GetPermaStats()
		

		if stats and ishov and not cloud then 
			cloud = self:AddCloud("stats")
			cloud:SetColor(30, 30, 30)
			cloud:Popup(true)
			cloud:Bond(self)
			cloud.Speed = 25
			cloud.RemoveWhenDone = true
			cloud:SetLabel(v:GetName())

			local knownstats = {}
			local knownmods = {}

			local statnums = {}    --debug table
			local remarked = false 


			function cloud:UpdateStats()	--for use when inventory updates

				local sepped = false 
				local stats = v.GetPermaStats and v:GetPermaStats()
				
				if stats and stats.stats then
					for k,v in pairs(stats.stats) do 
						local stat = Inventory.Stats[k]

						if stat and (not knownstats[k] or knownstats[k].val~=v) then 
							local name, col, font, yoff

							font = stat.font
							yoff = stat.yoff
							if isstring(v) then --unanalyzed/unknown lvl
								name = string.format(stat.name, "", v)
								col = Color(200, 200, 200) 
							elseif not stat.format then 
								local val = (stat.diff and stat.diff(v)) or v
								if val==0 then continue end
								
								local good = stat.good and stat.good(val)
								local bad = stat.bad and stat.bad(val)

								col = (good and Color(100, 200, 100)) or (bad and Color(200, 100, 100)) or Color(150, 150, 150, 100)
								
								name = string.format(stat.name, (bad and "-") or (good and "+") or "", math.abs(val))
							else

								name, col = stat.format(v)

							end
							local key = (knownstats[k] and knownstats[k].id) or (stat.order or k)

							statnums[key] = self:AddFormattedText(name, col or Color(255, 0, 0), font, yoff, stat.order or k)	--nils are supported
							
							knownstats[k] = {id = key, val = v}
						end

					end 
				end

				if stats and stats.mods then 

					for k,v in pairs(stats.mods) do 
						local mod = Inventory.Modifiers[k]

						if isbool(v) then   --unanalyzed/unknown lvl
							 v = "?"
						end

						if mod and (not knownmods[k] or knownmods[k].val~=v) then 

							local seq = (knownmods[k] and knownmods[k].id) or table.maxn(statnums) + 1

							if not sepped then
								sepped = true 
								self:AddSeperator(nil, 12)
							end

							local name, col = mod.Name, mod.col 

							
							statnums[seq] = self:AddFormattedText(name .. " " .. v, col or Color(255, 0, 0), "OS18", 18, seq)  

							knownmods[k] = {id = seq, val = v}
						else 

						end

					end 

				end

				for k,v in pairs(stats) do 
					local stat = Inventory.Stats[k]

					if stat and (not knownstats[k] or knownstats[k].val~=v) then 
						local name, col, font, yoff

						font = stat.font
						yoff = stat.yoff
						if isstring(v) then --unanalyzed/unknown lvl
							name = string.format(stat.name, "", v)
							col = Color(200, 200, 200) 
						elseif not stat.format then 
							local val = (stat.diff and stat.diff(v)) or v
							if val==0 then continue end
							
							local good = stat.good and stat.good(val)
							local bad = stat.bad and stat.bad(val)

							col = (good and Color(100, 200, 100)) or (bad and Color(200, 100, 100)) or Color(150, 150, 150, 100)
							
							name = string.format(stat.name, (bad and "-") or (good and "+") or "", math.abs(val))
						else

							name, col = stat.format(v)

						end
						local key = (knownstats[k] and knownstats[k].id) or (stat.order or k)

						statnums[key] = self:AddFormattedText(name, col or Color(255, 0, 0), font, yoff, stat.order or k) --nils are supported
						
						knownstats[k] = {id = key, val = v}
					end

				end 

				local ev = v.GetRemark and eval(v.GetRemark, v)

				if ev and not remarked then 
					remarked = true
					self:AddSeperator(nil, 16)

					local tx = ev.Text or "???"
					local col = ev.Color or Colors.DarkWhite
					local font = ev.Font 

					self:AddFormattedText(tx, col, font, nil, 9001)
					self.MinW = 160
				end

			end

			function cloud:PostPaint()
				if not IsValid(f) then self:Remove() end
			end

			cloud:UpdateStats()

			
			cloud.Middle = 0.5
			cloud:SetAbsPos(40,-20)

		end

		if cloud then 
			cloud:Popup(ishov)
			cloud:UpdateStats()
		end
		

		
		if self.Icons then 

			for k,v in ipairs(self.Icons) do 

				if v.URL then 
					local col = (isfunction(v.Col) and v.Col(Item)) or (IsColor(v.Col) and v.Col) or self.White
					surface.SetDrawColor(col)
					surface.DrawMaterial(v.URL, v.URLName, v.X, v.Y, v.W, v.H, v.rot)
				else
					surface.SetMaterial(v.mat)
					local col =  (isfunction(v.Col) and v.Col(Item)) or (IsColor(v.Col) and v.Col) or self.White
					surface.SetDrawColor(col)
					if v.rot then 
						surface.DrawTexturedRectRotated(v.X, v.Y, v.W, v.H, v.rot)
					else
						surface.DrawTexturedRect(v.X, v.Y, v.W, v.H)
					end
				end
			end

		end

		if v.PaintIcon then 
			v:PaintIcon(self, w, h)
		end
		
	end

	local lmx, lmy = gui.MouseX(), gui.MouseY()
	local rot = 0

	function slot:PaintOver(w, h)

		local ok, err = pcall(function() 
			if self.DontPaint then self.DontPaint = false return end 

			draw.SimpleText(v:GetName(), "TW18", w/2, 0, self.White, 1, 5)
			if Inventory.InDev then draw.SimpleText(self.UID, "TW18", 0, 28, self.White, 0, 5) end
			local amt = (v.GetAmount and v:GetAmount())

			if amt then 
				draw.SimpleText("x" .. amt, "TW18", w/2, 14, self.Gray, 1, 5)
			end
		end)

		if not ok then print(err) end

		if self.PopMatrix then 
			cam.PopModelMatrix(self.Matrix)
			self.Matrix = nil 
			self.PopMatrix = false 
		end

	end

	function slot:PaintEmpty(x, y, w, h)
		local ok, err = pcall(function() 
			draw.SimpleText("[empty slot]", "TW18", x + w/2, y + h/2, self.White, 1, 1)

			draw.RoundedBox(8, x, y, w, h, Colors.DarkGray)

			draw.SimpleText(v:GetName(), "TW18", x + w/2, y, self.White, 1, 5)
			draw.SimpleText(v:GetUID(), "TW18", x, y + 28, self.White, 0, 5)

			if v.ItemAmount then 
				draw.SimpleText("x"..v:GetAmount(), "TW18", x + w/2, y + 14, self.Gray, 1, 5)
			end
		end)

		if not ok then 
			print("Inventory PaintEmpty cell error!:", err)
		end
	end

	function slot:DragPaint(mx, my)

		local w, h = ScrW(), ScrH()
		local x, y = self:LocalToScreen(0, 0)
		local vm
		my = my or 30


		local dx, dy = gui.MouseX() - lmx, gui.MouseY() - lmy
		lmx, lmy = dx + lmx, dy + lmy --basically gui.MouseX(), gui.MouseY()

		rot = L(rot, math.Clamp((dx)/FrameTime()/15, -60, 60), 6)

		if math.abs(rot) > 0.7 then

			vm = Matrix()
			local vec = Vector(lmx, lmy)

			vm:Translate(vec)
				vm:Rotate(Angle(0, rot, 0))
			vm:Translate(-vec)

		end

		local main = par.Main or par:GetParent()
		local sx, sy = main:LocalToScreen(0, 0)

		render.SetScissorRect(sx, sy, sx + main:GetWide(), sy + main:GetTall(), true)	--it can paint outside of its' canvas otherwise
			self:PaintEmpty(x, y, 80, 80)
		render.SetScissorRect(0, 0, 0, 0, false)

		self.Matrix = vm 

		self.DraggedPaint = true 
		self.DontPaint = false 
		self.DrawShadow = false
		

			self:PaintAt( mx + self.x - self:GetWide() / 2, my + self.y - self:GetTall() / 2 )
		
		self.DrawShadow = true
		self.DraggedPaint = false 
		self.DontPaint = true 

	end

	local itemMDL = item.mdl or item.Model 

	if itemMDL and not slot.mdl then 
		local mdl = itemMDL.name or ""

		local p = vgui.Create("DModelPanel", slot)

		p:SetSize(72, 60)
		p:SetPos(4, 10)

		local ecol
		local mdpnt
		local pnt = p.Paint 

		function p:Init()
			self.Initted = true
			
			p:SetModel(mdl)
			p:SetMouseInputEnabled(false)
			if p.Entity then 

				p.Entity.RenderGroup = RENDERGROUP_BOTH
				p.Entity:SetRenderMode(RENDERMODE_TRANSCOLOR)

				if itemMDL.skin then 
					p.Entity:SetSkin(itemMDL.skin)
				end
				if itemMDL.mat then 
					p.Entity:SetMaterial(itemMDL.mat)
				end
				if itemMDL.col then 
					p.Entity:SetColor(itemMDL.col)
				end

				local mn, mx = p.Entity:GetRenderBounds()
				local size = 0
				size = math.max( size, math.abs( mn.x ) + math.abs( mx.x ) )
				size = math.max( size, math.abs( mn.y ) + math.abs( mx.y ) )
				size = math.max( size, math.abs( mn.z ) + math.abs( mx.z ) )

				p:SetFOV( 45 )
				p:SetCamPos( Vector( size, size, size ) )
				p:SetLookAt( ( mn + mx ) * 0.5 )

				if itemMDL.decal then 
					itemMDL.decal(slot, p, p.Entity)
				end
				
			end
			ecol = p.Entity and p.Entity:GetColor()
			mdpnt = itemMDL.tick
		end

		

		function p:Paint(w,h)
			--draw.RoundedBox(2,0,0,w,h,Color(25,25,25,125))
			if slot.DontPaint then return end 
			local sx, sy = self:LocalToScreen(0, 0)

			if sy >= ScrH() then return end 

			if not self.Initted then self:Init() end

		
			if math.abs(rot) > 0.7 and slot.DraggedPaint then 	--i dont know why but modelpanel doesn't obey the slot's matrix even though it's popped after mdl paints
				local ang = self:GetLookAng() or ( self.vLookatPos - self.vCamPos ):Angle()
				ang.r = -rot * 1.5

				self:SetLookAng(ang)
			else 
				self.aLookAngle = nil 
			end

			local col = ecol or self:GetColor()

			col.a = math.min(self:GetAlpha(), slot:GetAlpha())
			self:SetColor(col)


			pnt(self,w,h)
			if mdpnt then mdpnt(slot, self, self.Entity) end
			
		end
		slot.mdl = p
	elseif item.icon then 
		slot.Icons = {}

		local icon = table.Copy(item.icon)
		if v.Overrides and v.Overrides.icon then 
			table.Merge(icon, v.Overrides.icon)
		end

		if icon.mat then 

			slot.Icons[1] = {}

			slot.Icons[1].mat = icon.mat 
			slot.Icons[1].URL = icon.URL
			slot.Icons[1].URLName = icon.URLName
			slot.Icons[1].Col = icon.Col or Color(255, 255, 255)
			slot.Icons[1].X = icon.x or 16
			slot.Icons[1].Y = icon.y or 16
			slot.Icons[1].W = icon.w or 48
			slot.Icons[1].H = icon.h or 48

		elseif istable(icon[1]) then
			
			for k,v in pairs(icon) do
				slot.Icons[k] = {}
				slot.Icons[k].mat = v.mat 
				slot.Icons[k].URL = v.URL
				slot.Icons[k].URLName = v.URLName
				slot.Icons[k].Col = v.Col or Color(255, 255, 255)
				slot.Icons[k].X = v.x or 16
				slot.Icons[k].Y = v.y or 16
				slot.Icons[k].W = v.w or 48
				slot.Icons[k].H = v.h or 48
			end 
		end

	end

	function slot:OnRemove()

	end 


	if f and f.OnNewCell then 
		f:OnNewCell(slot)
	end

	return slot
end

function Inventory.CreateItemSlot(item, par)
	local ow = item:GetOwner()
	local has = ow:HasItem(item:GetUID())

	if not IsPlayer(ow) or not has then error("Player doesn't have this item!") return end 

	return CreateItemSlot(0, 0, item, par)
end

local iTypes = Items.SortTypes

local LastSort = "date"
local LastType = "All"

local fgm = Inventory.FeelsGoodManClap

local sortnames = {
	["name"] = "Name",
	["amt"] = "Amount",
	["date"] = "Date",
	["rar"] = "Rarity(no)",
}

--[[

	Tip: choose heights for this which fall under the formula 
	y = 40 + (i * 88) + (32 to 40)
	where:
		40 is the header size
		"i" is the amt of slots in height you want
		"36 to 44" is "Page x/x" : select any amt there you want 

	For example, 428, 516, 604

]]

local function GetOtherInventory(id)
	return bit.band(id, 1) + 1 	--wtf
end

Inventory.InventoryPanels = Inventory.InventoryPanels or {}

function Inventory.CreateFrame(inv_tbl, offx, offy, context)
	local switchable = not inv_tbl 				--If no inventory was provided, then this frame can switch between vault and temp
	inv_tbl = inv_tbl or Inventory.Data.Temp 	--Then default inventory becomes temp inv

	local defaultoffsets = not offx and not offy
	iTypes = Items.SortTypes
	local f

	if context and IsValid(g_ContextMenu) then 
		f = g_ContextMenu:Add("FFrame")
		f:MoveToAfter(g_ContextMenu)
	else 
		f = vgui.Create("FFrame")
	end

	offx = offx or 44
	offy = offy or 8

	f.RBRadius = 4
	f:SetSize(192, 192) --minimum
	f:Center()

	hook.Add("InventoryUpdate", f, function(f)
		f:UpdateItems()
		f:Update(true)
	end)

	f.Inventory = inv_tbl

	f.Items = {}
	f.Exclude = {}

	f.Shadow = {spread=2, intensity=2}
	local fW, fH = 192, 192

	f.m_bCloseButton:SetVisible(false)--:Remove()
	f.HeaderSize = 40
	local ta = 255
	local tr

	local pages = {}

	f.Pages = pages 
	f.QueuedForCreation = {}

	local items = {}

	f.Curpage = 1
	local InvFrame = f

	if switchable then 
		local switch = vgui.Create("FButton", InvFrame)
		InvFrame.SwitchBtn = switch 

		switch:SetSize(32, 32)
		switch:SetPos(4, 4)

		function switch:PostPaint(w, h)
			surface.SetDrawColor(color_white)
			surface.DrawMaterial("https://i.imgur.com/Kr2xpAj.png", "swap_inv.png", 4, 4, w-8, h-8)
		end

		function switch:OnHover()
			if not self.Cloud then 
				local cl = vgui.Create("Cloud")
				self.Cloud = cl 
				cl:Bond(self)
				cl:MoveAbove(self, 4)
				cl:Popup(true)

				local inv = GetOtherInventory(f.Inventory:GetID()) --Other inventory. Stfu about the maths.
				
				cl:SetLabel("Switch to " .. Inventory.InventoryNamings[inv])
			end
		end

		function switch:OnUnhover()
			self.Cloud:Popup(false)
		end

		function switch:DoClick()
			if not self.Cloud then self:OnHover() end 

			for k, page in pairs(pages) do 
				for uid, item in ipairs(page.Cells) do 
					if not ispanel(item) or not IsValid(item) then continue end --w/e

					item:PopOut()
				end 
				table.Empty(page.Cells)
				page:ResetOffsets()
			end 

			f.Inventory = Inventory.GetByID(GetOtherInventory(f.Inventory:GetID()))

			local inv = f.Inventory:GetID()
			self.Cloud:SetLabel("Switch to " .. Inventory.InventoryNamings[inv])

			f:CreateItems(true)
		end
	end 

	function f:PostPaint(w,h)
		--self:DrawHeaderPanel(w,h)
		fW, fH = self:GetSize()

		local name = self.Inventory:GetName()

		draw.SimpleText(name, "R36", w/2, 0, Color(255,255,255,ta), 1, 5)

		draw.SimpleText("Page " .. f.Curpage .. "/" .. math.max(#pages, 1), "TWB28", w/2, h - 2, Color(255,255,255, 255), 1, 4)

		if not f.Created then 
			draw.SimpleText("did you forget to call f:CreateItems()?", "TW24", w/2, h/2, Color(255,255,255,80), 1, 2)
		end

	end

	f.InventorySorted = {}

	function f:SortItems(func, num)
		self.InventorySorted[num or (#self.InventorySorted + 1)] = func
	end

	function f:RemoveSort(num)

		if not num then 
			table.Empty(self.InventorySorted)
		else 
			table.remove(self.InventorySorted, num)
		end

	end

	local sX, sY = offx - 88, offy
	

	local function CreatePage(i)

		pages[i] = vgui.Create("InvisPanel", f)

		local fr = pages[i]
		fr:MoveToFront()
		fr:SetMouseInputEnabled(true)
		fr:SetSize(fW, fH)
		fr:SetPos(-fW + fW * i, f.HeaderSize)
		fr.Cells = {}
		fr.Main = f
		function fr:Update()
			fr:SetSize(fW, fH)        
		end

		local sX, sY = offx - 88, offy

		function fr:OnActive(popin)
			
			for k,v in ipairs(self.Cells) do 
				sX = sX + 88

				if sX + 80 > fW then 
					sX = offx
					sY = sY + 88
				end

				if istable(v) then 
					if v.HasCoords then 
						self.Cells[k] = CreateItemSlot(unpack(v))
						self.Cells[k].PageKey = k

						if popin then 
							self.Cells[k]:PopIn()
						end
					else
						self.Cells[k] = CreateItemSlot(sX, sY, unpack(v))
						self.Cells[k].PageKey = k

						if popin then 
							self.Cells[k]:PopIn()
						end
					end


					self.Cells[k].Page = i

				end
			end
		end

		function fr:Think()
			self.X = L(self.X, fW * (i - f.Curpage), 10, true)
			if #self.Cells == 0 and i ~= 0 then 
				self:Remove()
				table.remove(pages, i)

				if f.CurPage == i then 
					f.CurPage = i - 1
				end
			end
		end

		function fr:GetCellPos(and_add)
			local newpage = false

			if and_add then
				sX = sX + 88

				if sY + 176 > self:GetTall() and sX + 172 > fW then 

					newpage = true

				end

				if sX + 80 > fW then 
					sX = offx
					sY = sY + 88
				end
				print("current sX, sY now:", sX, sY, newpage, i)
			end

			return sX, sY, newpage
		end

		function fr:ResetOffsets()

			sX = offx - 88 
			sY = offy

		end
	end

	function f:SetPage(pg, anim)
		if not pages[pg] then return end
		if anim then 
			self.Curpage = pg 
		else
			for k,v in pairs(pages) do 
				v.X = fW * (k - pg)
			end 
			self.Curpage = pg
		end
		pages[pg]:OnActive()
	end

	

	local page = 1
	

	local bk, fwd 

	function f:UpdateItems()

		page = 1

		local temp = {}	--this is godawful by the way, but has to be done to keep the table references instead of new tables, unfortunately
		local sX, sY = offx - 88, offy

		local temp2 = {}

		local results = {} 

		if #self.InventorySorted>0 then 

			for _, val in pairs(self.Inventory) do 
				temp[#temp+1] = val
			end

			for num,func in SortedPairs(self.InventorySorted) do

				table.sort(temp, func) --sort

			end

			for _, val in SortedPairs(temp) do --put the results in
				results[#results + 1] = val
			end
			
		else 
			results = self.Inventory
		end


		for _,v in SortedPairs(results) do 

			local item = Items[v.ItemID]
			if not item then continue end 
			local k = v.ItemUID 

			if IsValid(items[k]) then 
				items[k]:Remove()
			end

			sX = sX+88

			if sX+80 > fW then 
				sX = offx
				sY = sY + 88
			end

			if sY >= fH - 88 then 
				sX = offx 
				sY = offy
				page = page+1
			end

			if not pages[page] then 
				CreatePage(page)
			end

			local key = #pages[page].Cells + 1

			local s = {v, pages[page], self, page, key = key}

			s.DeHighlight = function(self, b)
				self.Dehighlight = b
			end

			if not pages[page].Cells[key] then 

				pages[page].Cells[key] = s
				self.QueuedForCreation[v.ItemUID] = s

			else 

			end
			--s.Page = page 
		end

		return sX, sY
	end

	function f:CreateItems(popin)
		f.Created = true

		local sX, sY = self:UpdateItems()

		fW, fH = self:GetSize()
		fH = fH - f.HeaderSize - 8

		
		fwd = vgui.Create("FButton", f)
		fwd:SetSize(24, 60)
		fwd:SetPos(fW - 24, fH/2 - 30)
		fwd:SetColor(Color(50, 150, 255))
		fwd.RBRadius=4
		fwd.ShadowMaxSpread = 0.5
		fwd.DoClick = function()
			if f.Curpage < #pages then 

				f.Curpage = f.Curpage+1
				pages[f.Curpage]:OnActive()
			end
		end

		fwd:MoveToAfter(pages[#pages])
		fwd:SetDoubleClickingEnabled(false)
		local hovtime

		fwd:Receiver("ItemDrop", function(self, pnls, drped)
			if drped then hovtime = nil return end 
			hovtime = hovtime or CurTime()
			if CurTime() - hovtime > 0.6 then 
				self:DoClick()
				hovtime = nil
			end
		end)

		f.Forward = fwd 

		bk = vgui.Create("FButton", f)
		bk:SetSize(24, 60)
		bk:SetPos(0, fH/2 - 30)
		bk:SetColor(Color(50, 150, 255))
		bk.RBRadius=4
		bk.ShadowMaxSpread = 0.5
		bk.DoClick = function()
			if f.Curpage~=1 then 

				f.Curpage = f.Curpage-1
				pages[f.Curpage]:OnActive()
			end
		end
		bk:MoveToAfter(pages[#pages])
		bk:SetDoubleClickingEnabled(false)
		bk:Receiver("ItemDrop", function(self, pnls, drped)
			if drped then hovtime = nil return end 
			hovtime = hovtime or CurTime()
			if CurTime() - hovtime > 0.6 then 
				self:DoClick()
				hovtime = nil
			end
		end)
		
		f.Back = bk

		local _ = (pages[1] and pages[1]:OnActive(popin))
	end

	function f:DisableFilter()
		self.Exclude = {}
		self:ColorTo(Color(50, 50, 50), 0.3, 0)
		self:Update()
	end
	function f:SetFilter(type)

		local sort = Items.SortTypes[type]
		self.Exclude = {}

		for k,v in pairs(self.Inventory) do 
			local typ = v:GetItem().type
			if not sort.falls[typ] then
				self.Exclude[k] = true 
			end
		end

		for k,v in pairs(self.Items) do 

			if self.Exclude[k] then 

				print("gtfo", k, typ, v.Item.ItemUID)

				v:PopOut() 

				pages[v.Page].Cells[v.PageKey] = nil

				self.Items[k] = nil 

				if self.ExistingCells then 
					self.ExistingCells[k] = nil 
				end

				continue 
			end

		end

		self:Update()
	end

	function f:OnChangedSize(nw, nh)
		fW, fH = nw, nh
		

		

		if defaultoffsets then 
			offx = nw%88 / 2 + 4
			offy = nh%88 / 4
		end

		local sX, sY = offx - 88, offy

		for uid,item in pairs(self.Items) do --classic copypasting

			sX = sX+88

			if sX+80 > fW then 
				sX = offx
				sY = sY + 88
			end

			if sY > fH - 88 then 
				sX = offx 
				sY = offy
				page = page+1
			end

			if not pages[page] then 
				CreatePage(page)
			end

			item:SetParent(pages[page])
			item:SetPos(sX, sY)
		end
		for k,v in pairs(pages) do
			v:Update()
		end
		
		if bk then 
			bk:SetPos(0, nh/2 - 30)
			bk:MoveToFront()
		end 
		if fwd then 
			fwd:SetPos(nw-24, nh/2 - 30)
			bk:MoveToFront()
		end
	end

	function f:GetItems()

		return self.Items

	end
	function f:Update(nicemove)
		local nw, nh = self:GetSize()

		if defaultoffsets then 
			offx = nw%88 / 2 + 4
			offy = nh%88 / 4
		end
		local page = 1

		local results = {}
		local temp = {}

		if #self.InventorySorted>0 then 

			for _, val in pairs(self.Inventory) do 
				if self.Exclude[val.ItemUID] then continue end
				temp[#temp+1] = val	
			end

			for num,func in SortedPairs(self.InventorySorted) do

				table.sort(temp, func) --sort

			end

			for _, val in SortedPairs(temp) do 
				results[#results + 1] = val
			end
			
		else 

			results = self.Inventory
		end

		local existingcells = self.ExistingCells or {}
		self.ExistingCells = existingcells

		for k,v in ipairs(pages) do
			v:ResetOffsets()

			for k,v2 in pairs(v.Cells) do 
				if ispanel(v2) then 
					existingcells[v2.Item.ItemUID] = v2 
				end 
			end 

			v.Cells = {}
		end

		for k,item in SortedPairs(results) do --i have no idea if sorting actually helps

			local uid = item.ItemUID 
			local curpage = pages[page]

			if not pages[page] then 
				CreatePage(page)
				curpage = pages[page]
			end

			local move
			local slot 

			if IsValid(existingcells[uid]) then  --A cell with this UID was already created; just assign it to a new page

				if self.Curpage == page then

					local cell = existingcells[uid]
					cell:SetParent(curpage)

					local pX, pY = cell:LocalToScreen(0, 0)
					local nX, nY, newpg = curpage:GetCellPos(true)

					curpage.Cells[#curpage.Cells + 1] = cell
					cell.PageKey = #curpage.Cells

					move = {pX, pY, nX, nY}

					if newpg then 
						page = page + 1 
					end
					slot = cell

				else                   -- cell exists but it's not required on the current page so might as well set it to it's proper parent

					local cell = existingcells[uid]
					cell:SetParent(pages[page])

					local pX, pY = cell:LocalToScreen(0, 0)
					local nX, nY, newpg = curpage:GetCellPos(true)

					curpage.Cells[#curpage.Cells + 1] = cell
					cell.PageKey = #curpage.Cells

					move = {pX, pY, nX, nY}
					cell:SetPos(nX, nY)

					if newpg then 
						page = page + 1 
					end
  
					continue
				end

			else 

				if self.QueuedForCreation[uid] then -- This cell is queued for creation...

					if self.Curpage == page then                                        -- ... and should be displayed on the current page
						local t = self.QueuedForCreation[uid]
						local sX, sY, newpg = pages[page]:GetCellPos(true)

						slot = CreateItemSlot(sX, sY, item, pages[page], self)
						slot.Page = page

						curpage.Cells[#curpage.Cells + 1] = slot
						slot.PageKey = #curpage.Cells
						move = {ScrW(), sY, sX, sY}

						if newpg then 
							page = page + 1
						end

					else     
																			   -- ... or is not necessary yet
						local sX, sY, newpg = pages[page]:GetCellPos(true)

						pages[page].Cells[#pages[page].Cells + 1] = {sX, sY, item, pages[page], self, page, ["HasCoords"] = true}

						if newpg then 
							page = page + 1 
						end

						continue
					end

				else 
					error("is the fucking cell gone")
				end


			end
		   
			local prevp = slot.Page

			local prevx, prevy = slot.X, slot.Y
			slot:SetParent(curpage)
			slot.Page = page 
			
			if not nicemove and move then 

				slot:SetPos(move[3], move[4])

			elseif nicemove and move then
				local pX, pY = curpage:ScreenToLocal(move[1], move[2])
				local nX, nY = move[3], move[4]

				slot:SetPos(pX, pY)

				local dist = math.Distance(pX, pY, nX, nY)

				slot:MoveTo(nX, nY, math.sqrt(dist*0.0004), 0, 0.25)
			end
			
		end
		for k,v in pairs(pages) do
			v:Update()
		end

	end
		
	local rem = {}

	function f:AddRemoveablePanel(pnl)
		rem[#rem+1] = pnl
	end

	function f:EnableSorting(b, del)

		if b==nil or b then 
			local InvFrame = self 

			local s = vgui.Create("InvisPanel")
			self.Sorting = s

			s:SetSize(self:GetWide(), 140)
			s:SetPos(self:LocalToScreen(0, 0))

			local lTo = -100

			s.Lerp = true

			function s:Paint(w, h)
				--draw.RoundedBox(4, 0, 0, w, h, Color(30, 30, 30))
				if not IsValid(f) then self:Remove() return end
				local px, py = f:LocalToScreen(0, 0)

				if self.Lerp then 
					self.OffY = L(self.OffY, lTo, 10)
				end

				self:SetPos(px + (self.OffX or 0), py + (self.OffY or 0))
			end

			self:AddRemoveablePanel(s)
			local i = 0
			for k,v in pairs(iTypes) do 
				i = i + 1
				local b = vgui.Create("DButton", s)
				b:SetSize(60, 140)
				b:SetPos(-60 + 68*i, 40)
				b:SetText("")
				b.Type = k
				if LastType == k then
					b.LY = 0
				else 
					b.LY = 20 
				end

				local icon = ((v.icon and v.icon.url and #v.icon.url > 0) and v.icon.url) or "-"
				local iname = ((v.icon and v.icon.name and #v.icon.name > 0) and v.icon.name) or "-"
				local iw, ih = (v.icon and v.icon.w) or 48, (v.icon and v.icon.h) or 48
				local iy = (v.icon and v.icon.y) or 8

				function b:Paint(w, h)
					draw.RoundedBox(8, 0, 0, w, h+12, Color(120, 120, 120))
					draw.RoundedBox(8, 4, 4, w-8, h+12, Color(60, 60, 60))

					surface.SetDrawColor(Color(255, 255, 255))
					surface.DrawMaterial(icon, iname, (60 - iw)/2, iy, iw, ih) --"https://i.imgur.com/y6YD9CV.png"

					if LastType == k then
						b.LY = 0
					else 
						b.LY = 40 
					end

					self.Y = L(self.Y, self.LY, 20, true)
				end

				function b:DoClick()
					if LastType==self.Type then 
						InvFrame:DisableFilter()
						LastType = "All"
						return
					end
					LastType = self.Type 
					InvFrame:ColorTo(v.col or InvFrame.Color, 0.2, 0)
					InvFrame:SetFilter(LastType)
				end
			end
			return self.Sorting
		end

		if IsValid(self.Sorting) then
			self.Lerp = false
			self.Sorting:InElastic(0.4, 0, function(anim, pnl, var)
				if not IsValid(pnl) or not IsValid(f) then self:Remove() return end 

				local px, py = f:LocalToScreen(0, 0)
				
				self.OffY = -100 + 100*var
				pnl:SetPos(px, py + self.OffY)

			end, function(anim, pnl)
				if not IsValid(pnl) then return end 
				pnl:Remove()
			end, 1.1, 2, 1.8)

			self.Sorting = nil 

		return end 

	end

	function f:OnRemove()
		for k,v in pairs(rem) do 
			if IsValid(v) then v:Remove() end 
		end
	end
	
	return f
end

--[[
See Inventory.OpenFull @ cl_charpanel.lua (currently @ cl_renderequipment.lua)
]]