--yeet
Inventory = Inventory or {}
if IsValid(InvContextPnl) then InvContextPnl:Remove() end  
InvContextPnl = nil
ContextcOpen = false 

local fgm = Inventory.FeelsGoodManClap

local sortnames = {
    ["name"] = "Name",
    ["amt"] = "Amount",
    ["date"] = "Date",
    ["rar"] = "Rarity(no)",
}

local lightemup = Inventory.HaloEnts or {}

hook.Add("PreDrawHalos", "Inventory", function()

    for k,v in pairs(lightemup) do 
        if not IsValid(v) then print('fuckin loser') lightemup[k] = nil end 
    end

    halo.Add(lightemup, Color(100, 200, 100), 2, 2, 3, true, true)

end)
local hand = Material("data/hdl/hand.png")
hdl.DownloadFile("https://static.thenounproject.com/png/2372-200.png", "hand.png", function(n) hand = Material(n) end)

local mat = Material("arivia/arivia_button_shipments.png")

local LastSort = "date"
local LastType = "All"

local star = Material("data/hdl/star.png")
hdl.DownloadFile("https://i.imgur.com/Nf3RjTz.png", "star.png", function(fn) star = Material(fn) end)

local iTypes = Items.Types

local LastPage = 1

function Inventory.CreateSortingPanel(ft, f)

    if not iTypes then iTypes = Items.Types end 
    if not iTypes then return end 

    if not fgm then fgm = Inventory.FeelsGoodManClap end 
    if not fgm then return end 

    local hs = 40
    local p = vgui.Create("FFrame", ft)

    p:SetSize(400, 150)
    p:Center()
    p.RBRadius = 6

    p:SetDraggable(false)
    p:SetCloseable(false, true)

    p.Label = "Sorting"

    local off = 0
  
    local tps = vgui.Create("DLabel", p)

    tps:SetPos(4, hs + 6)

    tps:SetText("Type:")
    tps:SetFont("TWB24")
    tps:SizeToContentsX()

    off = off + tps:GetWide() + 12

    surface.SetFont("TW24")

    local selType
    local selSort

    local typeFunc = function(a, b) 
        local t1, t2 = a:GetType(), b:GetType()
        
        if t1==LastType then return true, t2==LastType end 
        return false 
    end

    if LastType == "All" then typeFunc = function() return false end end

    local sortFunc = function() return false end 

    local function UpdateSort()
        local sortfunc = function() return false end 

        if selSort or LastSort then 

            local key = (selSort and selSort.sort) or LastSort

            sortfunc = fgm[key]

            if istable(sortfunc) then 
                sortfunc.preeval()
                print('preevalled', key)
                sortfunc = sortfunc.sort
            end
        end
        f:SortItems(function(a, b)
            local ret, ret2 = typeFunc(a, b)

            if (ret==false and ret2==false) or LastType == "All" then
                return sortfunc(a, b)
            end

        end, 1)

        f:SortItems(function(a, b)
            if LastType=="All" then return sortfunc(a, b) end 

            local ret, ret2 = typeFunc(a, b)

            if ret==true and ret2==true then 
                return sortfunc(a, b)
            elseif ret==true then 
                return ret
            end 

            return false
        end, 2)

        for k,v in pairs(f.Items) do 
            if v.Item:GetType() ~= LastType and LastType ~= "All" then 
                v:DeHighlight(true)
            else 
                v:DeHighlight(false)
            end
        end


        f:Update(true)
    end

    for k,v in pairs(iTypes) do 
        local t = vgui.Create("FButton", p)
        t:SetPos(8 + off, hs)
        local tx = surface.GetTextSize(v.mult)

        t.Label = v.mult

        t.Font = "TW24"
        t:SetWide(math.max(tx + 8, 48))
        t:SetTall(32)
        t.Type = k 


        function t:DoClick()
            if selType==self then return end

            if IsValid(selType) then
                selType:SetColor(70, 70, 70)
            end

            self:SetColor(50, 150, 250)

            selType = self 

            typeFunc = function(a, b) 
                local t1, t2 = a:GetType(), b:GetType()
                
                if t1==k then return true, t2==k end 
                return false 
            end
            LastType = k

            UpdateSort()
            
        end
        if LastType==k then 
            t:SetColor(50, 150, 250)
            selType = t
        end
        off = off + t:GetWide() + 12
    end

    local all = vgui.Create("FButton", p)
    all:SetPos(8 + off, hs)
    local tx = surface.GetTextSize("All")

    all.Label = "All"

    all.Font = "TW24"
    all:SetWide(math.max(tx + 8, 48))
    all:SetTall(32)

    function all:DoClick()
        if selType==self then return end

        if IsValid(selType) then
            selType:SetColor(70, 70, 70)
        end

        self:SetColor(50, 150, 250)

        selType = self 

        typeFunc = function(a, b) 
            
            return false 
        end
        LastType = "All"
        UpdateSort()
    end

    

    --selType = all 
    --all:SetColor(50, 150, 250)

    off = off + all:GetWide() + 12


    local srt = vgui.Create("DLabel", p)
    srt:SetText("Sort by:")
    srt:SetFont("TWB24")
    srt:SetPos(4, hs+38+6)

    srt:SizeToContentsX()

    off = srt:GetWide() + 12

    for k,v in pairs(fgm) do 
        local t = vgui.Create("FButton", p)
        t:SetPos(8 + off, hs + 32 + 8)
        local tx = surface.GetTextSize(sortnames[k])

        t.Label = sortnames[k]

        t.Font = "TW24"
        t:SetWide(math.max(tx + 8, 48))
        t:SetTall(32)
        t.Sort = k
        

        if k == LastSort then 
            t:SetColor(50, 150, 250)
            selSort = t 
        end
        --function t:Think()
        --    if LastType == "All" then 
        --        self.Dim = true
        --    end
        --end
        function t:DoClick()
            if selSort==self then return end

            if IsValid(selSort) then
                selSort:SetColor(70, 70, 70)
            end

            self:SetColor(50, 150, 250)

            selSort = self 
            LastSort = k
            UpdateSort()
        end

        off = off + t:GetWide() + 12

        if LastType == "All" then 
            all:DoClick() 
        end
    end

    return p
end

function Inventory.OpenContextMenu()
    if not IsValid(g_ContextMenu) then return end 
    
    local f = Inventory.CreateFrame(Inventory.Data.Temp, nil, nil, true)

    f:SetSize(700, 430)
    f:SetPos(ScrW()/2 - 350, ScrH()-1)

    f.m_bCloseButton:Remove()

    InvContextPnl = f
    
    

    local typeFunc = function(a, b) 
        local t1, t2 = a:GetType(), b:GetType()
                
        if t1==LastType then return true, t2==LastType end 
        return false 
    end

    local function UpdateSort()

        local sortfunc = function() return false end 
        
        if LastSort then 
            sortfunc = fgm[LastSort]

            if istable(sortfunc) then 
                sortfunc.preeval()
                sortfunc = sortfunc.sort
            end
        end

        f:SortItems(function(a, b)
            local ret, ret2 = typeFunc(a, b)

            if (ret==false and ret2==false) or LastType == "All" then
                return sortfunc(a, b)
            end

        end, 1)
        
        f:SortItems(function(a, b)

            if LastType=="All" then return sortfunc(a, b) end 

            local ret, ret2 = typeFunc(a, b)

            if ret==true and ret2==true then 
                return sortfunc(a, b)
            elseif ret==true then 
                return ret
            end 

            return false
        end, 2)

         for k,v in pairs(f.Items) do 
            if v.Item:GetType() ~= LastType and LastType ~= "All" then 
                v:DeHighlight(true)
            else 
                v:DeHighlight(false)
            end
        end

    end
    
    UpdateSort()

    f:CreateItems()
    f:SetPage(LastPage, false)
    
    f.Forward:SetSize(30, 80)
    f.Forward:CenterVertical()
    f.Forward.X = f:GetWide() - f.Forward:GetWide()
    f.Forward.Label = ">"

    f.Back:SetSize(30, 80)
    f.Back:CenterVertical()
    f.Back.Label = "<"
    timer.Simple(0.1, function() if IsValid(f) then 
        f:MakePopup() 
        f:SetKeyboardInputEnabled( false )
        f:SetMouseInputEnabled( true ) 
        end 
    end)

    local ta = 255

    local ehov
    local curdrag
    local dragcol = Color(50, 50, 50)
    local washov = false

    local drag = 0

    local ft-- = vgui.Create("InvisPanel")
   -- ft:SetSize(f:GetSize())
   -- ft:SetPos(f:GetPos())

    --ft:MakePopup()
   -- ft:MoveToFront()
   -- ft:PopIn()

   -- function ft:Paint(w,h)
    --    if not IsValid(f) then self:Remove() return end 
    --    draw.RoundedBoxEx(4, 0, 0, w, h, Color(255, 255, 255, 20), true, true, false, false)
    --end

    local bt = vgui.Create("FButton", f)

    bt:SetPos(700 - 48, 4)
    bt:SetSize(32, 32)
    bt.RBRadius = 4
    function bt:PrePaint(w,h)
        self.Hovered = vgui.GetHoveredPanel() == self
        surface.SetAlphaMultiplier(255) --do not go transparent with ft panel
    end
    function bt:PostPaint(w, h)
        surface.SetDrawColor(55, 155, 235)
        surface.DrawMaterial("https://i.imgur.com/L3XJZrU.png", "filter.png", 4, 4, w-8, h-8)
        surface.SetAlphaMultiplier(1)
    end

    function bt:DoClick()

        --f.Dim = not f.Dim
        f:EnableSorting(not IsValid(f.Sorting))

    end

    local cl = vgui.Create("Cloud", slot)
    f.Cloud = cl

    local cxkey = input.LookupBinding("+menu_context") or "[UNBOUND]"
    local tabkey = input.LookupBinding("+score") or input.LookupBinding("+showscores") or "[UNBOUND]"

    local invtxt = ("%s + %s"):format(cxkey, tabkey):upper() .. " or I" 

    local openinv = vgui.Create("DButton", f)
    openinv:SetSize(48, 48)
    openinv:SetPos(0, f.HeaderSize / 2 - 24)
    openinv:SetText("")

    openinv.DoClick = function(self)
        g_ContextMenu:Close()
        Inventory.OpenFull()
    end
    local bprot = 0

    function openinv:Paint(w, h)

        if self:IsHovered() then 
            bprot = L(bprot, 30, 15)
        else 
            bprot = L(bprot, 0, 15)
        end
        surface.SetDrawColor(Color(255, 255, 255, 255 - ta))
        surface.DrawMaterial("https://i.imgur.com/z4doImC.png", "backpack.png", w/2, h/2, w, h, bprot)
    end

    local lastHov = 0

    function f:PostPaint(w,h)
       -- self:DrawHeaderPanel(w,h)
        local cmo = ContextMenuOpen
        local mx, my = input.GetCursorPos()
        local x, y = self.X, self.Y
        local ft = IsValid(ft) and ft or false
        self.Shadow = {spread=(255-ta)/125, intensity=(255-ta)/100}
        local hov = false 

        if mx>x-24 and mx<x+w+24 then 
            local yoff = 12 
            if self.Sorting then yoff = 12 + 120 end
            if my>y-yoff then 

                hov = true 
                lastHov = CurTime()
                --[[if not washov then 
                    
                    if ft then 
                        ft:MoveToFront()
                        ft:SetKeyBoardInputEnabled(false)
                    end

                end]]
            end 
        end
        if not hov then g_ContextMenu:SetMouseInputEnabled(true) else g_ContextMenu:SetMouseInputEnabled(false) end    --it seems like because the context panel was popped up, shit breaks


        if not hov and lastHov + 0.2 > CurTime() then 
            hov = true
        elseif not hov and lastHov + 0.2 < CurTime() then
            lastHov = 0 
        end
        --this inventory system is quickly turning into a hack on top of a hack on top of a hack
        

        washov = hov
        

        if cmo and (hov or CurTime() - drag < 2) then
            self.Y = L(self.Y, ScrH() - 420, 8, true)
            ta = L(ta, 0, 20)
            --bt:SetAlpha(L(bt:GetAlpha(), 255, 10, true))
        elseif cmo then
            self.Y = L(self.Y, ScrH() - 40, 8, true)
            if y>ScrH()-100 then 
                ta = L(ta, 255, 15)
            end
            --bt:SetAlpha(L(bt:GetAlpha(), 0, 10, true))
        elseif not cmo then
            --self:Remove() return
        end

        draw.SimpleText("Inventory", "R36", w/2, 0, Color(255,255,255,ta), 1, 5)

        draw.SimpleText("Page " .. f.Curpage .. "/" .. math.max(#f.Pages, 1), "OS28", w/2, f.HeaderSize/2, Color(255,255,255, 255 - ta), 1, 1)



        draw.SimpleText(invtxt, "OS18", 56, f.HeaderSize/2, Color(255,255,255, (255 - ta)/4), 0, 1)

        if curdrag then 
            
            local mx, my = gui.MousePos()
            local x,y = self:ScreenToLocal(mx, my)
            cl:SetAbsPos(mx + 8, my - 64) --4 is the rounded box radius
            cl:Popup(true)
            cl.YAlign = 0
            cl.MaxW = 512
            cl:SetLabel(curdrag)

            curdrag = false 
            cl:SetColor(LC(cl.Color, dragcol, 10))
        else 

            cl:Popup(false)

        end

       if ft then ft:SetPos(self:GetPos()) end

    end
    local dima = 0
    function f:PaintOver(w,h)

        if self.Dim then 
            dima = L(dima, 230, 10, true)
        else 
            dima = L(dima, 0, 10, true)
        end

        draw.RoundedBox(self.RBRadius, 0, 0, w, h, Color(0, 0, 0, dima))

    end

    function f:OnRemove()
        if IsValid(self.Cloud) then self.Cloud:Remove() end
        lightemup[1] = nil
    end

    function f:Think()

        local tr = LocalPlayer():GetEyeTrace()

        local e = tr.Entity 

        if ehov and ehov~=e  then
            if ehov.OnUnhover then  
                ehov:OnUnhover() 
            end

            if e.OnHover then 
                e:OnHover() 
            end 
        end

        ehov = e

        if not e.ContextInteractable then return end 

    end

  
   

    -------------------------
    for k,slot in pairs(f:GetItems()) do
        local v = slot.Item

        function slot:OnStartDragging()
            -- self:SetWorldClicker(true)
            self.IsDragged = true

        end

        


        function slot:Think()

            if self.IsDragged then 
                drag = CurTime()
                local tr = util.QuickTrace( LocalPlayer():GetShootPos(), gui.ScreenToVector( gui.MousePos() ) * 256, LocalPlayer() )
                if IsValid(tr.Entity) and tr.Entity.ContextInteractable then 
                    --if tr.Entity.CanInteractItem and tr.Entity:CanInteractItem(v) then 
                        local e = tr.Entity

                        lightemup[1] = e
                        self.DraggedOnEntity = e

                         if e.OnItemHover then 

                            local desc, ok = e:OnItemHover(self.Item)
                            if desc then 

                                --if self.Hovered then return end --what the fuck drag&drop???
                                curdrag = desc
                                dragcol = (ok==false and Color(80, 50, 50)) or Color(50, 50, 50)

                            end 

                        end 
                    --end

                else 

                    lightemup[1] = nil
                    self.DraggedOnEntity = nil

                end

            end

        end

        local item = Items[v:GetID()]

        function slot:OnStopDragging()
            if not self.IsDragged then return end --cancer, but for some reason this is double-called
            lightemup[1] = nil
            self.IsDragged = false
            local e = self.DraggedOnEntity
            
            if not IsValid(e) or not e.InteractItem or not e.ContextInteractItem then return end 
                
            local sw, sh = self:GetSize()
            local mx, my = gui.MousePos()

                
            local nx, ny = mx - sw/2+8, my - sh/2+8

            local function CreateDummy()
                local dum = vgui.Create("FButton")
                dum:CopyBase(self)
                
                dum:SetPos(nx, ny)
                if item.mdl then 
                    local p = vgui.Create("DModelPanel", dum)
                    p:SetSize(72, 60)
                    p:SetPos(4, 20)
                    p:SetModel(item.mdl.name)
                    p:SetMouseInputEnabled(false)
                    if item.mdl.skin then 
                        p.Entity:SetSkin(item.mdl.skin)
                    end
                    if item.mdl.mat then 
                        p.Entity:SetMaterial(item.mdl.mat)
                    end
                    if item.mdl.col then 
                        p.Entity:SetColor(item.mdl.col)
                    end

                    local mn, mx = p.Entity:GetRenderBounds()
                    local size = 0
                    size = math.max( size, math.abs( mn.x ) + math.abs( mx.x ) )
                    size = math.max( size, math.abs( mn.y ) + math.abs( mx.y ) )
                    size = math.max( size, math.abs( mn.z ) + math.abs( mx.z ) )

                    p:SetFOV( 45 )
                    p:SetCamPos( Vector( size, size, size ) )
                    p:SetLookAt( ( mn + mx ) * 0.5 )

                    if item.mdl.decal then 
                        item.mdl.decal(slot, p, p.Entity)
                    end
                   
                    local mdpnt = item.mdl.tick
                elseif item.icon then 

                end

                return dum, p
            end
            

            local func = e.ContextInteractItem or e.InteractItem 
            local notok = func(e, v, self)

            local dum, p = CreateDummy(dum)

            if notok then 

                local mx, my = self:LocalToScreen(0, 0)
                dum:SetColor(Color(200, 100, 100))
                dum:MoveTo(mx,my, 0.5, 0.1, 0.2)
                dum:AlphaTo(0,0.3,0.15,function(t, self) if IsValid(self) then self:Remove() end end)

            return end 
            
                        

            if p then
                p:SizeTo(60-8, 60-20, 0.2, 0, 0.6, function(t,self) if IsValid(self) then self:Remove() end end)
            end
            dum:SizeTo(60, 60, 0.2, 0, 0.6)
            dum:MoveTo(nx+10, ny+10, 0.2, 0, 0.6)
            dum:AlphaTo(0, 0.4, 0.1, function(t, self) if not IsValid(self) then return end self:Remove() end)

        end
    end


    
end

hook.Add("OnContextMenuOpen", "Inventory", function()

    Inventory.OpenContextMenu()
    ContextMenuOpen = true 
end)

hook.Add("OnContextMenuClose", "Inventory", function()
    local f = InvContextPnl 
    if IsValid(f) then 
        f:SetMouseInputEnabled(false) 
        f:SetKeyboardInputEnabled(false) 
        f:MoveBy(0, f:GetTall() + 2, 0.1, 0, 0.4, function() f:Remove() end)
        f:PopOut()
        LastPage = f.Curpage 
        InvContextPnl:Remove()
    end
    ContextMenuOpen = false 
end)

local tabs = {
    ["+showscores"] = true, 
    ["+score"] = true
}

hook.Add("PlayerBindPress", "OpenInventory", function(ply, cmd, on)
    if not tabs[cmd] or not on then return end 
    local ckey = input.LookupBinding("+menu_context") or "nevermind"
    if not input.IsKeyDown(input.GetKeyCode(ckey)) then return end 

    g_ContextMenu:Close()
    Inventory.OpenFull()
    
    return true
end)