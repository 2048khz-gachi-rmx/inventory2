BaseItem = BaseItem or Class:extend()
BaseItem.IsBaseItem = true 

function BaseItem:Initialize(id, data)
	if data then 
		table.Merge(self, data)
	end

	self.ItemID = id
	self.Listeners = muldim()
end

ChainAccessor(BaseItem, "Name", "Name")

ChainAccessor(BaseItem, "MaxStack", "MaxStack")
ChainAccessor(BaseItem, "Stackable", "Stackable")

ChainAccessor(BaseItem, "ItemIDName", "ID") 		--ID as a string, not as a number

ChainAccessor(BaseItem, "Type", "Type")

function BaseItem:On(event, cb)
	local listeners = self.Listeners:GetOrSet(event)
	listeners:Set(cb, #listeners + 1)
end

BaseItem.on = BaseItem.On 


function BaseItem:Emit(event, ...)
	local listeners = self.Listeners:Get(event)
	if not listeners then return end 

	for k,v in ipairs(listeners) do 
		v(...)
	end
end

function BaseItem:GetID()
	return self.ItemIDName or self.ItemID or self.ID or self:GetName()
end

function BaseItem:Register(cb)
	if not self:GetID() then error("Attempted to register an item without an ItemID!") return end 

	Inventory.CreateNewItem(self:GetID(), self, cb)
	return self
end