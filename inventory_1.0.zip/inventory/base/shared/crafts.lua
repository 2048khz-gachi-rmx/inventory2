Inventory.Crafting = Inventory.Crafting

if not Inventory.Crafting then 
	Inventory.Crafting = {}

	Crafts = {}
	local ctbl = Inventory.Crafting 

	ctbl["guns"] = {singname = "gun", OpenFunc = "OpenBlueprintCraftingMenu"}

	ctbl["utils"] = {singname = "utility item", vow = false, cats = {

		["Economy"] = {},
		["Raiding"] = {},
		["Combat"] = {},

	}, catprio = {	--more priority = appears first
		["Economy"] = 1,
		["Raiding"] = 2,
		["Combat"] = 3,
	}}
end

local ctbl = Inventory.Crafting 
--[[
slot.Icons[1] = {}

slot.Icons[1].mat = item.icon.mat 
slot.Icons[1].URL = v.url
slot.Icons[1].URLName = v.urlname
slot.Icons[1].Col = item.icon.col or Color(255, 255, 255)
slot.Icons[1].X = item.icon.x or 16
slot.Icons[1].Y = item.icon.y or 16
slot.Icons[1].W = item.icon.w or 48
slot.Icons[1].H = item.icon.h or 48]]



local g = ctbl["guns"]
local ut = ctbl["utils"]


local function CreateGunCrafts()
	local rev = weapons.Get("weapon_bf4_44rt")


end

function CreateUtilityCrafts()
	local f = ut.cats.Combat
	local r = ut.cats.Raiding 
	local e = ut.cats.Economy 

end

local overclk = {
	name = "%s Ovrclk.",
	format = true, 
	toformat = function(self)
		local mat = self.perma.var 
		local over = ut.cats.Economy[1].vars
		local name = "L_? L_? L_?"
		for k,v in pairs(over) do 
			if v.id == mat then 
				name = k
			end
		end

		return name
	end,
	type = "consumable",
	icon = {
		[1] = {
			URL = "https://i.imgur.com/DKw6IDz.png",
			URLName = "overclock.png",

			Col = function(self)
				local mat = self.perma.var 
				local over = ut.cats.Economy[1].vars
				local col = Color(255, 0, 0)
				for k,v in pairs(over) do 
					if v.id == mat then 
						col = v.col or Color(200, 200, 200)
					end
				end

				return col
			end,

			x = 10,
			y = 20,
			w = 60,
			h = 60,
		}
	},
}

Inventory.CreateNewItem("overclocker", overclk)

function CreateCrafts()
	CreateGunCrafts()
	CreateUtilityCrafts()

	local f = ut.cats.Combat
	local r = ut.cats.Raiding 
	local e = ut.cats.Economy 

	-- Items:Get\("(.+)\s(\w+)"\)
	-- ->
	-- Items["\L$1_\L$2"]

	-- plus

	-- Items:Get\("(.+)"\)
	-- ->
	-- Items["\L$1"]

	-- :)

	local gb = (Items["gold_bar"])
	local cb = (Items["copper_bar"])
	local sb = (Items["silver_bar"])
	local tb = (Items["tin_bar"])
	local lb = (Items["lead_bar"])
	local ab = (Items["alum_bar"])
	local sulf = (Items["sulfur"])
	local bronze = (Items["bronze_bar"])
		
	f[1] = {
		name = "Blank",
		desc = "Banish bullets",
		mdl = "models/weapons/w_4ist_deagle.mdl",
		amt = 12,
		time = 24,
		id = "blanks",
		perma = {Amount = 50},
		reqs = {
			[gb] = 50,
			[ab] = 30,
			[sulf] = 150,
			[tb] = 70,
		},
		icon = {
			URL = "https://i.imgur.com/OBQ76DH.png",
			name = "blank.png",
			w = 48, 
			h = 48,
			col = Color(255,255,255),
		}
	}

	e[1] = {
		name = "Overclocker",
		desc = "Increases your printers' print rate. 25 uses.",
		amt = 12,
		time = 24,
		id = "overclocker",
		perma = {uses = 25},
		variantname = "var",
		icon = {
			URL = "https://i.imgur.com/DKw6IDz.png",
			name = "overclock.png",
			w = 64,
			h = 64,
			col = Color(250, 250, 100)
		},
		vars = {
			["Golden"] = {
				reqs = {
					[gb] = 75,
					[sb] = 60,
					[cb] = 15,
					[sulf] = 250,
				},
				id = 1,
				desc = "Speed up print rate by 50%",
				col = Color(200, 200, 70)
			},
			["Silver"] = {
				reqs = {
					[sb] = 75,
					[gb] = 10,
					[cb] = 15,
					[sulf] = 150,
				},
				id = 2,
				desc = "Speed up print rate by 30%",
				col = Color(200, 200, 200)
			}
		}
	}

	e[2] = {
		name = "Armor",
		desc = "Durability up brother",
		amt = 12,
		time = 24,
		id = "entarmor",
		reqs = {
			[lb] = 120,
			[cb] = 30,
			[gb] = 5,
			[sb] = 15,
		},
		icon = {
			URL = "https://i.imgur.com/3523WVg.png",
			name = "armor.png",
			w = 64,
			h = 64,
			col = Color(250, 200, 170)
		}
	}

	for _,tbl in pairs(ut.cats) do 
		for _, it in pairs(tbl) do 
			if isstring(it) then continue end --w/e

			if not istable(it) or not it.id then print("didnt find id for", _, it, (istable(it) and it.name), it.id) continue end 

			Crafts[it.id] = it 
		end
	end
end


hook.Add("ReceiveInventoryConsts", "Crafts", CreateCrafts)

if CurTime() > 15 then
	CreateCrafts()
end