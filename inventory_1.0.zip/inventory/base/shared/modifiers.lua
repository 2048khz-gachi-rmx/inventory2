
Inventory.Modifiers = Inventory.Modifiers or {}

if CLIENT then 
	local fonts = {}
	local fams = table.KeysToValues(FontFamilies)

	local function MakeShadowFont(str)
		local size = tonumber(str:match("%d+"))
		local fontfam = str:match("%a+")

		local font = fams[fontfam]
		if not font then print("didn't find font", fontfam) return end

		surface.CreateFont(str .. "Shadow", {
            font = font,
            size = size,
            weight = 400,
            blursize = 3
        })

	end
	MakeShadowFont("OS24")

	-- return true in prepaint to switch coords to screen coords
	-- (useful for shadows)

	Inventory.Modifiers[1] = {
		ID = 1,
		Name = "Venomous",
		col = Color(60, 200, 60),
		prepaint = function(tx, ty, tw, th, lv, self, mod, info)

			local text = info.text 
			local font = info.font

			local col = ColorAlpha(HSVToColor(132, 1, 0.6 + math.sin(CurTime() * 0.5) * 0.1), 150 + math.sin(CurTime()*3) * 70)
			draw.SimpleText(text, "OS24Shadow", tx, ty, col, 0, 5)

		end,

	}

	Inventory.Modifiers[2] = {
		ID = 2,
		Name = "Infernal",
		col = Color(240, 200, 50),
		postpaint = function(tx, ty, tw, th, lv, self, mod, text)
			local sin = math.sin(CurTime()*2)*40
			mod.col = Color(220 + math.abs(sin), 130 + sin/2, 50 + sin/4)
		end,
	}
	--https://i.imgur.com/Qb2pUMi.png bat
	local bats = {}

	Inventory.Modifiers[3] = {
		ID = 3,
		Name = "Leeching",
		eff = {1, 3},
		col = Color(140, 40, 40),
		prepaint = function(tx, ty, tw, th, lv, self)
			local ft = FrameTime() * 100 --more rendertime = more chance 
			local lv = (isbool(lv) and 1) or lv

			for i=1, (1 + (math.modf(ft, 1))) do 

				local r = math.random(0, 10)

				if r < lv and #bats < lv then 
					bats[#bats+1] = {x = math.random(tw*-0.5, 0), y = math.random(th*0.1, th*0.3), size = math.random(16, 24), yaccel = math.random(20, 60), xaccel = math.random(70, 150)}
				end

			end

			local x, y = self:LocalToScreen(tx, ty)

			render.SetScissorRect(x, y, x+tw, y+th, true)

				for k,v in pairs(bats) do
					surface.DrawMaterial("https://i.imgur.com/Qb2pUMi.png", "crafting/bat.png", tx + v.x, ty + v.size + v.y, v.size, v.size)
					bats[k].x = bats[k].x + FrameTime() * v.xaccel
					bats[k].y = bats[k].y - FrameTime() * v.yaccel

					if tx + bats[k].x - v.size > tw then 
						bats[k] = nil 
						continue
					end
					if ty + bats[k].y + v.size*2 < ty then 
						bats[k] = nil 
						continue
					end
				end

			render.SetScissorRect(0, 0, 0, 0, false)

		end,

		postpaint = function(tx, ty, tw, th, lv, self)


		end,
	}


end