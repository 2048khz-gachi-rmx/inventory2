invobj = invobj or Class:callable()
local invmeta = invobj.Meta 

Inventory.InventoryMeta = invobj

Inventory.InventoryValues = Inventory.InventoryValues or {}

local invs = Inventory.InventoryValues

function invmeta:Initialize(ply, name, id, sqlname)
	invs[self] = {Name = name, ID = id, Owner = ply, SQLName = sqlname}
end

function invmeta:GetName()
	return invs[self].Name
end

function invmeta:GetID()
	return invs[self].ID
end

function invmeta:GetOwner()
	return invs[self].Owner 
end

function invmeta:GetSQLName()
	return invs[self].SQLName 
	end

function invmeta:GetItems(iid)
	iid = isnumber(iid) and iid or Inventory.StringToID[iid]
	if not iid then error("No such item exists! " .. iid) return end

	local ret = {}

	for k,v in pairs(self) do 
		if v.ItemID == iid then 
			ret[k] = v 
		end
	end

	return ret
end

--don't get fooled by its' simplicity, it takes about 0.001ms per call for this

function invmeta:GetItemCount(iid)
	
	local cnt = 0

	for k,v in pairs(self:GetItems(iid)) do 
		cnt = cnt + (v.ItemAmount or 0)
	end

	return cnt
end

if SERVER then include("inventory/base/server/metas/inv_meta.lua") end