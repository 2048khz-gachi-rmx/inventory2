--[[
	This gets called by server and client.
]]

itemfuncs.__tostring = function(self)
	local str = "Item \"%s\"; ItemID: %d; ItemUID: %d"
	str = str:format(self:GetName() or "[no name?]", self:GetID() or -1, self:GetUID() or -1)

	return str
end

itemfuncs.IsItem = true

function IsItem(t)
	return (istable(t) and t.IsItem)
end

function IsBaseItem(t)
	return (istable(t) and t.IsBaseItem)
end

function itemfuncs:GetItem()
	return Items[self.ItemID]
end

itemfuncs.GetBase = itemfuncs.GetItem 
itemfuncs.GetBaseItem = itemfuncs.GetItem

if SERVER then 
	
	function itemfuncs:GetName()
		return self:GetItem().name or "WTF?"
	end

else 

	function itemfuncs:GetName()
		local it = self:GetItem()
		if it.format and it.toformat then 
			return string.format(it.name or "???", it.toformat(self) or "unformatted")
		end
		return self:GetItem().name or self:GetItem().Name or "WTF?"
	end

end

function itemfuncs:GetType()
	return self:GetItem().type or "WTF?"
end

function itemfuncs:GetPermaStat(k, def)
	return self.perma[k] or def
end

ChainAccessor(itemfuncs, "__belongs_tbl", "Belongs")
ChainAccessor(itemfuncs, "__belongs_tbl", "BelongsTo")

ChainAccessor(itemfuncs, "__belongs_id", "BelongsID")
ChainAccessor(itemfuncs, "__belongs_id", "BelongsToID")

--[[
function itemfuncs:CreateGetFuncs()
	if not self.GetItem or not istable(self:GetItem()) then return end 

	for k,v in pairs(self:GetItem()) do 
		if k[1] and k[1] ~= k[1]:upper() then continue end --Only values that start with an uppercase get a GetX function

		AccessorFunc(self, k, k)

		--if itemfuncs["Get" .. k] then continue end --Functions that were defined by itemfuncs don't get one
		
		--self["Get"..k] = function() return v end 
	end

end
]]

itemfuncs.CreateGetFuncs = Deprecated 

function itemfuncs:GetID()
	return self.ItemID
end

itemfuncs.GetItemID = itemfuncs.GetID

function itemfuncs:GetUID()
	return self.ItemUID
end

function itemfuncs:GetAmount()
	return self.ItemAmount
end

function itemfuncs:SetMeta(meta)

	if not meta then 
		local smeta = self.specialMeta
		meta = (istable(smeta) and smeta) or (isstring(smeta) and _G[smeta]) or itemmeta
	end

	setmetatable(self, meta)
end

if CLIENT then

	function itemfuncs:SetAmount(num)
		if not self:GetAmount() then print("cursed", self:GetUID()) return end
		self.ItemAmount = num
	end
	function itemfuncs:DeleteItem()

	end

	function itemfuncs:TakeAmount(num)
		if not self:GetAmount() then print("no?", self:GetUID()) return end 
		local oldamt = self:GetAmount()
		self:SetAmount(math.max(oldamt - num), 0)
		--let the server send us the item deleted state instead of predicting it,
		--cuz it'd be hard to restore it if we're wrong
	end
end

function itemfuncs:GetRefined()
	return self:GetItem().refTo or false 
end 

function itemfuncs:GetRefinedItem()
	return Items[self:GetItem().refTo] or false 
end

function itemfuncs:GetPermaStats()
	return self.perma
end

itemfuncs.GetPerma = itemfuncs.GetPermaStats

function itemfuncs:GetRefinedRatio()
	local rit = Items[self:GetRefined()] or Items[Inventory.StringToID[self:GetRefined()] ]
	local req = self:GetItem().reqtr
	local res = rit.res
	return req, res
end

function itemfuncs:GetAlias()
	return self:GetItem().alias
end

function itemfuncs:IsSoulbound()
	return self:GetItem().SoulBound or self.perma.soulbound or false 
end

function itemfuncs:IsEquippable()
	return self:GetItem().Equippable
end

function itemfuncs:IsStackable()
	return self:GetItem().stackable
end

function itemfuncs:GetSlot()
	return self:IsEquippable() and self:GetItem().Slot
end

