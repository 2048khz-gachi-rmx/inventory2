--note that this launches before serverside and clientside inventory init
Items.Types = {
	["bar"] = {name = "Bar", mult = "Bars"},
	["gun"] = {name = "Gun", mult = "Guns"},
	["ore"] = {name = "Ore", mult = "Ores"},
	["consumable"] = {name = "Consumable", mult = "Consumables"},
}

Items.SortTypes = {
	["mats"] = {
		name = "Material", 
		mult = "Materials", 
		col = Color(30, 25, 50),
		icon = {
			url = "https://i.imgur.com/ViLauHO.png",
			name = "crmats.png",
			w = 40,
			h = 40,
			y = 10
		},
		falls = {bar = true, ore = true}
	},

	["consumables"] = {
		name = "Consumable", 
		mult = "Consumables", 
		col = Color(20, 50, 20),
		icon = {
			url = "",
			name = ""
		},
		falls = {consumable = true}
	},

	["guns"] = {
		name = "Weapon", 
		mult = "Weapons", 
		col = Color(50, 30, 30),
		icon = {
			url = "https://i.imgur.com/Lavjvin.png",
			name = "gun.png",
			w = 40,
		},

		falls = {gun = true}
	}

}

ITEM_DELETED = 0
ITEM_MOVED = 1

ITEM_TEMP = 0
ITEM_VAULT = 1
ITEM_PERMA = 2

ITEM_FULL = 0
ITEM_CHANGES = 1


--Names for getting inventory name by an ID for indexing within player.Inventory

Inventory.InventoryIDs = {
	[3] = "Perma",
	[2] = "Vault",
	[1] = "Temp",
}


Inventory.InventoryNames = table.KeysToValues(Inventory.InventoryIDs)

Inventory.Ores = Inventory.Ores or {}
Inventory.InventoryNamings = {	--for VGUI
	[1] = "Backpack",
	[2] = "Vault",
	[3] = "Permanent"
}