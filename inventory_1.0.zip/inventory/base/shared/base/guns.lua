local guns = {}
Inventory.Guns = Inventory.Guns or {}
Inventory.GunClasses = Inventory.GunClasses or {}
function Inventory.AddGun(tbl)
	local gun = {}
	gun.Class = tbl.Class or error("Missing class!")
	gun.Name = tbl.Name or error("Missing name!")
	gun.mdl = tbl.mdl or {name = "models/weapons/w_pistol.mdl"}
	gun.perma = tbl.perma or error("Missing perma! (At least uses!)")
	gun.permastats = tbl.permastats or {}
	gun.weptype = tbl.weptype or "Undefined"
	gun.ID = tbl.ID or #Inventory.Guns + 1
	gun.Equippable = true 

	gun.type = "gun"

	gun.ServerUse = Inventory.GiveGun	--they're
	gun.ClientUse = Inventory.GiveGun	--different


	local id = tbl.ID or #Inventory.Guns + 1

	Inventory.Guns[id] = gun 
	Inventory.Guns[gun.Name] = gun 
	
	Inventory.GunClasses[gun.Class] = gun 

	--Items[id] = gun
	Inventory.CreateNewItem(id, gun)

	return #Inventory.Guns
end

Inventory.AddGun({
	ID = "m1911",
	Name = "M1911", 
	Class = "cw_m1911", 
	mdl = {name = "models/weapons/cw_pist_m1911.mdl"},
	perma = {uses = 3},

	permastats = {
		{
			type = "rand",
			stat = "dmg",
			[1] = 90,
			[2] = 120,
		},
		{
			type = "rand",
			stat = "acc",
			[1] = 90,
			[2] = 120,
		}
	},
	weptype = "Pistol",
	Slot = "secondary",
	mods_compat = {
		[1] = true,
	},

	mods_incompat = {
		[2] = true,
	}

})

Inventory.AddGun({
	ID = "makarov",
	Name = "PM", 
	Class = "cw_makarov", 
	mdl = {name = "models/cw2/pistols/w_makarov.mdl"},
	perma = {uses = 25},

	permastats = {
		{
			type = "rand",
			stat = "dmg",
			[1] = 90,
			[2] = 120,
		},
		{
			type = "rand",
			stat = "acc",
			[1] = 90,
			[2] = 120,
		}
	},
	weptype = "Pistol",
	Slot = "secondary",
	mods_compat = {
		[1] = true,
	},

	mods_incompat = {
		[2] = true,
	}

})

--function SWEP:ClearStatCache(vn)
Inventory = Inventory or {}




Inventory.TurnToBlueprints(guns)


for k,v in pairs(guns) do 
	local tbl = table.Copy(v)
	
	tbl.UseFunc = function(self, ply)
		local wep = ply:Give(self:GetClass())
		local uses = self:GetPermaStat("uses", -3)

		if uses==-3 then error('gun '..self:GetName()..' has no uses stat!') return end 
		if uses-1 <= 0 then self:DeleteItem() print('deleted,',uses) return end

		if self:GetPermaStat("dmg", false) then 

			Inventory.ApplyDamage(wep, self:GetPermaStat("dmg") - 100)

		end

		self:SetPermaStat("uses", uses-1)
		self:Network()
	end

	tbl.Usable = true 
	tbl.type = "gun"
	Inventory.CreateNewItem(k, tbl)--Items[k] = tbl

	Inventory.AddOnTo("Guns", k, tbl)

end


