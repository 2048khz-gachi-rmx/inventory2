local off = 10000
local baroff = 1000

--[[
name: string - Display Name
stackable: bool - Is item stackable?(Disables perma stats)
maxStack: number - How many items can one slot contain?
type: string - Type of item? Currently accepatble: bar/ore

mdl: table - {
	name: string - Model name
	skin: number - Skin to set for item
	mat: IMaterial - Material to set for the item
	col: Color - Color to set for the item
	decal: function - A function that'll be ran when the panel is created. Args: Panel slot, Panel mdlPanel, Entity mdlEntity
	tick: function - A function that'll be ran for every tick(Panel:Paint hook). Args: ^
}
res: number - How many items will be the results(for example, reqtr:5, res:1 = 5 ores to 1 bar)
]]

local bars = {
	["copper_bar"] = {name = "Copper Bar", stackable = true, maxStack = 50, type = "bar", mdl = {name = "models/grp/ingots/ingot.mdl", skin = 1}, res = 3},
	["silver_bar"] = {name = "Silver Bar", stackable = true, maxStack = 40, type = "bar", mdl = {name = "models/grp/ingots/ingot.mdl", skin = 2}, res = 2},
	["tin_bar"] = {name = "Tin Bar", stackable = true, maxStack = 75, type = "bar", mdl = {name = "models/grp/ingots/ingot.mdl", skin = 2}, res = 5},
	["lead_bar"] = {name = "Lead Bar", stackable = true, maxStack = 50, type = "bar", mdl = {name = "models/grp/ingots/ingot.mdl", skin = 2}, res = 4},
	["gold_bar"] = {name = "Gold Bar", stackable = true, maxStack = 25, type = "bar", mdl = {name = "models/grp/ingots/ingot.mdl", skin = 2}, res = 2},
	["alum_bar"] = {name = "Aluminum Bar", stackable = true, maxStack = 75, type = "bar", mdl = {name = "models/grp/ingots/ingot.mdl", skin = 2}, res = 5},
	["sulfur"] = {name = "Sulfur", stackable = true, maxStack = 250, type = "bar", mdl = {
		name = "models/weapons/w_bugbait.mdl", 
		skin = 2, 
		col = Color(140, 110, 20),
		mat = "models/props_debris/concretefloor013a",
		 tick = function(i, s, e)
		 	e:SetColor(Color(255, 0, 0, 10))
		 end}, res = 10},

	["bronze_bar"] = {name = "Bronze Bar", stackable = true, maxStack = 60, type = "bar", mdl = {name = "models/grp/ingots/ingot.mdl", skin = 2}, res = 3},

}
--[[
name: string - Display Name
stackable: bool - Is item stackable?(Disables perma stats)
maxStack: number - How many items can one slot contain?
type: string - Type of item? Currently accepatble: bar/ore

mdl: table - {
	name: string - Model name
	skin: number - Skin to set for item
	mat: string - not implemented
}
ttr: number - Time to Refine(in seconds)
reqtr: number - Required to Refine(how many items will go to refine that)
]]

local ores = {
	["copper_ore"] = {
		name = "Copper Ore", 
		maxStack = 150, 
		col = Color(170, 120, 60), 
		mdl = {
			name = "models/zerochain/props_mining/zrms_resource.mdl", 
			skin = 1, 
			decal = function(item, self, ent)
				if item.Item and item.Item:GetAmount() > 80 then 
					ent:SetBodygroup(0,1)
				else 
					ent:SetBodygroup(0,0)
				end
				self:SetColor(Color(220, 220, 220))
			end,
			tick = function(item, self, ent)
				if item.Item and item.Item:GetAmount() > 80 then 
					ent:SetBodygroup(0,1)
				else 
					ent:SetBodygroup(0,0)
				end
			end,
		}, 
		ttr = 15, 
		reqtr = 5,
		refTo = "copper_bar",
	},

	["silver_ore"] = {
		name = "Silver Ore", 
		maxStack = 120, 
		col = Color(185, 205, 220), 
		mdl = {
			name = "models/zerochain/props_mining/zrms_resource.mdl", 
			skin = 2, 
			decal = function(btn, self, ent)
				if btn.Item and btn.Item:GetAmount() > 60 then 
					ent:SetBodygroup(0,1)
				else 
					ent:SetBodygroup(0,0)
				end
			end,
			tick = function(btn, self, ent)
				if btn.Item and btn.Item:GetAmount() > 60 then 
					ent:SetBodygroup(0,1)
				else 
					ent:SetBodygroup(0,0)
				end
			end,
		}, 
		ttr = 25, 
		reqtr = 4,
		refTo = "silver_bar",
	},

	["tin_ore"] = {name = "Tin Ore", stackable = true, maxStack = 200, type = "ore", col = Color(170, 200, 230), mdl = {
		name = "models/zerochain/props_mining/zrms_resource.mdl", 
		skin = 2, 
		decal = function(btn, self, ent)
			if btn.Item and btn.Item:GetAmount() > 90 then 
				ent:SetBodygroup(0,1)
			else 
				ent:SetBodygroup(0,0)
			end
			ent:SetColor(Color(220, 220, 220))

		end,
		tick = function(btn, self, ent)
			if btn.Item and btn.Item:GetAmount() > 90 then 
				ent:SetBodygroup(0,1)
			else 
				ent:SetBodygroup(0,0)
			end
		end,
	}, ttr = 8, reqtr = 5},
	["lead_ore"] = {name = "Lead Ore", stackable = true, maxStack = 200, type = "ore", col = Color(70, 70, 110), mdl = {
		name = "models/zerochain/props_mining/zrms_resource.mdl", 
		skin = 2, 
		decal = function(btn, self, ent)
			if btn.Item and btn.Item:GetAmount() > 90 then 
				ent:SetBodygroup(0,1)
			else 
				ent:SetBodygroup(0,0)
			end
			ent:SetColor(Color(220, 220, 220))

		end,
		tick = function(btn, self, ent)
			if btn.Item and btn.Item:GetAmount() > 90 then 
				ent:SetBodygroup(0,1)
			else 
				ent:SetBodygroup(0,0)
			end
		end,
	}, ttr = 8, reqtr = 3},
	["gold_ore"] = {name = "Gold Ore", stackable = true, maxStack = 200, type = "ore", col = Color(230, 230, 70), mdl = {
		name = "models/zerochain/props_mining/zrms_resource.mdl", 
		skin = 2, 
		decal = function(btn, self, ent)
			if btn.Item and btn.Item:GetAmount() > 90 then 
				ent:SetBodygroup(0,1)
			else 
				ent:SetBodygroup(0,0)
			end
			ent:SetColor(Color(220, 220, 220))

		end,
		tick = function(btn, self, ent)
			if btn.Item and btn.Item:GetAmount() > 90 then 
				ent:SetBodygroup(0,1)
			else 
				ent:SetBodygroup(0,0)
			end
		end,
	}, ttr = 8, reqtr = 5},
	["alum_ore"] = {name = "Aluminum Ore", stackable = true, maxStack = 200, type = "ore", col = Color(255, 255, 255), mdl = {
		name = "models/zerochain/props_mining/zrms_resource.mdl", 
		skin = 2, 
		decal = function(btn, self, ent)
			if btn.Item and btn.Item:GetAmount() > 90 then 
				ent:SetBodygroup(0,1)
			else 
				ent:SetBodygroup(0,0)
			end
			ent:SetColor(Color(220, 220, 220))

		end,
		tick = function(btn, self, ent)
			if btn.Item and btn.Item:GetAmount() > 90 then 
				ent:SetBodygroup(0,1)
			else 
				ent:SetBodygroup(0,0)
			end
		end,
	}, ttr = 8, reqtr = 5},
	["sulfur_ore"] = {name = "Sulfur Ore", stackable = true, maxStack = 200, type = "ore", col = Color(160, 160, 60), mdl = {
		name = "models/zerochain/props_mining/zrms_resource.mdl", 
		skin = 2, 
		decal = function(btn, self, ent)
			if btn.Item and btn.Item:GetAmount() > 90 then 
				ent:SetBodygroup(0,1)
			else 
				ent:SetBodygroup(0,0)
			end

		end,
		tick = function(btn, self, ent)
			if btn.Item and btn.Item:GetAmount() > 90 then 
				ent:SetBodygroup(0,1)
			else 
				ent:SetBodygroup(0,0)
			end
		end,
	}, ttr = 8, reqtr = 5},

	["bronze_ore"] = {name = "Bronze Ore", stackable = true, maxStack = 120, type = "ore", col = Color(180, 150, 90), mdl = {	--alloy-only
		name = "models/zerochain/props_mining/zrms_resource.mdl", 
		skin = 1, 
		decal = function(btn, self, ent)
			if btn.Item and btn.Item:GetAmount() > 90 then 
				ent:SetBodygroup(0,1)
			else 
				ent:SetBodygroup(0,0)
			end

		end,
		tick = function(btn, self, ent)
			if btn.Item and btn.Item:GetAmount() > 90 then 
				ent:SetBodygroup(0,1)
			else 
				ent:SetBodygroup(0,0)
			end
		end,
	}, ttr = 25, reqtr = 3},
}

--[[
	appearchance: in %
	richness: amt of ore in a rock
	minechance: chance that the ore will be awarded to the miner
	wastechance: chance that amt will be spent on a mine
	incompat: {	incompatibility with ores
		{
			with: ID of ore
			[makes: makes what ore when found incompatible?]
			[ratio: if makes, how much is spent to merge? 1 = current ore, 2 = other ore("with")]
			[amt: how much ore will be the result?]
			[frac: how much % of the original ore will actually merge?]

			remove: which of the ores will be removed if found: 1 = current, 2 = other("with")
		}
	}
]]


for k,v in pairs(bars) do 
	local tbl = table.Copy(v)
	tbl.Useable = false 
	tbl.type = "bar"

	if ores[k] then 
		ores[k].refTo = k + off + baroff
		ores[k].type = "ore"
	end

	Inventory.CreateNewItem(k, tbl)
end

for k,v in pairs(ores) do 

	local tbl = table.Copy(v)
	tbl.type = "ore"
	tbl.stackable = true

	Inventory.CreateNewItem(k, tbl)

	if SERVER then Inventory.Ores[k] = tbl end
end