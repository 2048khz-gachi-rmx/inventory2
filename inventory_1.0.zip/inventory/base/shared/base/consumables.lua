local heals = {
	medkit = {name = "MedKit", stackable = true, maxStack = 15, type = "consumable", mdl = {name = "models/Items/HealthKit.mdl"}, res = 2},
	blanks = {name = "Blanks", stackable = true, maxStack = 50, type = "consumable", mdl = {name = "models/Items/HealthKit.mdl"}, res = 2, alias = "Blank"},
}

for k,v in pairs(heals) do 

	local tbl = table.Copy(v)
	tbl.Usable = true 
	tbl.type = "consumable"

	Inventory.CreateNewItem(k, tbl)
	
end