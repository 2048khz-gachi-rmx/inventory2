--placeholder

local PLAYER = FindMetaTable("Player")

function PLAYER:HasEquipped(item)
	local inv = (CLIENT and Inventory.Items) or self.Items
	local eq = (CLIENT and Inventory.Equipped) or self.Equipment
	if not eq then return false end 
	
	if isnumber(item) then --UID
		local uid = item

		local item = inv[uid]
		if not item then return false end 

		local base = item:GetItem()

		local slot = item:IsEquippable() and item:GetSlot()
		if not slot then return false end 

		local equipped = eq[slot]
		if not equipped or equipped:GetUID() ~= uid then return false end 

		return equipped 

	elseif IsBaseItem(item) then

		local slot = item.Equippable and item.Slot 
		if not slot then return false end 

		local it = eq[slot]
		if not it or it:GetID() ~= item.ItemID then return false end 

		return it

	elseif IsItem(item) then 

		local slot = item:IsEquippable() and item:GetSlot()
		if not slot then return false end 

		local equipped = eq[slot]
		if not equipped or equipped:GetUID() ~= item:GetUID() then return false end 

		return equipped

	elseif isstring(item) then --class 
		local item = Items[item]
		if not item then return false end 

		local slot = item.Equippable and item.Slot 
		if not slot then return false end 

		local it = eq[slot]
		if not it or it:GetID() ~= item.ItemID then return false end 

		return it
	end

	return "What"
end