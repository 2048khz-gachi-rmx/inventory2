--hello

ITEM.Name = "Helmet"

ITEM.Model = {
	name = "models/props_survival/upgrades/upgrade_dz_helmet.mdl",
}

ITEM.Render = {

	{
		mdl = "models/props_survival/upgrades/upgrade_dz_helmet.mdl",
		pos = Vector(0, 0, 0),
		ang = Angle(90, 0, -90),
		scale = Vector(1, 1, 1),
		bone = "ValveBiped.Bip01_Head1"
	},

}

ITEM.OnEquip = function()

end

ITEM.OnUnequip = function(self)

end


hook.Add("ScalePlayerDamage", "Equipment.Helmet", function(ply, hg, dmg)
	if not ply:HasEquipped(ITEM) then return end 

	if hg == HITGROUP_HEAD then 
		dmg:ScaleDamage(0.8)
	end
end)