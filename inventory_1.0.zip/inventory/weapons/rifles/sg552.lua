local wep = Inventory.BaseWeapon("cw_sg55x")
	:SetName("SG552")
	:SetID("sg552")
	:SetModel("models/weapons/w_sg550.mdl")
	:SetSlot("primary")

	:Register()

function wep:GetScreenInfo(pos, ang)
	ang:RotateAroundAxis(ang:Right(), 180)
	ang:RotateAroundAxis(ang:Forward(), -20)
	pos = pos + ang:Up() * 0.55 + ang:Forward() * 6 + ang:Right() * -1

	return pos, ang, 0.008
end

return wep