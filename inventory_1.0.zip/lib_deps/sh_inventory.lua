
AddCSLuaFile()

local function inc(str)

	include(str)
	AddCSLuaFile(str)

end

Inventory = Inventory or {}
Inventory.InDev = true 

Items = Items

item = Emitter:extend()  -- Reset item metatable
itemmeta = item 		-- Alias

itemfuncs = item.Meta 

UniqueItems = UniqueItems or {}

local MetaPath = "inventory/base/metas/"

local function IncludeMeta(name)

	local mname = MetaPath .. name

	if file.Exists(mname .. "/_include.lua", "LUA") then --let them handle it
		AddCSLuaFile(mname .. "/_include.lua")
		include(mname .. "/_include.lua")
		return
	end

	FInc.Recursive(mname .. "/shared/*", _SH)

	FInc.Recursive(mname .. "/client/*", _CL)
	FInc.Recursive(mname .. "/server/*", _SV)

end

local dontload = {}
dontload["sh_values.lua"] = true
dontload["cl_meta.lua"] = true 


local function LoadInventory()

	include("inventory/base/shared/sh_values.lua")
	AddCSLuaFile("inventory/base/shared/sh_values.lua")

	AddCSLuaFile("inventory/base/client/cl_meta.lua")

	IncludeFolder("inventory/base/shared/*_meta.lua")	--meta files get included before anything else

	--[[
		Load base before loading items
	]]
	IncludeFolder("inventory/base/server/tier0/*.lua", _SV)
	IncludeFolder("inventory/base/server/tier1/*.lua", _SV)
	IncludeFolder("inventory/base/server/tier1/blueprints/*.lua", _SV)
	IncludeFolder("inventory/base/server/tier2/*.lua", _SV)
	IncludeFolder("inventory/base/server/*.lua", _SV)

	IncludeFolder("inventory/items/cl/*.lua", _CL)
	IncludeFolder("inventory/base/client/*.lua", _CL)


	IncludeFolder("inventory/base/shared/base/*", _SH)
	IncludeFolder("inventory/base/shared/*.lua", _SH)
	IncludeFolder("inventory/base/shared/equipment/*.lua", _SH)

	IncludeFolder("inventory/base/client/equipment/*.lua", _CL)

	--[[
		Base loaded; now load the items themselves
	]]

	IncludeFolder("inventory/items/sh/*", _SH)

	IncludeFolder("inventory/items/sv/*.lua", _SV)
	IncludeFolder("inventory/base/server/equipment/*.lua", _SV)

	


	if SERVER then 
		--script reload; reload and re-network everyone's inventories
		for k,v in ipairs(player.GetAll()) do 
			v:ResetInventory()
			v:NetworkInventory(true)
		end 
	end

	hook.Run("OnInvLoad")

	local _, metafolds = file.Find(MetaPath .. "/*", "LUA")

	for k,v in pairs(metafolds) do 
		print("including meta folder", v)
		IncludeMeta(v)
	end
end

Inventory.ReloadInventory = LoadInventory 

hook.Add("PostGamemodeLoaded", "Inventory", LoadInventory)

if CurTime() > 60 then --script reload?
	LoadInventory()
end
